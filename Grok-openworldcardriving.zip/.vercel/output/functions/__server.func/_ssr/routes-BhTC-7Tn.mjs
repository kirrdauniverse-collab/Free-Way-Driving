import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Navigation, i as Pause, n as Volume2, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BhTC-7Tn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var SAVE_KEY = "horizont-save-v2";
var FACTORY = {
	x: -255,
	z: 95
};
var AIRPORT = {
	x: 110,
	z: -400
};
var PLAZA = {
	x: 42,
	z: -70
};
var CARS = [
	{
		id: "csibe",
		name: "Kis Csibe",
		klass: "Városi",
		price: 0,
		color: "#c45c3a",
		accent: "#1a1c20",
		glass: "#8aa4b8",
		maxSpeed: 36,
		accel: 13,
		brake: 22,
		turn: 2.35,
		grip: 7.2,
		mass: 1,
		body: "hatch",
		roar: .85,
		blurb: "Az első kocsid. Fürge, barátságos, és mindenhová elkísér."
	},
	{
		id: "utca",
		name: "Utca 1.6",
		klass: "Szedán",
		price: 3400,
		color: "#3d5c7a",
		accent: "#cfd5dc",
		glass: "#9bb4c4",
		maxSpeed: 42,
		accel: 14.5,
		brake: 24,
		turn: 2.15,
		grip: 7.6,
		mass: 1.1,
		body: "sedan",
		roar: .8,
		blurb: "Csendes utazó. Taxisofőrök és nénik kedvence."
	},
	{
		id: "taxika",
		name: "Sárga Járat",
		klass: "Taxi",
		price: 4600,
		color: "#e8b86d",
		accent: "#1a1c20",
		glass: "#8aa4b8",
		maxSpeed: 40,
		accel: 15,
		brake: 24,
		turn: 2.2,
		grip: 7.5,
		mass: 1.12,
		body: "sedan",
		roar: .82,
		blurb: "A városi sárga. Taxi fuvaron +15% fizetség."
	},
	{
		id: "kombi",
		name: "Család Kombi",
		klass: "Kombi",
		price: 6100,
		color: "#5a6b7a",
		accent: "#c45c3a",
		glass: "#9bb4c4",
		maxSpeed: 44,
		accel: 14,
		brake: 24,
		turn: 2.05,
		grip: 7.8,
		mass: 1.22,
		body: "estate",
		roar: .86,
		blurb: "Hosszú raktér, kényelmes futáshoz és buliszervezéshez."
	},
	{
		id: "hegy",
		name: "Hegy SUV",
		klass: "Terep",
		price: 9800,
		color: "#3a4a3c",
		accent: "#c8b49a",
		glass: "#7f93a0",
		maxSpeed: 42,
		accel: 14.5,
		brake: 23,
		turn: 1.95,
		grip: 8.6,
		mass: 1.45,
		body: "suv",
		roar: 1.02,
		blurb: "Magas, széles, otthon van a réten és a sivatagban is."
	},
	{
		id: "furgon",
		name: "Doboz Futár",
		klass: "Kisteher",
		price: 5200,
		color: "#d8d4c8",
		accent: "#2a6b8a",
		glass: "#9aa8b0",
		maxSpeed: 34,
		accel: 11,
		brake: 20,
		turn: 1.85,
		grip: 6.8,
		mass: 1.4,
		body: "van",
		roar: .95,
		blurb: "Rengeteg hely a csomagoknak. Futárkodáskor +20% fizetség."
	},
	{
		id: "pampa",
		name: "Pampa 4×4",
		klass: "Pickup",
		price: 7800,
		color: "#5a6b3a",
		accent: "#2a2c28",
		glass: "#7f93a0",
		maxSpeed: 40,
		accel: 13.5,
		brake: 21,
		turn: 2,
		grip: 8.4,
		mass: 1.35,
		body: "pickup",
		roar: 1.05,
		blurb: "Homokon, erdőn, réten sem ijed meg. Kisebb terep-büntetés."
	},
	{
		id: "bravo",
		name: "Bravo Nyitott",
		klass: "Kabrió",
		price: 14200,
		color: "#8a1f1a",
		accent: "#ece8e0",
		glass: "#6f88a0",
		maxSpeed: 50,
		accel: 21,
		brake: 27,
		turn: 2.6,
		grip: 6.6,
		mass: .92,
		body: "cabrio",
		roar: 1.22,
		blurb: "Lehajtott tető, éles kanyarok. A gyártelepen villog."
	},
	{
		id: "motor",
		name: "Fürge 250",
		klass: "Motor",
		price: 8900,
		color: "#1e4d8c",
		accent: "#e8eaee",
		glass: "#2a3340",
		maxSpeed: 48,
		accel: 22,
		brake: 26,
		turn: 3.1,
		grip: 6.2,
		mass: .55,
		body: "moto",
		roar: 1.05,
		blurb: "Két kerék, szűk kanyarok. A gyártelepen otthon van."
	},
	{
		id: "siraly",
		name: "Sirály Coupe",
		klass: "Sport",
		price: 16800,
		color: "#1e4d8c",
		accent: "#e8eaee",
		glass: "#6f88a0",
		maxSpeed: 52,
		accel: 20,
		brake: 28,
		turn: 2.55,
		grip: 6.4,
		mass: .95,
		body: "coupe",
		roar: 1.15,
		blurb: "Alacsony, éles, imád driftelni. Az elhagyott gyárban otthon van."
	},
	{
		id: "kamion",
		name: "Teher 12t",
		klass: "Kamion",
		price: 18500,
		color: "#6a5340",
		accent: "#e8b86d",
		glass: "#7f93a0",
		maxSpeed: 32,
		accel: 8.5,
		brake: 16,
		turn: 1.35,
		grip: 6.4,
		mass: 2.4,
		body: "truck",
		roar: 1.4,
		blurb: "Hosszú orrú teherautó. Futárnál +25% a rakományért."
	},
	{
		id: "busz",
		name: "Városi 12",
		klass: "Busz",
		price: 22800,
		color: "#c45c3a",
		accent: "#dce0e6",
		glass: "#8aa4b8",
		maxSpeed: 30,
		accel: 8,
		brake: 18,
		turn: 1.25,
		grip: 6.6,
		mass: 2.2,
		body: "bus",
		roar: 1.15,
		blurb: "A járat. Taxi- és bulifuvaron extra férőhely, extra borravaló."
	},
	{
		id: "villam",
		name: "Villám GT",
		klass: "Izom",
		price: 24600,
		color: "#8a1f1a",
		accent: "#111111",
		glass: "#5a6a78",
		maxSpeed: 56,
		accel: 24,
		brake: 26,
		turn: 2.05,
		grip: 5.8,
		mass: 1.25,
		body: "muscle",
		roar: 1.55,
		blurb: "Durrog, ordít, és a reptéri kifutón király."
	},
	{
		id: "nyil",
		name: "Nyíl RS",
		klass: "Szuper",
		price: 54e3,
		color: "#ece8e0",
		accent: "#1a1c20",
		glass: "#2a3340",
		maxSpeed: 72,
		accel: 30,
		brake: 34,
		turn: 2.4,
		grip: 7.8,
		mass: .9,
		body: "super",
		roar: 1.3,
		blurb: "Végsebességre született. A sivatagi kifutón elszáll."
	},
	{
		id: "holdfeny",
		name: "Holdfény",
		klass: "Rejtett",
		price: 0,
		color: "#c8d4dc",
		accent: "#3a6a78",
		glass: "#1a2830",
		maxSpeed: 64,
		accel: 32,
		brake: 32,
		turn: 2.5,
		grip: 8,
		mass: .88,
		body: "ev",
		roar: .28,
		secret: true,
		blurb: "Az erdőben felejtett prototípus. Csendes, aztán elszáguld."
	}
];
var CAR_BY_ID = Object.fromEntries(CARS.map((c) => [c.id, c]));
var POIS = [
	{
		id: "garage",
		name: "Műhely",
		x: 52,
		z: 28,
		hint: "Fejleszd vagy cseréld az autódat",
		color: "#8aa4b8"
	},
	{
		id: "dealer",
		name: "Kereskedés",
		x: -56,
		z: 28,
		hint: "Új autók a kirakatban",
		color: "#dce0e6"
	},
	{
		id: "taxi",
		name: "Taxiállomás",
		x: 8,
		z: 88,
		hint: "Utasok várnak rád",
		color: "#e8b86d"
	},
	{
		id: "courier",
		name: "Futárközpont",
		x: -88,
		z: -44,
		hint: "Csomagok mennek-jönnek",
		color: "#5ecf9a"
	},
	{
		id: "market",
		name: "Piac",
		x: 92,
		z: -36,
		hint: "Bevásárlás Ilonka néninek",
		color: "#c45c3a"
	},
	{
		id: "grandma",
		name: "Ilonka néni",
		x: 318,
		z: 42,
		hint: "A néni háza a réten",
		color: "#e8c4a8"
	},
	{
		id: "secret",
		name: "Hátsó udvar",
		x: -28,
		z: -96,
		hint: "Diszkrét, jól fizető fuvar",
		color: "#6a7080"
	},
	{
		id: "party",
		name: "Főtér",
		x: PLAZA.x,
		z: PLAZA.z,
		hint: "Buli szervezés a téren",
		color: "#e8b86d"
	},
	{
		id: "drift",
		name: "Gyártelep",
		x: FACTORY.x,
		z: FACTORY.z,
		hint: "Elhagyott csarnokok, driftkör",
		color: "#67e8f9"
	},
	{
		id: "accel",
		name: "Reptér",
		x: AIRPORT.x,
		z: AIRPORT.z,
		hint: "Üres kifutó, gyorsulás 0–100",
		color: "#e24a3b"
	},
	{
		id: "topspeed",
		name: "Kifutó",
		x: 0,
		z: -360,
		hint: "Végsebesség a sivatagban",
		color: "#e8b86d"
	},
	{
		id: "jump",
		name: "Ugratók",
		x: 96,
		z: 318,
		hint: "Dombokról a levegőbe",
		color: "#7ec8c4"
	},
	{
		id: "circuit",
		name: "Városi kör",
		x: 0,
		z: -8,
		hint: "Időfutam a belvárosban",
		color: "#dce0e6"
	},
	{
		id: "fishing",
		name: "Stég",
		x: -36,
		z: 392,
		hint: "Állj meg a víznél, és pecázz",
		color: "#5ecf9a"
	},
	{
		id: "statue",
		name: "Szobor",
		x: 0,
		z: 0,
		hint: "Dudálj háromszor…",
		color: "#a8b0bc"
	},
	{
		id: "hidden",
		name: "Tisztás",
		x: -412,
		z: 118,
		hint: "Valami csillog a fák között",
		color: "#c8d4dc"
	},
	{
		id: "fagyi",
		name: "Fagyis",
		x: 48,
		z: 348,
		hint: "Állj meg egy gombócért",
		color: "#f2d2c4"
	}
];
var POI_BY_ID = Object.fromEntries(POIS.map((p) => [p.id, p]));
var DESTINATIONS = [
	{
		id: "work-taxi",
		kind: "work",
		name: "Taxiállomás",
		blurb: "Utasok várnak — finom vezetés, borravaló.",
		x: 8,
		z: 88,
		poi: "taxi"
	},
	{
		id: "work-courier",
		kind: "work",
		name: "Futárközpont",
		blurb: "Csomagok a város és a vidék között.",
		x: -88,
		z: -44,
		poi: "courier"
	},
	{
		id: "work-market",
		kind: "work",
		name: "Piac",
		blurb: "Bevásárlás Ilonka néninek.",
		x: 92,
		z: -36,
		poi: "market"
	},
	{
		id: "work-secret",
		kind: "work",
		name: "Hátsó udvar",
		blurb: "Diszkrét, jól fizető különfuvar.",
		x: -28,
		z: -96,
		poi: "secret"
	},
	{
		id: "ch-drift",
		kind: "challenge",
		name: "Gyári drift",
		blurb: "Csússz az elhagyott gyártelepen.",
		x: FACTORY.x,
		z: FACTORY.z,
		poi: "drift"
	},
	{
		id: "ch-accel",
		kind: "challenge",
		name: "Reptéri gyorsulás",
		blurb: "Nulláról százra az üres kifutón.",
		x: AIRPORT.x,
		z: AIRPORT.z,
		poi: "accel"
	},
	{
		id: "ch-top",
		kind: "challenge",
		name: "Sivatagi kifutó",
		blurb: "Maxold a tempót a sivatagban.",
		x: 0,
		z: -360,
		poi: "topspeed"
	},
	{
		id: "ch-jump",
		kind: "challenge",
		name: "Ugratók",
		blurb: "Dombokról a levegőbe.",
		x: 96,
		z: 318,
		poi: "jump"
	},
	{
		id: "ch-circuit",
		kind: "challenge",
		name: "Városi kör",
		blurb: "Időfutam a belvárosi kapukon.",
		x: 0,
		z: -8,
		poi: "circuit"
	},
	{
		id: "party-plaza",
		kind: "party",
		name: "Főtér — buli",
		blurb: "Dísz, vendégek, zene a téren.",
		x: PLAZA.x,
		z: PLAZA.z,
		poi: "party"
	}
];
var JOB_META = {
	taxi: {
		name: "Taxisofőr",
		desc: "Vigyél utasokat a városban. Finom vezetés = nagyobb borravaló.",
		giver: "taxi"
	},
	courier: {
		name: "Futárkodás",
		desc: "Csomagokat viszel a város és a vidék között.",
		giver: "courier"
	},
	grandma: {
		name: "Bevásárlás néninek",
		desc: "Vásárolj be Ilonka néninek, és vidd haza a szatyrokat.",
		giver: "market"
	},
	secret: {
		name: "Titkos futár",
		desc: "Különleges csomag — állatkerti meglepetés. Jól fizet, ne törj semmit.",
		giver: "secret"
	},
	party: {
		name: "Buli szervezés",
		desc: "Díszítés a piacról, vendégek, aztán a főtér.",
		giver: "party"
	}
};
var CHALLENGE_META = {
	drift: {
		name: "Gyári drift",
		desc: "Gyűjts driftpontot 35 másodperc alatt az elhagyott gyárban.",
		poi: "drift"
	},
	accel: {
		name: "Gyorsulás 0–100",
		desc: "Állj a reptéri vonalra, majd menj 100 km/órára minél hamarabb.",
		poi: "accel"
	},
	topspeed: {
		name: "Végsebesség",
		desc: "Érd el a legmagasabb tempót a sivatagi kifutón.",
		poi: "topspeed"
	},
	jump: {
		name: "Ugrató",
		desc: "Szállj el a dombokról — a levegőben töltött idő számít.",
		poi: "jump"
	},
	circuit: {
		name: "Városi időfutam",
		desc: "Érintsd a kapukat sorrendben, minél gyorsabban.",
		poi: "circuit"
	}
};
var UPGRADE_LABEL = {
	engine: "Motor",
	tires: "Gumik",
	brakes: "Fékek",
	turbo: "Turbó"
};
var UPGRADE_COST = [
	900,
	2100,
	4800
];
var CIRCUIT_GATES = [
	{
		x: 0,
		z: -8
	},
	{
		x: 96,
		z: -96
	},
	{
		x: 96,
		z: 96
	},
	{
		x: -96,
		z: 96
	},
	{
		x: -96,
		z: -96
	}
];
var TAXI_STOPS = [
	{
		x: 88,
		z: 88,
		name: "Déli tér"
	},
	{
		x: -88,
		z: 88,
		name: "Pályaudvar"
	},
	{
		x: 88,
		z: -88,
		name: "Múzeum"
	},
	{
		x: -88,
		z: -88,
		name: "Kikötőnegyed"
	},
	{
		x: 0,
		z: -110,
		name: "Északi kapu"
	},
	{
		x: 318,
		z: 42,
		name: "Ilonka néni"
	},
	{
		x: -56,
		z: 28,
		name: "Kereskedés"
	},
	{
		x: 48,
		z: 348,
		name: "Fagyis a parton"
	},
	{
		x: PLAZA.x,
		z: PLAZA.z,
		name: "Főtér"
	},
	{
		x: FACTORY.x,
		z: FACTORY.z,
		name: "Gyártelep"
	},
	{
		x: AIRPORT.x,
		z: AIRPORT.z,
		name: "Reptér"
	}
];
var COURIER_STOPS = [
	{
		x: 92,
		z: -36,
		name: "Piac"
	},
	{
		x: 318,
		z: 42,
		name: "Réti ház"
	},
	{
		x: FACTORY.x,
		z: FACTORY.z,
		name: "Gyári porta"
	},
	{
		x: 0,
		z: -280,
		name: "Sivatagi kút"
	},
	{
		x: 52,
		z: 28,
		name: "Műhely"
	},
	{
		x: -36,
		z: 392,
		name: "Stég"
	},
	{
		x: 48,
		z: 348,
		name: "Fagyis"
	},
	{
		x: AIRPORT.x,
		z: AIRPORT.z,
		name: "Hangár"
	}
];
var PASSENGERS = [
	{
		name: "Marci bácsi",
		kind: "elder",
		line: "Nyugodtan, fiam, nincs rohanás."
	},
	{
		name: "Kati néni",
		kind: "elder",
		line: "A piacra sietek, de szépen, kérlek."
	},
	{
		name: "Áron",
		kind: "kid",
		line: "Mehetünk gyorsan? De a biztonsági öv bevan!"
	},
	{
		name: "Zsófi",
		kind: "kid",
		line: "Ha ugrunk egy dombon, rögtön rajongó leszek."
	},
	{
		name: "Béla",
		kind: "adult",
		line: "A pályaudvarra, köszönöm."
	},
	{
		name: "Anna",
		kind: "adult",
		line: "A múzeumhoz, ha lehet, rázkódás nélkül."
	},
	{
		name: "Peti",
		kind: "kid",
		line: "Láttad a szobrot a téren? Dudálj neki!"
	},
	{
		name: "Gábor bácsi",
		kind: "elder",
		line: "Régen ilyen kocsival jártam… nosztalgia."
	}
];
var PARTY_GUESTS = [
	{
		name: "Réka",
		line: "Hozom a hangszórót, csak ne rázd szét!"
	},
	{
		name: "Máté",
		line: "A lufik a csomagtartóban. Lassan a kanyarban."
	},
	{
		name: "Lili",
		kind: "kid",
		line: "Lesz fagyi a bulin? Ugorjunk egyet!"
	}
];
var VIEWPOINTS = [
	{
		id: "desert",
		name: "Sivatagi kilátó",
		x: 12,
		z: -410
	},
	{
		id: "forest",
		name: "Erdei tisztás",
		x: -390,
		z: 40
	},
	{
		id: "coast",
		name: "Naplemente-part",
		x: 80,
		z: 420
	},
	{
		id: "hills",
		name: "Dombtető",
		x: 40,
		z: 240
	}
];
var SECRET_CARGO = [
	"Egy szökött kecske a raktérben. Nyugi, béget.",
	"Papagáj ketrecben. Nem szabad kinyitni.",
	"Egy hatalmas torta a polgármesternek. Ne rázd!",
	"Titkos palánta az erdészetnek."
];
var defaultSave = () => ({
	version: 2,
	money: 1800,
	owned: ["csibe"],
	currentCar: "csibe",
	upgrades: { csibe: {
		engine: 0,
		tires: 0,
		brakes: 0,
		turbo: 0
	} },
	stars: {},
	foundSecret: false,
	statueHonks: 0,
	fishCaught: 0,
	jobsDone: 0,
	iceCreams: 0,
	viewsFound: [],
	champion: false
});
function migrate(raw) {
	const base = defaultSave();
	return {
		...base,
		...raw,
		version: 2,
		owned: raw.owned?.length ? raw.owned : base.owned,
		upgrades: {
			...base.upgrades,
			...raw.upgrades
		},
		stars: { ...raw.stars },
		viewsFound: Array.isArray(raw.viewsFound) ? raw.viewsFound : [],
		iceCreams: raw.iceCreams ?? 0,
		champion: Boolean(raw.champion)
	};
}
function loadSave() {
	try {
		const raw = localStorage.getItem("horizont-save-v2") ?? localStorage.getItem("horizont-save-v1");
		if (!raw) return defaultSave();
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") return defaultSave();
		return migrate(parsed);
	} catch {
		return defaultSave();
	}
}
function writeSave(data) {
	try {
		const payload = JSON.stringify({
			...data,
			version: 2
		});
		localStorage.setItem(SAVE_KEY, payload);
		localStorage.setItem(SAVE_KEY + ":bak", payload);
	} catch {}
}
function hasSave() {
	try {
		return Boolean(localStorage.getItem("horizont-save-v2") || localStorage.getItem("horizont-save-v1"));
	} catch {
		return false;
	}
}
function resetSave() {
	const fresh = defaultSave();
	writeSave(fresh);
	return fresh;
}
var toastSeq = 1;
function snapshot(s) {
	return {
		version: 2,
		money: s.money,
		owned: s.owned,
		currentCar: s.currentCar,
		upgrades: s.upgrades,
		stars: s.stars,
		foundSecret: s.foundSecret,
		statueHonks: s.statueHonks,
		fishCaught: s.fishCaught,
		jobsDone: s.jobsDone,
		iceCreams: s.iceCreams,
		viewsFound: s.viewsFound,
		champion: s.champion
	};
}
var useGame = create((set, get) => ({
	...loadSave(),
	screen: "loading",
	ready: false,
	loadProgress: 0,
	speedKmh: 0,
	rpm: 800,
	gear: 1,
	biomeLabel: "Város",
	prompt: null,
	toast: null,
	job: null,
	challenge: null,
	waypoint: null,
	hoodCam: false,
	minimap: null,
	fishResult: null,
	posX: 18,
	posZ: 52,
	heading: 0,
	wayRel: null,
	wayDist: null,
	drifting: false,
	setScreen: (screen) => set({ screen }),
	setReady: (ready) => set({ ready }),
	setProgress: (loadProgress) => set({ loadProgress }),
	setTelemetry: (t) => set({
		speedKmh: t.speedKmh,
		rpm: t.rpm,
		gear: t.gear,
		biomeLabel: t.biomeLabel,
		prompt: t.prompt,
		minimap: t.minimap === void 0 ? get().minimap : t.minimap,
		posX: t.posX ?? get().posX,
		posZ: t.posZ ?? get().posZ,
		heading: t.heading ?? get().heading,
		wayRel: t.wayRel === void 0 ? get().wayRel : t.wayRel,
		wayDist: t.wayDist === void 0 ? get().wayDist : t.wayDist,
		drifting: t.drifting ?? get().drifting
	}),
	setJob: (job) => set({ job }),
	setChallenge: (challenge) => set({ challenge }),
	setWaypoint: (waypoint) => set({ waypoint }),
	setHood: (hoodCam) => set({ hoodCam }),
	addMoney: (n) => {
		set({ money: Math.max(0, Math.round(get().money + n)) });
		get().persist();
	},
	setStars: (id, n) => {
		if (n <= (get().stars[id] ?? 0)) return;
		set({ stars: {
			...get().stars,
			[id]: n
		} });
		get().persist();
	},
	ownCar: (id) => {
		if (get().owned.includes(id)) return;
		const car = CAR_BY_ID[id];
		set({
			owned: [...get().owned, id],
			upgrades: {
				...get().upgrades,
				[id]: get().upgrades[id] ?? {
					engine: 0,
					tires: 0,
					brakes: 0,
					turbo: 0
				}
			},
			currentCar: id,
			money: get().money - (car.secret ? 0 : car.price)
		});
		get().persist();
	},
	selectCar: (id) => {
		if (!get().owned.includes(id)) return;
		set({ currentCar: id });
		get().persist();
	},
	bumpUpgrade: (car, kind) => {
		const u = get().upgrades[car] ?? {
			engine: 0,
			tires: 0,
			brakes: 0,
			turbo: 0
		};
		const lvl = u[kind] ?? 0;
		if (lvl >= 3) return false;
		const cost = [
			900,
			2100,
			4800
		][lvl] ?? 99999;
		if (get().money < cost) return false;
		set({
			money: get().money - cost,
			upgrades: {
				...get().upgrades,
				[car]: {
					...u,
					[kind]: lvl + 1
				}
			}
		});
		get().persist();
		return true;
	},
	sellCar: (id) => {
		const s = get();
		if (!s.owned.includes(id) || s.owned.length < 2) return false;
		const car = CAR_BY_ID[id];
		const refund = Math.round((car.price || 1800) * .7);
		const owned = s.owned.filter((c) => c !== id);
		set({
			owned,
			currentCar: s.currentCar === id ? owned[0] : s.currentCar,
			money: s.money + refund
		});
		get().persist();
		get().toastMsg(`${car.name} eladva · +${refund.toLocaleString("hu-HU")} Ft`);
		return true;
	},
	toastMsg: (text) => {
		const id = toastSeq++;
		set({ toast: {
			id,
			text
		} });
		window.setTimeout(() => {
			if (get().toast?.id === id) set({ toast: null });
		}, 3e3);
	},
	persist: () => {
		writeSave(snapshot(get()));
	},
	applySave: (save) => set({ ...save }),
	newGame: () => {
		set({
			...resetSave(),
			job: null,
			challenge: null,
			waypoint: null,
			fishResult: null
		});
	},
	bumpStat: (k, n = 1) => {
		set({ [k]: get()[k] + n });
		get().persist();
	},
	setFishResult: (fishResult) => set({ fishResult }),
	markView: (id) => {
		const found = get().viewsFound;
		if (found.includes(id)) return false;
		set({ viewsFound: [...found, id] });
		get().persist();
		return true;
	},
	markSecret: () => {
		if (get().foundSecret) return;
		set({ foundSecret: true });
		get().persist();
	},
	setChampion: () => {
		if (get().champion) return;
		set({
			champion: true,
			money: get().money + 8e3
		});
		get().persist();
	}
}));
function effectiveStats(carId) {
	const def = CAR_BY_ID[carId];
	const u = useGame.getState().upgrades[carId] ?? {};
	const e = u.engine ?? 0;
	const t = u.tires ?? 0;
	const b = u.brakes ?? 0;
	const tu = u.turbo ?? 0;
	return {
		...def,
		maxSpeed: def.maxSpeed * (1 + .1 * e + .04 * tu),
		accel: def.accel * (1 + .12 * e + .1 * tu),
		brake: def.brake * (1 + .14 * b + .05 * t),
		grip: def.grip * (1 + .1 * t),
		turn: def.turn * (1 + .06 * t),
		turbo: tu
	};
}
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"KeyE",
	"KeyH",
	"KeyM",
	"KeyV",
	"KeyP",
	"Space",
	"Escape",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"ShiftLeft",
	"ShiftRight"
]);
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function radialDeadzone(x, y, dz = .18) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var InputManager = class {
	keys = /* @__PURE__ */ new Set();
	qaKeys = null;
	qaSteer = null;
	blocked = false;
	steerTouch = 0;
	throttleTouch = 0;
	brakeTouch = 0;
	handbrakeTouch = false;
	interactTouch = false;
	hornTouch = false;
	pauseTouch = false;
	mapTouch = false;
	steer = 0;
	throttle = 0;
	brake = 0;
	handbrake = false;
	interact = false;
	interactPressed = false;
	horn = false;
	hornPressed = false;
	pausePressed = false;
	mapPressed = false;
	cameraPressed = false;
	prevInteract = false;
	prevHorn = false;
	prevPause = false;
	prevMap = false;
	prevCam = false;
	attached = false;
	onDown = (e) => {
		if (e.repeat) {
			if (GAME_CODES.has(e.code)) e.preventDefault();
			return;
		}
		this.keys.add(e.code);
		if (GAME_CODES.has(e.code)) e.preventDefault();
	};
	onUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
	};
	attach() {
		if (this.attached) return;
		this.attached = true;
		window.addEventListener("keydown", this.onDown);
		window.addEventListener("keyup", this.onUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onBlur);
	}
	detach() {
		if (!this.attached) return;
		this.attached = false;
		window.removeEventListener("keydown", this.onDown);
		window.removeEventListener("keyup", this.onUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onBlur);
		this.keys.clear();
	}
	setKeys(codes) {
		this.qaKeys = codes.length ? codes : null;
		if (!codes.length) this.qaSteer = null;
	}
	poll() {
		if (this.blocked) {
			this.steer = 0;
			this.throttle = 0;
			this.brake = 0;
			this.handbrake = false;
			this.interact = false;
			this.interactPressed = false;
			this.horn = false;
			this.hornPressed = false;
			this.pausePressed = false;
			this.mapPressed = false;
			this.cameraPressed = false;
			this.prevInteract = false;
			this.prevHorn = false;
			this.prevPause = false;
			this.prevMap = false;
			this.prevCam = false;
			return;
		}
		const k = this.qaKeys ? new Set(this.qaKeys) : this.keys;
		let steer = 0;
		if (k.has("KeyA") || k.has("ArrowLeft")) steer += 1;
		if (k.has("KeyD") || k.has("ArrowRight")) steer -= 1;
		steer += this.steerTouch;
		let throttle = k.has("KeyW") || k.has("ArrowUp") ? 1 : 0;
		let brake = k.has("KeyS") || k.has("ArrowDown") ? 1 : 0;
		throttle = Math.max(throttle, this.throttleTouch);
		brake = Math.max(brake, this.brakeTouch);
		const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : [];
		if (pads) for (const p of pads) {
			if (!p || p.mapping !== "standard") continue;
			const st = radialDeadzone(p.axes[0] ?? 0, p.axes[1] ?? 0);
			steer += -st.x;
			const trigR = p.buttons[7]?.value ?? 0;
			const trigL = p.buttons[6]?.value ?? 0;
			if (trigR > .05) throttle = Math.max(throttle, trigR);
			if (trigL > .05) brake = Math.max(brake, trigL);
			if (st.y < -.3) throttle = Math.max(throttle, -st.y);
			if (st.y > .3) brake = Math.max(brake, st.y);
			if (p.buttons[0]?.pressed) this.handbrakeTouch = true;
			if (p.buttons[2]?.pressed) this.interactTouch = true;
			if (p.buttons[1]?.pressed) this.hornTouch = true;
			if (p.buttons[9]?.pressed) this.pauseTouch = true;
		}
		this.steer = this.qaSteer ?? clamp(steer, -1, 1);
		this.throttle = clamp(throttle, 0, 1);
		this.brake = clamp(brake, 0, 1);
		this.handbrake = k.has("Space") || k.has("ShiftLeft") || this.handbrakeTouch;
		const inter = k.has("KeyE") || this.interactTouch;
		this.interactPressed = inter && !this.prevInteract;
		this.interact = inter;
		this.prevInteract = inter;
		const horn = k.has("KeyH") || this.hornTouch;
		this.hornPressed = horn && !this.prevHorn;
		this.horn = horn;
		this.prevHorn = horn;
		const pause = k.has("Escape") || k.has("KeyP") || this.pauseTouch;
		this.pausePressed = pause && !this.prevPause;
		this.prevPause = pause;
		this.pauseTouch = false;
		const map = k.has("KeyM") || this.mapTouch;
		this.mapPressed = map && !this.prevMap;
		this.prevMap = map;
		this.mapTouch = false;
		const cam = k.has("KeyV");
		this.cameraPressed = cam && !this.prevCam;
		this.prevCam = cam;
		this.interactTouch = false;
		this.hornTouch = false;
	}
};
var input = new InputManager();
function ft(n) {
	return `${Math.round(n).toLocaleString("hu-HU")} Ft`;
}
function resume() {
	useGame.getState().setScreen("play");
	window.__horizont?.setFrozen(false);
}
function openMap() {
	useGame.getState().setScreen("map");
	window.__horizont?.setFrozen(true);
}
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const ready = useGame((s) => s.ready);
	const screen = useGame((s) => s.screen);
	const progress = useGame((s) => s.loadProgress);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let dead = false;
		let engine = null;
		import("./engine-a-gXoj-1.mjs").then(({ GameEngine }) => {
			if (dead) return;
			const created = new GameEngine(canvas);
			window.__horizont = created;
			engine = created;
			created.start();
		});
		return () => {
			dead = true;
			engine?.dispose();
			window.__horizont = void 0;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "game-canvas"
			}),
			!ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, { progress }),
			ready && screen === "title" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {}),
			ready && screen === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayHud, {}),
			ready && screen === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseMenu, {}),
			ready && screen === "help" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Help, {}),
			ready && screen === "map" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapOverlay, {}),
			ready && screen === "garage" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Garage, {}),
			ready && screen === "dealer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dealer, {}),
			ready && screen === "fishing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fishing, {}),
			ready && (screen === "play" || screen === "pause") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchControls, {})
		]
	});
}
function Loading({ progress }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 flex items-end bg-bg/40 p-6 sm:items-center sm:justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hud-panel w-full max-w-sm rounded-xl p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-5xl tracking-wide",
					children: "HORIZONT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "A város ébred…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 h-1.5 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "load-bar h-full bg-accent",
						style: { width: `${Math.round(progress * 100)}%` }
					})
				})
			]
		})
	});
}
function Title() {
	const [help, setHelp] = (0, import_react.useState)(false);
	const saved = hasSave();
	const start = (fresh) => {
		if (fresh) useGame.getState().newGame();
		window.__horizont?.beginPlay();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 flex items-end p-4 sm:items-center sm:p-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto hud-panel w-full max-w-md rounded-xl p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-widest text-muted",
					children: "NYÍLT VILÁG"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-6xl leading-none tracking-wide",
					children: "HORIZONT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-sm text-base leading-relaxed text-muted",
					children: "Vezess a városban, az erdőn és a sivatagban. Keress pénzt fuvarokkal, fejleszd a kocsit, és keresd a rejtett helyeket."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-12 rounded-lg bg-accent px-4 font-display text-xl tracking-wide text-accent-fg",
							onClick: () => start(true),
							children: "Indítás"
						}),
						saved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-12 rounded-lg border border-border bg-surface px-4 font-display text-xl text-fg",
							onClick: () => start(false),
							children: "Folytatás"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-11 rounded-lg px-4 text-muted",
							onClick: () => setHelp((v) => !v),
							children: "Segítség"
						})
					]
				}),
				help && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpBody, {})
			]
		})
	});
}
function PlayHud() {
	const speed = useGame((s) => s.speedKmh);
	const gear = useGame((s) => s.gear);
	const rpm = useGame((s) => s.rpm);
	const biome = useGame((s) => s.biomeLabel);
	const money = useGame((s) => s.money);
	const prompt = useGame((s) => s.prompt);
	const toast = useGame((s) => s.toast);
	const job = useGame((s) => s.job);
	const challenge = useGame((s) => s.challenge);
	const minimap = useGame((s) => s.minimap);
	const wayRel = useGame((s) => s.wayRel);
	const wayDist = useGame((s) => s.wayDist);
	const waypoint = useGame((s) => s.waypoint);
	const drifting = useGame((s) => s.drifting);
	const rpmPct = Math.min(100, Math.max(8, (rpm - 700) / 6500 * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 sm:p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud-panel rounded-xl px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl leading-none tabular-nums",
							children: Math.round(speed)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-sm text-muted",
							children: "km/h"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center gap-2 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [gear, ". fokozat"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: biome }),
							drifting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-speed",
								children: "drift"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-1 w-28 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rpm-fill h-full bg-speed",
							style: { width: `${rpmPct}%` }
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hud-panel rounded-xl px-4 py-3 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Pénz"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-cash",
						children: ft(money)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudBtn, {
						label: "Úticél",
						onClick: openMap,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudBtn, {
						label: "Szünet",
						onClick: () => {
							useGame.getState().setScreen("pause");
							window.__horizont?.setFrozen(true);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
					})]
				})]
			})]
		}),
		(job || challenge) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute top-36 left-3 max-w-xs sm:top-32 sm:left-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud-panel rounded-xl px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: job?.title ?? challenge?.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: job?.detail ?? challenge?.detail
				})]
			})
		}),
		waypoint && wayRel != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute top-36 right-3 sm:top-32 sm:right-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud-panel flex items-center gap-2 rounded-xl px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, {
					className: "size-5 text-accent",
					style: { transform: `rotate(${-wayRel * 180 / Math.PI}deg)` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: waypoint.label ?? "Úticél"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [Math.round(wayDist ?? 0), " m"]
				})] })]
			})
		}),
		prompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-x-0 bottom-28 flex justify-center px-4 sm:bottom-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hud-panel rounded-full px-4 py-2 text-sm",
				children: prompt
			})
		}),
		toast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-x-0 bottom-40 flex justify-center px-4 sm:bottom-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hud-panel rounded-lg px-4 py-2 text-sm",
				children: toast.text
			})
		}),
		minimap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: minimap,
			alt: "Térkép",
			className: "pointer-events-none absolute right-3 bottom-3 size-28 rounded-xl border border-border sm:right-4 sm:bottom-4 sm:size-36"
		})
	] });
}
function HudBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: "hud-panel flex min-h-11 items-center gap-2 rounded-lg px-3 text-sm",
		onClick,
		children: [children, label]
	});
}
function PauseMenu() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Szünet",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg",
				onClick: resume,
				children: "Folytatás"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-12 rounded-lg border border-border bg-surface font-display text-xl",
				onClick: openMap,
				children: "Úticél"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-12 rounded-lg border border-border bg-surface font-display text-xl",
				onClick: () => useGame.getState().setScreen("help"),
				children: "Segítség"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-11 text-muted",
				onClick: () => {
					useGame.getState().setScreen("title");
					window.__horizont?.setFrozen(true);
				},
				children: "Főmenü"
			})
		]
	});
}
function Help() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Irányítás",
		onClose: resume,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpBody, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg",
			onClick: resume,
			children: "Vissza"
		})]
	});
}
function HelpBody() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "mt-4 space-y-2 text-sm leading-relaxed text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "W / felfelé — gáz. S — fék. A és D — balra és jobbra." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Szóköz — kézifék drifteléshez. H — duda. V — motorháztető kamera." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "E — munka, műhely, kereskedés, peca. M — úticél." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Az Úticél menüben válassz munkát, kihívást vagy bulit: a nyilak mutatják az utat." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A gyártelepen driftelj, a reptéren gyorsulj. A víznél állj meg, és pecázz." })
		]
	});
}
function MapOverlay() {
	const [tab, setTab] = (0, import_react.useState)("work");
	const posX = useGame((s) => s.posX);
	const posZ = useGame((s) => s.posZ);
	const list = DESTINATIONS.filter((d) => d.kind === tab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Úticél",
		onClose: resume,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				{
					id: "work",
					label: "Munka"
				},
				{
					id: "challenge",
					label: "Kihívás"
				},
				{
					id: "party",
					label: "Buli"
				}
			].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: `min-h-11 rounded-lg border px-2 text-sm ${tab === t.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-surface text-fg"}`,
				onClick: () => setTab(t.id),
				children: t.label
			}, t.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex max-h-96 flex-col gap-2 overflow-y-auto",
			children: list.map((d) => {
				const dist = Math.hypot(d.x - posX, d.z - posZ);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex min-h-16 items-center justify-between gap-3 rounded-lg border border-border bg-surface px-3 py-2 text-left",
					onClick: () => {
						useGame.getState().setWaypoint({
							x: d.x,
							z: d.z,
							label: d.name
						});
						useGame.getState().toastMsg(`GPS: ${d.name}`);
						resume();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-xl",
						children: d.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: d.blurb
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shrink-0 text-sm text-muted",
						children: [Math.round(dist), " m"]
					})]
				}, d.id);
			})
		})]
	});
}
function Garage() {
	const money = useGame((s) => s.money);
	const owned = useGame((s) => s.owned);
	const current = useGame((s) => s.currentCar);
	const upgrades = useGame((s) => s.upgrades);
	const car = CARS.find((c) => c.id === current);
	const u = upgrades[current] ?? {};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Műhely",
		onClose: resume,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					car.name,
					" · ",
					ft(money)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: owned.map((id) => {
					const c = CARS.find((x) => x.id === id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `min-h-12 rounded-lg border px-3 text-left text-sm ${id === current ? "border-accent bg-surface-2" : "border-border bg-surface"}`,
						onClick: () => {
							useGame.getState().selectCar(id);
							window.__horizont?.swapCar(id);
						},
						children: c.name
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-col gap-2",
				children: [
					"engine",
					"tires",
					"brakes",
					"turbo"
				].map((k) => {
					const lvl = u[k] ?? 0;
					const cost = lvl >= 3 ? null : UPGRADE_COST[lvl];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: cost == null || money < (cost ?? 0),
						className: "flex min-h-12 items-center justify-between rounded-lg border border-border bg-surface px-3 text-sm disabled:opacity-40",
						onClick: () => {
							if (useGame.getState().bumpUpgrade(current, k)) useGame.getState().toastMsg(`${UPGRADE_LABEL[k]} szint ${lvl + 1}`);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							UPGRADE_LABEL[k],
							" · ",
							"●".repeat(lvl),
							"○".repeat(3 - lvl)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-cash",
							children: cost == null ? "Max" : ft(cost)
						})]
					}, k);
				})
			})
		]
	});
}
function Dealer() {
	const money = useGame((s) => s.money);
	const owned = useGame((s) => s.owned);
	const found = useGame((s) => s.foundSecret);
	const list = CARS.filter((c) => !c.secret || found);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Kereskedés",
		onClose: resume,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-cash",
			children: ft(money)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex max-h-96 flex-col gap-2 overflow-y-auto",
			children: list.map((c) => {
				const have = owned.includes(c.id);
				const canBuy = !have && !c.secret && money >= c.price;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								c.klass,
								" · ",
								c.blurb
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-4 shrink-0 rounded-full",
							style: { background: c.color }
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [
							!have && !c.secret && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: !canBuy,
								className: "min-h-11 flex-1 rounded-lg bg-accent text-sm text-accent-fg disabled:opacity-40",
								onClick: () => {
									useGame.getState().ownCar(c.id);
									window.__horizont?.swapCar(c.id);
									useGame.getState().toastMsg(`${c.name} a tiéd.`);
								},
								children: ["Vétel · ", ft(c.price)]
							}),
							have && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex min-h-11 flex-1 items-center text-sm text-cash",
								children: "Megvan"
							}),
							have && owned.length > 1 && c.id !== "csibe" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "min-h-11 rounded-lg border border-border px-3 text-sm",
								onClick: () => useGame.getState().sellCar(c.id),
								children: "Eladás"
							})
						]
					})]
				}, c.id);
			})
		})]
	});
}
function Fishing() {
	const [pos, setPos] = (0, import_react.useState)(.2);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		let p = .2;
		let dir = 1;
		let last = performance.now();
		const step = (t) => {
			const dt = Math.min(.05, (t - last) / 1e3);
			last = t;
			p += dir * dt * .72;
			if (p > 1) {
				p = 1;
				dir = -1;
			}
			if (p < 0) {
				p = 0;
				dir = 1;
			}
			setPos(p);
			raf = requestAnimationFrame(step);
		};
		raf = requestAnimationFrame(step);
		return () => cancelAnimationFrame(raf);
	}, []);
	const cast = () => {
		const sweet = Math.abs(pos - .72);
		const st = useGame.getState();
		if (sweet < .08) {
			st.addMoney(180);
			st.bumpStat("fishCaught");
			st.toastMsg("Ponty! +180 Ft");
			resume();
		} else if (sweet < .2) {
			st.addMoney(70);
			st.bumpStat("fishCaught");
			st.toastMsg("Keszeg. +70 Ft");
			resume();
		} else st.toastMsg("Elúszott. Cél a zöld sáv.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "Pecázás",
		onClose: resume,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Dobd be, amikor a mutató a zöld sávban van."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-4 h-4 overflow-hidden rounded-full bg-surface-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-0 h-full w-8 bg-cash/80",
					style: { left: "68%" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-0 h-full w-1 bg-fg",
					style: { left: `${pos * 100}%` }
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-4 min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg",
				onClick: cast,
				children: "Bevetés"
			})
		]
	});
}
function Overlay({ title, children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 flex items-end justify-center bg-bg/55 p-3 sm:items-center sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hud-panel flex max-h-dvh w-full max-w-md flex-col overflow-y-auto rounded-xl p-4 sm:p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-wide",
					children: title
				}), onClose && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "flex size-11 items-center justify-center rounded-lg border border-border",
					onClick: onClose,
					"aria-label": "Bezárás",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})
	});
}
function TouchControls() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-3 md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
				label: "Balra",
				onDown: () => {
					input.steerTouch = 1;
				},
				onUp: () => {
					input.steerTouch = 0;
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl",
					children: "A"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
				label: "Jobbra",
				onDown: () => {
					input.steerTouch = -1;
				},
				onUp: () => {
					input.steerTouch = 0;
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl",
					children: "D"
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
					label: "Fék",
					onDown: () => {
						input.brakeTouch = 1;
					},
					onUp: () => {
						input.brakeTouch = 0;
					},
					children: "S"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
					label: "Gáz",
					primary: true,
					onDown: () => {
						input.throttleTouch = 1;
					},
					onUp: () => {
						input.throttleTouch = 0;
					},
					children: "W"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
					label: "Kézifék",
					onDown: () => {
						input.handbrakeTouch = true;
					},
					onUp: () => {
						input.handbrakeTouch = false;
					},
					children: "●"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
					label: "Duda",
					onDown: () => {
						input.hornTouch = true;
					},
					onUp: () => {
						input.hornTouch = false;
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
					label: "E",
					onDown: () => {
						input.interactTouch = true;
					},
					onUp: () => {
						input.interactTouch = false;
					},
					children: "E"
				})
			]
		})]
	});
}
function Hold({ label, onDown, onUp, children, primary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": label,
		className: `flex size-12 items-center justify-center rounded-lg border border-border text-sm ${primary ? "bg-accent text-accent-fg" : "bg-bg/80 text-fg"}`,
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			onDown();
		},
		onPointerUp: onUp,
		onPointerCancel: onUp,
		onLostPointerCapture: onUp,
		children
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-4xl tracking-wide",
			children: "HORIZONT"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { SECRET_CARGO as _, AIRPORT as a, CIRCUIT_GATES as c, JOB_META as d, PARTY_GUESTS as f, POI_BY_ID as g, POIS as h, useGame as i, COURIER_STOPS as l, PLAZA as m, input as n, CAR_BY_ID as o, PASSENGERS as p, effectiveStats as r, CHALLENGE_META as s, routes_exports as t, FACTORY as u, TAXI_STOPS as v, VIEWPOINTS as y };
