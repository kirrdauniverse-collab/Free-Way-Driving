import { _ as SECRET_CARGO, a as AIRPORT, c as CIRCUIT_GATES, d as JOB_META, f as PARTY_GUESTS, g as POI_BY_ID, h as POIS, i as useGame, l as COURIER_STOPS, m as PLAZA, n as input, o as CAR_BY_ID, p as PASSENGERS, r as effectiveStats, s as CHALLENGE_META, u as FACTORY, v as TAXI_STOPS, y as VIEWPOINTS } from "./routes-BhTC-7Tn.mjs";
import { A as SphereGeometry, C as PlaneGeometry, D as SRGBColorSpace, E as RepeatWrapping, F as Vector3, M as Sprite, N as SpriteMaterial, O as Scene, P as TorusGeometry, S as PerspectiveCamera, T as PointsMaterial, _ as InstancedMesh, a as BufferGeometry, b as MeshStandardMaterial, c as CircleGeometry, d as CylinderGeometry, f as DirectionalLight, g as HemisphereLight, h as Group, i as BufferAttribute, j as SpotLight, k as ShaderMaterial, l as Color, m as FogExp2, n as AmbientLight, o as CanvasTexture, p as DodecahedronGeometry, r as BoxGeometry, s as CapsuleGeometry, t as WebGLRenderer, u as ConeGeometry, v as Mesh, w as Points, x as Object3D, y as MeshBasicMaterial } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-a-gXoj-1.js
function clamp$2(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	engineGain = null;
	osc = null;
	osc2 = null;
	osc3 = null;
	filter = null;
	noise = null;
	noiseGain = null;
	wind = null;
	screech = null;
	muted = false;
	started = false;
	lastPop = 0;
	prevThrottle = 0;
	unlock() {
		if (this.ctx) {
			if (this.ctx.state === "suspended") this.ctx.resume();
			return;
		}
		const AC = window.AudioContext || window.webkitAudioContext;
		this.ctx = new AC({ latencyHint: "interactive" });
		this.master = this.ctx.createGain();
		this.master.gain.value = .92;
		this.master.connect(this.ctx.destination);
		this.sfx = this.ctx.createGain();
		this.sfx.gain.value = .95;
		this.sfx.connect(this.master);
		this.engineGain = this.ctx.createGain();
		this.engineGain.gain.value = 0;
		this.engineGain.connect(this.master);
		this.startEngineGraph();
		document.addEventListener("visibilitychange", () => {
			if (document.visibilityState === "visible") this.ctx?.resume();
		});
	}
	startEngineGraph() {
		if (!this.ctx || !this.engineGain) return;
		const ctx = this.ctx;
		this.osc = ctx.createOscillator();
		this.osc.type = "sawtooth";
		this.osc.frequency.value = 46;
		this.osc2 = ctx.createOscillator();
		this.osc2.type = "square";
		this.osc2.frequency.value = 23;
		this.osc3 = ctx.createOscillator();
		this.osc3.type = "triangle";
		this.osc3.frequency.value = 58;
		const g2 = ctx.createGain();
		g2.gain.value = .28;
		const g3 = ctx.createGain();
		g3.gain.value = .16;
		this.filter = ctx.createBiquadFilter();
		this.filter.type = "lowpass";
		this.filter.frequency.value = 380;
		this.filter.Q.value = 1.35;
		this.osc.connect(this.filter);
		this.osc2.connect(g2);
		g2.connect(this.filter);
		this.osc3.connect(g3);
		g3.connect(this.filter);
		this.filter.connect(this.engineGain);
		const nbuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
		const data = nbuf.getChannelData(0);
		for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
		this.noise = ctx.createBufferSource();
		this.noise.buffer = nbuf;
		this.noise.loop = true;
		this.noiseGain = ctx.createGain();
		this.noiseGain.gain.value = .05;
		const nfilt = ctx.createBiquadFilter();
		nfilt.type = "bandpass";
		nfilt.frequency.value = 180;
		nfilt.Q.value = .55;
		this.noise.connect(nfilt);
		nfilt.connect(this.noiseGain);
		this.noiseGain.connect(this.engineGain);
		this.wind = ctx.createGain();
		this.wind.gain.value = 0;
		const wfilt = ctx.createBiquadFilter();
		wfilt.type = "highpass";
		wfilt.frequency.value = 720;
		this.noise.connect(wfilt);
		wfilt.connect(this.wind);
		this.wind.connect(this.master);
		this.screech = ctx.createGain();
		this.screech.gain.value = 0;
		const sfilt = ctx.createBiquadFilter();
		sfilt.type = "bandpass";
		sfilt.frequency.value = 1280;
		sfilt.Q.value = 3.4;
		this.noise.connect(sfilt);
		sfilt.connect(this.screech);
		this.screech.connect(this.sfx);
		this.osc.start();
		this.osc2.start();
		this.osc3.start();
		this.noise.start();
		this.started = true;
	}
	setMuted(v) {
		this.muted = v;
		if (this.master) this.master.gain.setTargetAtTime(v ? 0 : .92, this.now(), .04);
	}
	now() {
		return this.ctx?.currentTime ?? 0;
	}
	update(opts) {
		if (!this.ctx || !this.started || !this.engineGain || !this.filter) return;
		const t = this.now();
		if (opts.paused) {
			this.engineGain.gain.setTargetAtTime(0, t, .08);
			this.screech?.gain.setTargetAtTime(0, t, .05);
			this.wind?.gain.setTargetAtTime(0, t, .08);
			return;
		}
		const rpm = opts.rpm;
		const f = (opts.ev ? 26 : 38) + rpm * (opts.ev ? .011 : .042) * opts.roar;
		this.osc?.frequency.setTargetAtTime(f, t, .035);
		this.osc2?.frequency.setTargetAtTime(f * .48 + 6, t, .045);
		this.osc3?.frequency.setTargetAtTime(f * 1.48, t, .05);
		this.filter.frequency.setTargetAtTime((opts.ev ? 540 : 240) + opts.throttle * 1900 + rpm * .4, t, .045);
		const vol = (opts.ev ? .04 : .16) + opts.throttle * (opts.ev ? .09 : .48) * opts.roar + Math.min(.16, Math.abs(opts.speed) * .0024);
		this.engineGain.gain.setTargetAtTime(vol, t, .05);
		this.noiseGain?.gain.setTargetAtTime(.07 + opts.throttle * .18 * opts.roar, t, .07);
		this.wind?.gain.setTargetAtTime(Math.min(.16, Math.abs(opts.speed) * .0024), t, .1);
		this.screech?.gain.setTargetAtTime(opts.drifting ? .16 + opts.throttle * .08 : 0, t, .05);
		if (!opts.ev && this.prevThrottle > .7 && opts.throttle < .2 && rpm > 3400 && t - this.lastPop > .22) {
			this.lastPop = t;
			this.pop();
			if (opts.roar > 1.2) window.setTimeout(() => this.pop(), 40);
		}
		this.prevThrottle = opts.throttle;
	}
	pop() {
		if (!this.ctx || !this.sfx) return;
		const ctx = this.ctx;
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		o.type = "square";
		o.frequency.value = 70 + Math.random() * 55;
		const g = ctx.createGain();
		g.gain.setValueAtTime(.26, t);
		g.gain.exponentialRampToValueAtTime(.001, t + .16);
		o.connect(g);
		g.connect(this.sfx);
		o.start(t);
		o.stop(t + .15);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
	horn() {
		if (!this.ctx || !this.sfx) return;
		const ctx = this.ctx;
		const t = ctx.currentTime;
		for (const f of [348, 438]) {
			const o = ctx.createOscillator();
			o.type = "square";
			o.frequency.value = f;
			const g = ctx.createGain();
			g.gain.setValueAtTime(1e-4, t);
			g.gain.exponentialRampToValueAtTime(.11, t + .02);
			g.gain.exponentialRampToValueAtTime(1e-4, t + .42);
			o.connect(g);
			g.connect(this.sfx);
			o.start(t);
			o.stop(t + .44);
		}
	}
	impact(strength) {
		if (!this.ctx || !this.sfx) return;
		const ctx = this.ctx;
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		o.type = "sawtooth";
		o.frequency.setValueAtTime(110, t);
		o.frequency.exponentialRampToValueAtTime(36, t + .2);
		const g = ctx.createGain();
		const v = clamp$2(.05 + strength * .05, .05, .2);
		g.gain.setValueAtTime(v, t);
		g.gain.exponentialRampToValueAtTime(.001, t + .22);
		o.connect(g);
		g.connect(this.sfx);
		o.start(t);
		o.stop(t + .24);
	}
	blip(freq = 880, dur = .12) {
		if (!this.ctx || !this.sfx) return;
		const ctx = this.ctx;
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		o.type = "triangle";
		o.frequency.value = freq;
		const g = ctx.createGain();
		g.gain.setValueAtTime(.08, t);
		g.gain.exponentialRampToValueAtTime(.001, t + dur);
		o.connect(g);
		g.connect(this.sfx);
		o.start(t);
		o.stop(t + dur + .02);
	}
	cash() {
		this.blip(720, .08);
		window.setTimeout(() => this.blip(980, .1), 80);
	}
	splash() {
		this.blip(220, .18);
	}
	chime() {
		this.blip(880, .1);
		window.setTimeout(() => this.blip(1320, .14), 90);
	}
	bark() {
		this.blip(180, .08);
		window.setTimeout(() => this.blip(140, .12), 70);
	}
	cheer() {
		this.blip(640, .07);
		window.setTimeout(() => this.blip(860, .09), 60);
		window.setTimeout(() => this.blip(1100, .1), 130);
	}
};
function dist(ax, az, bx, bz) {
	return Math.hypot(ax - bx, az - bz);
}
function pick(arr, except) {
	const pool = except === void 0 ? arr : arr.filter((x) => x !== except);
	return pool[Math.floor(Math.random() * pool.length)] ?? arr[0];
}
function nearestPoi(x, z, max = 11) {
	let best = null;
	let bestD = max;
	for (const p of POIS) {
		const d = dist(x, z, p.x, p.z);
		if (d < bestD) {
			bestD = d;
			best = p;
		}
	}
	return best;
}
function startJob(id, v) {
	const st = useGame.getState();
	if (st.job) {
		st.toastMsg("Előbb fejezd be a mostani fuvart.");
		return;
	}
	const meta = JOB_META[id];
	if (id === "taxi") {
		const dest = pick(TAXI_STOPS);
		const pax = pick(PASSENGERS);
		st.setJob({
			id,
			step: 0,
			title: meta.name,
			detail: `${pax.name} → ${dest.name}`,
			pay: 340 + Math.round(dist(v.x, v.z, dest.x, dest.z) * .95),
			targetX: dest.x,
			targetZ: dest.z,
			smoothness: 0,
			samples: 0,
			hits: 0,
			passenger: pax.name,
			passengerKind: pax.kind,
			jumpCheers: 0
		});
		st.setWaypoint({
			x: dest.x,
			z: dest.z,
			label: dest.name
		});
		st.toastMsg(`${pax.name} beszállt. ${pax.line}`);
	}
	if (id === "courier") {
		const dest = pick(COURIER_STOPS);
		st.setJob({
			id,
			step: 0,
			title: meta.name,
			detail: `Csomag célja: ${dest.name}`,
			pay: 400 + Math.round(dist(v.x, v.z, dest.x, dest.z) * 1.08),
			targetX: dest.x,
			targetZ: dest.z,
			smoothness: 0,
			samples: 0,
			hits: 0
		});
		st.setWaypoint({
			x: dest.x,
			z: dest.z,
			label: dest.name
		});
		st.toastMsg("Csomag a raktérben. Hajrá!");
	}
	if (id === "grandma") {
		const market = POI_BY_ID.market;
		st.setJob({
			id,
			step: 0,
			title: meta.name,
			detail: "Szedd össze a bevásárlást a piacon.",
			pay: 520,
			targetX: market.x,
			targetZ: market.z,
			smoothness: 0,
			samples: 0,
			hits: 0
		});
		st.setWaypoint({
			x: market.x,
			z: market.z,
			label: "Piac"
		});
		st.toastMsg("Ilonka néni várja a szatyrokat — és a kutyája is.");
	}
	if (id === "secret") {
		const dest = pick(COURIER_STOPS);
		const cargo = pick(SECRET_CARGO);
		st.setJob({
			id,
			step: 0,
			title: meta.name,
			detail: `Cél: ${dest.name}. Ne ütközz!`,
			pay: 1200 + Math.round(Math.random() * 600),
			targetX: dest.x,
			targetZ: dest.z,
			smoothness: 0,
			samples: 0,
			hits: 0
		});
		st.setWaypoint({
			x: dest.x,
			z: dest.z,
			label: dest.name
		});
		st.toastMsg(cargo);
	}
	if (id === "party") {
		const market = POI_BY_ID.market;
		st.setJob({
			id,
			step: 0,
			title: meta.name,
			detail: "Szedd a díszeket a piacon.",
			pay: 780,
			targetX: market.x,
			targetZ: market.z,
			smoothness: 0,
			samples: 0,
			hits: 0
		});
		st.setWaypoint({
			x: market.x,
			z: market.z,
			label: "Piac — díszek"
		});
		st.toastMsg("Buli lesz a főtéren. Először a díszek!");
	}
}
function tickJob(v, impact, dt) {
	const st = useGame.getState();
	const job = st.job;
	if (!job) return;
	job.samples += dt;
	job.smoothness += (Math.abs(v.speed) > 1 ? Math.abs(v.vx) * .02 + Math.abs(impact) : 0) * dt;
	if (impact > 4) job.hits += 1;
	if (job.passengerKind === "kid" && v.airborne && v.airTime > .35) job.jumpCheers = (job.jumpCheers ?? 0) + dt;
	if (dist(v.x, v.z, job.targetX, job.targetZ) < 10 && Math.abs(v.speed) < 4) {
		if (job.id === "grandma" && job.step === 0) {
			const home = POI_BY_ID.grandma;
			st.setJob({
				...job,
				step: 1,
				detail: "Vidd haza a szatyrokat Ilonka néninek.",
				targetX: home.x,
				targetZ: home.z
			});
			st.setWaypoint({
				x: home.x,
				z: home.z,
				label: "Ilonka néni"
			});
			st.toastMsg("Bevásárlás kész. Irány a néni!");
			return;
		}
		if (job.id === "party" && job.step === 0) {
			const taxi = POI_BY_ID.taxi;
			st.setJob({
				...job,
				step: 1,
				detail: "A vendégek a taxiállomáson várnak.",
				targetX: taxi.x,
				targetZ: taxi.z
			});
			st.setWaypoint({
				x: taxi.x,
				z: taxi.z,
				label: "Vendégek"
			});
			st.toastMsg("Díszek a csomagtartóban. Most a vendégek!");
			return;
		}
		if (job.id === "party" && job.step === 1) {
			const plaza = POI_BY_ID.party;
			const guest = pick(PARTY_GUESTS);
			st.setJob({
				...job,
				step: 2,
				detail: `${guest.name} a főtérre. ${guest.line}`,
				targetX: plaza.x,
				targetZ: plaza.z,
				passenger: guest.name,
				passengerKind: "kind" in guest ? guest.kind : "adult"
			});
			st.setWaypoint({
				x: plaza.x,
				z: plaza.z,
				label: "Főtér"
			});
			st.toastMsg(`${guest.name} beszállt. ${guest.line}`);
			return;
		}
		finishJob(v);
	}
}
function finishJob(v) {
	const st = useGame.getState();
	const job = st.job;
	if (!job) return;
	const car = CAR_BY_ID[st.currentCar];
	let pay = job.pay;
	if (job.id === "courier" && (car.body === "van" || car.body === "truck")) pay = Math.round(pay * 1.2);
	if (job.id === "taxi") {
		if (job.smoothness / Math.max(1, job.samples) < 1.8 && job.hits === 0) {
			const tip = Math.round(pay * .5);
			pay += tip;
			const who = job.passenger ?? "Az utas";
			st.toastMsg(`„Micsoda vezetés!” ${who} +${tip} Ft borravalót ad.`);
		} else if (job.hits === 0) st.toastMsg("Szép út, kellemes utas.");
		else {
			pay = Math.round(pay * .75);
			st.toastMsg("Kicsit rázós volt… kevesebb a borravaló.");
		}
		if ((job.jumpCheers ?? 0) > .4 && job.passengerKind === "kid") {
			pay += 180;
			st.toastMsg("„Még egyet a dombon!” A gyerek ujjong. +180 Ft");
		}
		if (car.id === "taxika" || car.body === "bus") pay = Math.round(pay * 1.15);
	}
	if (job.id === "secret") {
		if (job.hits === 0) {
			pay = Math.round(pay * 1.18);
			st.toastMsg("A csomag épségben. A megbízó elégedett.");
		} else {
			pay = Math.round(pay * .6);
			st.toastMsg("Túl rázós volt a szállítmány. Kevesebb a díj.");
		}
	}
	if (job.id === "grandma") st.toastMsg("Ilonka néni süteménnyel fizetett. Na jó, és készpénzzel is.");
	if (job.id === "party") st.toastMsg("A tér megtelt. A zene szól, a fagyi is megérkezett.");
	st.addMoney(pay);
	st.bumpStat("jobsDone");
	st.setJob(null);
	st.setWaypoint(null);
	st.toastMsg(`+${pay.toLocaleString("hu-HU")} Ft`);
}
function startChallenge(id, v) {
	const st = useGame.getState();
	if (st.challenge?.active) {
		st.toastMsg("Előbb fejezd be a kihívást — vagy menj tovább, lejár magától.");
		return;
	}
	if (st.job) {
		st.toastMsg("Fuvar közben a kihívás várhat.");
		return;
	}
	const meta = CHALLENGE_META[id];
	const base = {
		id,
		title: meta.name,
		active: true,
		done: false,
		t: 0,
		value: 0,
		detail: meta.desc
	};
	if (id === "drift") st.setChallenge({
		...base,
		t: 35,
		detail: "Driftelj 35 mp-ig a gyárban!"
	});
	if (id === "accel") {
		v.vx = v.vz = v.speed = 0;
		v.x = AIRPORT.x;
		v.z = AIRPORT.z + 62;
		v.yaw = 0;
		st.setChallenge({
			...base,
			detail: "Állj a piros vonalra… Gázt! Cél: 100 km/h"
		});
	}
	if (id === "topspeed") st.setChallenge({
		...base,
		t: 25,
		detail: "25 mp a kifutón — maxold a tempót!"
	});
	if (id === "jump") st.setChallenge({
		...base,
		t: 40,
		detail: "40 mp, gyűjts levegőben töltött időt!"
	});
	if (id === "circuit") {
		st.setChallenge({
			...base,
			value: 0,
			detail: `Kapu 1/${CIRCUIT_GATES.length}`
		});
		const g = CIRCUIT_GATES[0];
		st.setWaypoint({
			x: g.x,
			z: g.z,
			label: "Kapu 1"
		});
	}
	st.toastMsg(meta.name + " indul!");
}
function tickChallenge(v, drifting, dt) {
	const st = useGame.getState();
	const c = st.challenge;
	if (!c || !c.active) return;
	c.t += dt;
	if (c.id === "drift") {
		if (drifting) c.value += (8 + Math.abs(v.speed) * .4) * dt;
		const left = 35 - c.t;
		c.detail = `Drift: ${Math.round(c.value)} · ${Math.max(0, left).toFixed(1)} mp`;
		if (left <= 0) completeChallenge(c.id, c.value, [
			80,
			160,
			260
		]);
	}
	if (c.id === "accel") {
		const kmh = Math.abs(v.speed) * 3.6;
		c.detail = `${kmh.toFixed(0)} km/h · ${c.t.toFixed(2)} mp`;
		if (kmh >= 100) completeChallenge(c.id, c.t, [
			4.8,
			3.6,
			2.7
		], true);
		if (c.t > 12) completeChallenge(c.id, 12, [
			4.8,
			3.6,
			2.7
		], true);
	}
	if (c.id === "topspeed") {
		const kmh = Math.abs(v.speed) * 3.6;
		c.value = Math.max(c.value, kmh);
		c.detail = `Csúcs: ${c.value.toFixed(0)} km/h · ${Math.max(0, 25 - c.t).toFixed(0)} mp`;
		if (c.t >= 25) completeChallenge(c.id, c.value, [
			140,
			180,
			230
		]);
	}
	if (c.id === "jump") {
		if (v.airborne) c.value += dt;
		c.detail = `Levegő: ${c.value.toFixed(1)} mp · ${Math.max(0, 40 - c.t).toFixed(0)} mp`;
		if (c.t >= 40) completeChallenge(c.id, c.value, [
			1.2,
			2.4,
			3.6
		]);
	}
	if (c.id === "circuit") {
		const i = Math.floor(c.value);
		const g = CIRCUIT_GATES[i];
		if (g && dist(v.x, v.z, g.x, g.z) < 12) {
			c.value += 1;
			const n = CIRCUIT_GATES[Math.floor(c.value)];
			if (n) {
				st.setWaypoint({
					x: n.x,
					z: n.z,
					label: `Kapu ${Math.floor(c.value) + 1}`
				});
				c.detail = `Kapu ${Math.floor(c.value) + 1}/${CIRCUIT_GATES.length} · ${c.t.toFixed(1)} mp`;
			} else completeChallenge(c.id, c.t, [
				95,
				70,
				50
			], true);
		} else c.detail = `Kapu ${i + 1}/${CIRCUIT_GATES.length} · ${c.t.toFixed(1)} mp`;
	}
	st.setChallenge({ ...c });
}
function completeChallenge(id, value, thresholds, lowerIsBetter = false) {
	let stars = 0;
	if (lowerIsBetter) {
		if (value <= thresholds[0]) stars = 1;
		if (value <= thresholds[1]) stars = 2;
		if (value <= thresholds[2]) stars = 3;
	} else {
		if (value >= thresholds[0]) stars = 1;
		if (value >= thresholds[1]) stars = 2;
		if (value >= thresholds[2]) stars = 3;
	}
	const pay = [
		0,
		420,
		780,
		1400
	][stars] ?? 0;
	const st = useGame.getState();
	st.setStars(id, stars);
	if (pay) st.addMoney(pay);
	st.setChallenge(null);
	st.setWaypoint(null);
	const starTxt = stars ? `${stars} csillag` : "Ezúttal nem jött össze";
	st.toastMsg(`${CHALLENGE_META[id].name}: ${starTxt}${pay ? ` · +${pay} Ft` : ""}`);
	if (Object.keys(CHALLENGE_META).every((k) => (st.stars[k] ?? 0) >= 3) && !st.champion) {
		st.setChampion();
		st.toastMsg("Bajnok! Minden kihívás 3 csillag. +8000 Ft a kasszába.");
	}
}
function tryInteract(v, poi, fishingOk) {
	const st = useGame.getState();
	if (st.job && dist(v.x, v.z, st.job.targetX, st.job.targetZ) < 10) return null;
	if (st.job) return null;
	if (fishingOk && Math.abs(v.speed) < 1.2) return "fishing";
	if (!poi) return null;
	if (poi.id === "garage") return "garage";
	if (poi.id === "dealer") return "dealer";
	if (poi.id === "fagyi") return "fagyi";
	if (poi.id === "hidden" && !st.foundSecret && Math.abs(v.speed) < 4) return "hidden";
	if (poi.id === "taxi") startJob("taxi", v);
	if (poi.id === "courier") startJob("courier", v);
	if (poi.id === "market") startJob("grandma", v);
	if (poi.id === "secret") startJob("secret", v);
	if (poi.id === "party") startJob("party", v);
	if (poi.id === "drift") startChallenge("drift", v);
	if (poi.id === "accel") startChallenge("accel", v);
	if (poi.id === "topspeed") startChallenge("topspeed", v);
	if (poi.id === "jump") startChallenge("jump", v);
	if (poi.id === "circuit") startChallenge("circuit", v);
	return null;
}
function promptFor(poi, fishingOk, parked, _job) {
	if (fishingOk && parked) return "Pecázás  ·  E";
	if (!poi) return null;
	switch (poi.id) {
		case "garage": return "Műhely  ·  E";
		case "dealer": return "Kereskedés  ·  E";
		case "taxi": return "Taxi fuvar  ·  E";
		case "courier": return "Futárkodás  ·  E";
		case "market": return "Bevásárlás néninek  ·  E";
		case "secret": return "Titkos futár  ·  E";
		case "party": return "Buli szervezés  ·  E";
		case "drift": return "Gyári drift  ·  E";
		case "accel": return "Reptéri gyorsulás  ·  E";
		case "topspeed": return "Végsebesség  ·  E";
		case "jump": return "Ugrató kihívás  ·  E";
		case "circuit": return "Városi időfutam  ·  E";
		case "hidden": return useGame.getState().foundSecret ? null : "Valami csillog  ·  E";
		case "statue": return "Dudálj háromszor";
		case "fishing": return parked ? "Pecázás  ·  E" : "Állj meg a stégen";
		case "fagyi": return parked ? "Fagyi  ·  E" : "Állj meg a fagyisnál";
		default: return poi.hint;
	}
}
function tryViewpoint(x, z, parked) {
	if (!parked) return null;
	for (const v of VIEWPOINTS) if (dist(x, z, v.x, v.z) < 16) return v.id;
	return null;
}
function viewName(id) {
	return VIEWPOINTS.find((v) => v.id === id)?.name ?? id;
}
var STEP = 38;
var LINK = 42;
var NavGraph = class {
	pts = [];
	adj = [];
	constructor(roads) {
		const raw = [];
		for (const r of roads) {
			const dx = r.bx - r.ax;
			const dz = r.bz - r.az;
			const n = Math.max(1, Math.round((Math.hypot(dx, dz) || 1) / STEP));
			for (let i = 0; i <= n; i++) {
				const t = i / n;
				raw.push({
					x: r.ax + dx * t,
					z: r.az + dz * t
				});
			}
		}
		const pts = [];
		for (const p of raw) {
			if (pts.some((q) => Math.hypot(q.x - p.x, q.z - p.z) < 14)) continue;
			pts.push(p);
		}
		this.pts = pts;
		const n = pts.length;
		this.adj = Array.from({ length: n }, () => []);
		for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (Math.hypot(pts[i].x - pts[j].x, pts[i].z - pts[j].z) < LINK) {
			this.adj[i].push(j);
			this.adj[j].push(i);
		}
	}
	nearest(x, z) {
		let best = 0;
		let bd = 1e9;
		for (let i = 0; i < this.pts.length; i++) {
			const d = Math.hypot(this.pts[i].x - x, this.pts[i].z - z);
			if (d < bd) {
				bd = d;
				best = i;
			}
		}
		return best;
	}
	path(ax, az, bx, bz) {
		const n = this.pts.length;
		if (!n) return [{
			x: bx,
			z: bz
		}];
		const s = this.nearest(ax, az);
		const g = this.nearest(bx, bz);
		if (s === g) return [{
			x: bx,
			z: bz
		}];
		const dist = new Float32Array(n).fill(1e9);
		const prev = new Int32Array(n).fill(-1);
		const used = new Uint8Array(n);
		dist[s] = 0;
		for (let k = 0; k < n; k++) {
			let u = -1;
			let best = 1e9;
			for (let i = 0; i < n; i++) if (!used[i] && dist[i] < best) {
				best = dist[i];
				u = i;
			}
			if (u < 0 || u === g) break;
			used[u] = 1;
			for (const v of this.adj[u]) {
				const d = dist[u] + Math.hypot(this.pts[u].x - this.pts[v].x, this.pts[u].z - this.pts[v].z);
				if (d < dist[v]) {
					dist[v] = d;
					prev[v] = u;
				}
			}
		}
		if (prev[g] < 0 && s !== g) return [{
			x: ax,
			z: az
		}, {
			x: bx,
			z: bz
		}];
		const chain = [{
			x: bx,
			z: bz
		}];
		let cur = g;
		const guard = n + 2;
		let hops = 0;
		while (cur !== s && hops++ < guard) {
			chain.push(this.pts[cur]);
			cur = prev[cur];
			if (cur < 0) break;
		}
		chain.push({
			x: ax,
			z: az
		});
		chain.reverse();
		return chain;
	}
};
function densify(path, spacing = 9) {
	const out = [];
	for (let i = 0; i < path.length - 1; i++) {
		const a = path[i];
		const b = path[i + 1];
		const len = Math.hypot(b.x - a.x, b.z - a.z) || 1;
		const n = Math.max(1, Math.round(len / spacing));
		for (let k = 0; k < n; k++) {
			const t = k / n;
			out.push({
				x: a.x + (b.x - a.x) * t,
				z: a.z + (b.z - a.z) * t
			});
		}
	}
	if (path.length) out.push(path[path.length - 1]);
	return out;
}
var SkidTrail = class {
	mesh;
	next = 0;
	n = 220;
	dummy = new Object3D();
	cooldown = 0;
	constructor(scene) {
		const geo = new PlaneGeometry(.26, 1.05);
		geo.rotateX(-Math.PI / 2);
		const mat = new MeshBasicMaterial({
			color: 1447706,
			transparent: true,
			opacity: .42,
			depthWrite: false
		});
		this.mesh = new InstancedMesh(geo, mat, this.n);
		this.mesh.frustumCulled = false;
		this.dummy.position.set(0, -40, 0);
		this.dummy.scale.setScalar(0);
		this.dummy.updateMatrix();
		for (let i = 0; i < this.n; i++) this.mesh.setMatrixAt(i, this.dummy.matrix);
		scene.add(this.mesh);
	}
	emit(x, y, z, yaw, dt, drifting, speed) {
		this.cooldown -= dt;
		if (!drifting || Math.abs(speed) < 8 || this.cooldown > 0) return;
		this.cooldown = .032;
		const i = this.next++ % this.n;
		this.dummy.position.set(x, y + .035, z);
		this.dummy.rotation.set(0, yaw, 0);
		this.dummy.scale.set(1, 1, 1);
		this.dummy.updateMatrix();
		this.mesh.setMatrixAt(i, this.dummy.matrix);
		this.mesh.instanceMatrix.needsUpdate = true;
	}
};
function hash2(x, z) {
	const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
	return n - Math.floor(n);
}
function hash3(x, z, s) {
	const n = Math.sin(x * 269.5 + z * 183.3 + s * 91.7) * 23421.631;
	return n - Math.floor(n);
}
function fade(t) {
	return t * t * (3 - 2 * t);
}
function valueNoise(x, z) {
	const x0 = Math.floor(x);
	const z0 = Math.floor(z);
	const fx = fade(x - x0);
	const fz = fade(z - z0);
	const a = hash2(x0, z0);
	const b = hash2(x0 + 1, z0);
	const c = hash2(x0, z0 + 1);
	const d = hash2(x0 + 1, z0 + 1);
	return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
}
function fbm(x, z, oct = 4) {
	let v = 0;
	let a = .5;
	let f = 1;
	let s = 0;
	for (let i = 0; i < oct; i++) {
		v += valueNoise(x * f, z * f) * a;
		s += a;
		a *= .5;
		f *= 2.03;
	}
	return v / s;
}
function makeCanvas(size) {
	const c = document.createElement("canvas");
	c.width = c.height = size;
	return {
		c,
		ctx: c.getContext("2d")
	};
}
function noiseFill(ctx, size, base, amp) {
	const img = ctx.createImageData(size, size);
	const d = img.data;
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const n = (x * 13 + y * 31) % 17 / 17 * .35 + (x * 7 + y * 17) % 11 / 11 * .25 + Math.random() * .4;
		const i = (y * size + x) * 4;
		d[i] = base[0] + (n - .5) * amp;
		d[i + 1] = base[1] + (n - .5) * amp;
		d[i + 2] = base[2] + (n - .5) * amp;
		d[i + 3] = 255;
	}
	ctx.putImageData(img, 0, 0);
}
function groundNoiseTexture() {
	const { c, ctx } = makeCanvas(128);
	noiseFill(ctx, 128, [
		236,
		234,
		228
	], 18);
	const tex = new CanvasTexture(c);
	tex.wrapS = tex.wrapT = RepeatWrapping;
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
function facadeTexture() {
	const { c, ctx } = makeCanvas(256);
	ctx.fillStyle = "#f4f1ea";
	ctx.fillRect(0, 0, 256, 256);
	ctx.fillStyle = "#d9d3c8";
	ctx.fillRect(0, 168, 256, 88);
	for (let y = 12; y < 160; y += 32) for (let x = 14; x < 246; x += 28) {
		const lit = (x * 3 + y * 5) % 17 > 7;
		ctx.fillStyle = "#8a8176";
		ctx.fillRect(x - 2, y - 2, 18, 22);
		ctx.fillStyle = lit ? "#f3e2b0" : "#2a3340";
		ctx.fillRect(x, y, 14, 18);
	}
	for (let x = 18; x < 240; x += 36) {
		ctx.fillStyle = "#6a8ea3";
		ctx.fillRect(x, 186, 22, 36);
		ctx.fillStyle = "#3a4048";
		ctx.fillRect(x + 6, 222, 10, 28);
	}
	const tex = new CanvasTexture(c);
	tex.wrapS = tex.wrapT = RepeatWrapping;
	tex.colorSpace = SRGBColorSpace;
	tex.repeat.set(1, 2);
	return tex;
}
function waterTexture() {
	const { c, ctx } = makeCanvas(256);
	const g = ctx.createLinearGradient(0, 0, 256, 256);
	g.addColorStop(0, "#1e5870");
	g.addColorStop(1, "#2a6d82");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, 256, 256);
	ctx.strokeStyle = "rgba(190,230,235,0.22)";
	ctx.lineWidth = 2;
	for (let i = 0; i < 20; i++) {
		ctx.beginPath();
		const y = 8 + i * 13;
		ctx.moveTo(0, y);
		for (let x = 0; x <= 256; x += 12) ctx.lineTo(x, y + Math.sin(x * .05 + i * .7) * 5);
		ctx.stroke();
	}
	const tex = new CanvasTexture(c);
	tex.wrapS = tex.wrapT = RepeatWrapping;
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
function houseFacadeTexture() {
	const { c, ctx } = makeCanvas(128);
	ctx.fillStyle = "#c8b49a";
	ctx.fillRect(0, 0, 128, 128);
	ctx.fillStyle = "#6a8aa0";
	ctx.fillRect(18, 28, 28, 32);
	ctx.fillRect(82, 28, 28, 32);
	ctx.fillStyle = "#5a3a30";
	ctx.fillRect(52, 58, 24, 50);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
function poiLabelTexture(text, color) {
	const c = document.createElement("canvas");
	c.width = 256;
	c.height = 64;
	const ctx = c.getContext("2d");
	ctx.clearRect(0, 0, 256, 64);
	ctx.fillStyle = "rgba(9,10,12,0.82)";
	roundRect(ctx, 4, 8, 248, 48, 12);
	ctx.fill();
	ctx.strokeStyle = color;
	ctx.lineWidth = 2;
	roundRect(ctx, 4, 8, 248, 48, 12);
	ctx.stroke();
	ctx.fillStyle = "#f1f2f4";
	ctx.font = "600 22px Barlow, Segoe UI, sans-serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText(text, 128, 34);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
function shopFacadeTexture() {
	const { c, ctx } = makeCanvas(256);
	ctx.fillStyle = "#f7f3ea";
	ctx.fillRect(0, 0, 256, 256);
	ctx.fillStyle = "#efe6d4";
	ctx.fillRect(0, 0, 256, 70);
	const awnings = [
		"#c45c3a",
		"#3d5c7a",
		"#5a6b3a",
		"#e8b86d"
	];
	for (let i = 0; i < 4; i++) {
		ctx.fillStyle = awnings[i % awnings.length];
		ctx.fillRect(8 + i * 62, 62, 54, 18);
		ctx.fillStyle = "#b9d4e2";
		ctx.fillRect(12 + i * 62, 88, 46, 58);
		ctx.fillStyle = "rgba(255,255,255,0.35)";
		ctx.fillRect(16 + i * 62, 92, 10, 48);
		ctx.fillStyle = "#2a2c30";
		ctx.fillRect(22 + i * 62, 156, 26, 78);
	}
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.wrapS = tex.wrapT = RepeatWrapping;
	return tex;
}
function brickFacadeTexture() {
	const { c, ctx } = makeCanvas(256);
	ctx.fillStyle = "#f3e4d8";
	ctx.fillRect(0, 0, 256, 256);
	for (let y = 0; y < 256; y += 16) {
		const off = y / 16 % 2 === 0 ? 0 : 16;
		for (let x = -16; x < 256; x += 32) {
			ctx.fillStyle = (x + y) * 13 % 17 > 8 ? "#fff6ee" : "#e7cbb8";
			ctx.fillRect(x + off + 1, y + 1, 28, 13);
		}
	}
	for (let y = 28; y < 230; y += 40) for (let x = 18; x < 240; x += 44) {
		ctx.fillStyle = "#c8b49a";
		ctx.fillRect(x - 3, y - 3, 24, 30);
		ctx.fillStyle = (x * 3 + y) % 11 > 5 ? "#f6e7b8" : "#314050";
		ctx.fillRect(x, y, 18, 24);
	}
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.wrapS = tex.wrapT = RepeatWrapping;
	return tex;
}
function glassFacadeTexture() {
	const { c, ctx } = makeCanvas(256);
	ctx.fillStyle = "#e7eef4";
	ctx.fillRect(0, 0, 256, 256);
	for (let y = 6; y < 250; y += 20) {
		ctx.fillStyle = "#c5d0da";
		ctx.fillRect(0, y, 256, 3);
		for (let x = 6; x < 250; x += 18) {
			const lit = (x * 7 + y * 13) % 11 > 6;
			ctx.fillStyle = "#b7c6d2";
			ctx.fillRect(x, y + 3, 2, 16);
			ctx.fillStyle = lit ? "#f7f1dc" : "#8eafc4";
			ctx.fillRect(x + 2, y + 4, 12, 14);
		}
	}
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.wrapS = tex.wrapT = RepeatWrapping;
	return tex;
}
function shopSignTexture(label, bg) {
	const c = document.createElement("canvas");
	c.width = 256;
	c.height = 96;
	const ctx = c.getContext("2d");
	ctx.fillStyle = bg;
	ctx.fillRect(0, 0, 256, 96);
	ctx.fillStyle = "rgba(255,255,255,0.18)";
	ctx.fillRect(0, 0, 256, 10);
	ctx.fillStyle = "#f7f4ee";
	ctx.font = "700 52px Barlow, Segoe UI, sans-serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText(label, 128, 52);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
function signTexture(kind) {
	const { c, ctx } = makeCanvas(128);
	ctx.clearRect(0, 0, 128, 128);
	if (kind === "stop") {
		ctx.fillStyle = "#c02820";
		ctx.beginPath();
		for (let i = 0; i < 8; i++) {
			const a = Math.PI / 8 + i * Math.PI / 4;
			const x = 64 + Math.cos(a) * 54;
			const y = 64 + Math.sin(a) * 54;
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		}
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "#f1f2f4";
		ctx.font = "bold 28px Barlow, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText("STOP", 64, 66);
	} else if (kind === "yield") {
		ctx.fillStyle = "#c02820";
		ctx.beginPath();
		ctx.moveTo(64, 118);
		ctx.lineTo(12, 18);
		ctx.lineTo(116, 18);
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "#f1f2f4";
		ctx.beginPath();
		ctx.moveTo(64, 100);
		ctx.lineTo(28, 30);
		ctx.lineTo(100, 30);
		ctx.closePath();
		ctx.fill();
	} else if (kind === "speed") {
		ctx.fillStyle = "#f1f2f4";
		roundRect(ctx, 22, 8, 84, 112, 12);
		ctx.fill();
		ctx.strokeStyle = "#c02820";
		ctx.lineWidth = 8;
		roundRect(ctx, 22, 8, 84, 112, 12);
		ctx.stroke();
		ctx.fillStyle = "#1a1c20";
		ctx.font = "bold 42px Barlow, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText("50", 64, 64);
	} else if (kind === "cross") {
		ctx.fillStyle = "#1e4d8c";
		ctx.beginPath();
		ctx.arc(64, 64, 54, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#f1f2f4";
		ctx.fillRect(56, 22, 16, 44);
		ctx.beginPath();
		ctx.arc(64, 22, 10, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillRect(44, 44, 40, 10);
		ctx.fillRect(50, 54, 10, 40);
		ctx.fillRect(68, 54, 10, 40);
	} else {
		ctx.fillStyle = "#c02820";
		ctx.beginPath();
		ctx.arc(64, 64, 54, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#f1f2f4";
		ctx.fillRect(22, 56, 84, 16);
	}
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
function roundRect(ctx, x, y, w, h, r) {
	const rr = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + rr, y);
	ctx.arcTo(x + w, y, x + w, y + h, rr);
	ctx.arcTo(x + w, y + h, x, y + h, rr);
	ctx.arcTo(x, y + h, x, y, rr);
	ctx.arcTo(x, y, x + w, y, rr);
	ctx.closePath();
}
var RES = 168;
var SIZE = 960;
function biomeAt(x, z) {
	const r = Math.hypot(x, z);
	if (r < 138) return "city";
	if (r < 188) return "suburb";
	if (z < -210 && Math.abs(x) < 300) return "desert";
	if (x < -210) return "forest";
	if (x > 210) return "country";
	if (z > 250) return "coast";
	return "hills";
}
function biomeLabel(b) {
	switch (b) {
		case "city": return "Belváros";
		case "suburb": return "Külváros";
		case "forest": return "Erdő";
		case "desert": return "Sivatag";
		case "country": return "Mező";
		case "coast": return "Part";
		default: return "Dombvidék";
	}
}
var World = class {
	group = new Group();
	roads = [];
	buildings = [];
	trees = [];
	height = /* @__PURE__ */ new Float32Array(28561);
	waterY = 1.35;
	lake = {
		x: -20,
		z: 400,
		r: 88
	};
	waterMesh = null;
	clouds = null;
	windmillBlades = null;
	hiddenMesh = null;
	nav;
	sidewalks = [];
	signalRed = null;
	signalGreen = null;
	tmp = new Vector3();
	rdRes = 112;
	rdDist;
	rdW;
	constructor() {
		this.buildRoads();
		this.nav = new NavGraph(this.roads);
		this.bakeRoadField();
		this.buildHeight();
		this.group.add(this.makeTerrain());
		this.group.add(this.makeWater());
		this.group.add(this.makeSky());
		this.makeRoadMarks();
		this.placeCity();
		this.placeSkyline();
		this.placeParks();
		this.placeStreetFurniture();
		this.placeCityDetails();
		this.placeSuburb();
		this.placeNature();
		this.placeFactory();
		this.placeAirport();
		this.placeLandmarks();
		this.placePois();
		this.placeClouds();
		this.tmp;
	}
	addRoad(ax, az, bx, bz, width) {
		this.roads.push({
			ax,
			az,
			bx,
			bz,
			width
		});
	}
	addCurve(ax, az, cx, cz, bx, bz, width, segs = 7) {
		let px = ax;
		let pz = az;
		for (let i = 1; i <= segs; i++) {
			const t = i / segs;
			const mt = 1 - t;
			const x = mt * mt * ax + 2 * mt * t * cx + t * t * bx;
			const z = mt * mt * az + 2 * mt * t * cz + t * t * bz;
			this.addRoad(px, pz, x, z, width);
			px = x;
			pz = z;
		}
	}
	buildRoads() {
		const H = 480;
		this.addCurve(0, -480, 52, -340, -14, -200, 20, 7);
		this.addCurve(-14, -200, -40, -140, 0, -90, 20, 5);
		this.addRoad(0, -90, 0, -30, 20);
		this.addRoad(0, 30, 0, 90, 20);
		this.addCurve(0, 90, -30, 210, 10, 330, 18, 6);
		this.addCurve(10, 330, 18, 410, 0, H, 16, 4);
		this.addCurve(-480, 0, -310, 44, -180, -10, 18, 6);
		this.addCurve(-180, -10, -122, -24, -90, 0, 18, 4);
		this.addRoad(-90, 0, -30, 0, 20);
		this.addRoad(30, 0, 90, 0, 20);
		this.addCurve(90, 0, 168, -32, 286, 12, 16, 6);
		this.addCurve(286, 12, 386, -16, H, 8, 16, 5);
		const rr = 28;
		const rn = 24;
		for (let i = 0; i < rn; i++) {
			const t0 = i / rn * Math.PI * 2;
			const t1 = (i + 1) / rn * Math.PI * 2;
			this.addRoad(Math.cos(t0) * rr, Math.sin(t0) * rr, Math.cos(t1) * rr, Math.sin(t1) * rr, 14);
		}
		const n = 40;
		for (let i = 0; i < n; i++) {
			const t0 = i / n * Math.PI * 2;
			const t1 = (i + 1) / n * Math.PI * 2;
			const rx0 = 168 * (1 + Math.sin(t0 * 2) * .09);
			const rz0 = 182 * (1 + Math.cos(t0 * 3) * .07);
			const rx1 = 168 * (1 + Math.sin(t1 * 2) * .09);
			const rz1 = 182 * (1 + Math.cos(t1 * 3) * .07);
			this.addRoad(Math.cos(t0) * rx0, Math.sin(t0) * rz0, Math.cos(t1) * rx1, Math.sin(t1) * rz1, 14);
		}
		for (let i = -4; i <= 4; i++) {
			if (i === 0) continue;
			const bulge = (i % 2 === 0 ? 1 : -1) * (34 + Math.abs(i) * 5);
			const y = i * 28;
			const w = i % 2 === 0 ? 12 : 9;
			this.addCurve(-126, y, -48, y + bulge, 6, y - bulge * .38, w, 6);
			this.addCurve(6, y - bulge * .38, 58, y + bulge * .48, 126, y, w, 5);
			const x = i * 28;
			this.addCurve(x, -126, x + bulge, -42, x - bulge * .32, 8, 9, 6);
			this.addCurve(x - bulge * .32, 8, x + bulge * .42, 72, x, 126, 9, 5);
		}
		this.addCurve(-120, 120, -18, 38, 112, -104, 16, 8);
		this.addCurve(-108, -92, 12, -8, 102, 112, 12, 7);
		this.addCurve(PLAZA.x - 40, PLAZA.z + 22, PLAZA.x, PLAZA.z - 18, PLAZA.x + 42, PLAZA.z + 14, 11, 6);
		this.addCurve(-170, 40, -222, 80, FACTORY.x + 20, FACTORY.z - 10, 12, 6);
		const dr = 38;
		for (let i = 0; i < 20; i++) {
			const t0 = i / 20 * Math.PI * 2;
			const t1 = (i + 1) / 20 * Math.PI * 2;
			this.addRoad(FACTORY.x + Math.cos(t0) * dr, FACTORY.z + Math.sin(t0) * 26, FACTORY.x + Math.cos(t1) * dr, FACTORY.z + Math.sin(t1) * 26, 11);
		}
		this.addCurve(8, -220, 54, -308, AIRPORT.x, AIRPORT.z + 70, 16, 6);
		this.addRoad(AIRPORT.x, AIRPORT.z + 78, AIRPORT.x, AIRPORT.z - 78, 22);
		this.addRoad(AIRPORT.x - 28, AIRPORT.z + 20, AIRPORT.x + 40, AIRPORT.z + 20, 10);
		this.addCurve(220, 18, 340, 8, 460, 22, 14, 5);
		this.addCurve(-18, -220, -8, -340, -18, -470, 16, 5);
		this.addRoad(70, 250, 110, 360, 10);
		this.addRoad(-36, 340, -36, 430, 8);
		this.addRoad(20, 300, 70, 360, 8);
	}
	bakeRoadField() {
		const R = this.rdRes;
		const n = (R + 1) * (R + 1);
		this.rdDist = new Float32Array(n);
		this.rdW = new Float32Array(n);
		for (let iz = 0; iz <= R; iz++) for (let ix = 0; ix <= R; ix++) {
			const x = ix / R * SIZE - 480;
			const z = iz / R * SIZE - 480;
			const d = this.distToRoadRaw(x, z);
			const i = iz * (R + 1) + ix;
			this.rdDist[i] = d.dist;
			this.rdW[i] = d.width;
		}
	}
	distToRoadRaw(x, z) {
		let best = 1e9;
		let w = 8;
		for (const r of this.roads) {
			const dx = r.bx - r.ax;
			const dz = r.bz - r.az;
			const len2 = dx * dx + dz * dz || 1;
			let t = ((x - r.ax) * dx + (z - r.az) * dz) / len2;
			t = Math.max(0, Math.min(1, t));
			const d = Math.hypot(x - (r.ax + dx * t), z - (r.az + dz * t));
			if (d < best) {
				best = d;
				w = r.width;
			}
		}
		return {
			dist: best,
			width: w
		};
	}
	distToRoad(x, z) {
		const u = (x + 480) / SIZE * this.rdRes;
		const v = (z + 480) / SIZE * this.rdRes;
		const x0 = Math.max(0, Math.min(this.rdRes - 1, Math.floor(u)));
		const z0 = Math.max(0, Math.min(this.rdRes - 1, Math.floor(v)));
		const fx = u - x0;
		const fz = v - z0;
		const i = (zz, xx) => zz * (this.rdRes + 1) + xx;
		const d00 = this.rdDist[i(z0, x0)];
		const d10 = this.rdDist[i(z0, x0 + 1)];
		const d01 = this.rdDist[i(z0 + 1, x0)];
		const d11 = this.rdDist[i(z0 + 1, x0 + 1)];
		return {
			dist: d00 * (1 - fx) * (1 - fz) + d10 * fx * (1 - fz) + d01 * (1 - fx) * fz + d11 * fx * fz,
			width: this.rdW[i(z0, x0)]
		};
	}
	onRoad(x, z) {
		const d = this.distToRoad(x, z);
		return d.dist < d.width * .55;
	}
	rawHeight(x, z) {
		const b = biomeAt(x, z);
		let h = (fbm(x * .007, z * .007, 5) - .5) * 10;
		h += (fbm(x * .02, z * .02, 3) - .5) * 3.2;
		if (b === "city") h *= .08;
		if (b === "suburb") h *= .25;
		if (b === "desert") {
			h += Math.abs(Math.sin(x * .028 + z * .01)) * 7.5;
			h += (fbm(x * .015, z * .015) - .4) * 4;
		}
		if (b === "forest") h += (fbm(x * .012, z * .012) - .4) * 9;
		if (b === "country") h += Math.sin(x * .01) * 1.4;
		if (b === "coast" || b === "hills") h += (fbm(x * .01, z * .01) - .35) * 12;
		const lake = Math.hypot(x - this.lake.x, z - this.lake.z);
		if (lake < this.lake.r + 24) {
			const k = clamp01((this.lake.r + 24 - lake) / 40);
			h = h * (1 - k) - 3.2 * k;
		}
		const ramp1 = Math.hypot(x - 96, z - 300);
		if (ramp1 < 28) h += (1 - ramp1 / 28) * 9 * (z > 290 ? 1 : .4);
		const ramp2 = Math.hypot(x - 70, z - 340);
		if (ramp2 < 22) h += (1 - ramp2 / 22) * 7;
		const fac = Math.hypot(x - FACTORY.x, z - FACTORY.z);
		if (fac < 70) h *= 1 - .92 * (1 - fac / 70);
		const air = Math.hypot(x - AIRPORT.x, z - AIRPORT.z);
		if (air < 95) h *= 1 - .94 * (1 - air / 95);
		if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < 22) h *= .15;
		const rd = this.distToRoad(x, z);
		if (rd.dist < rd.width * .7) {
			const k = 1 - rd.dist / (rd.width * .7);
			h *= 1 - .85 * k;
		}
		return h;
	}
	buildHeight() {
		for (let iz = 0; iz <= RES; iz++) for (let ix = 0; ix <= RES; ix++) {
			const x = ix / RES * SIZE - 480;
			const z = iz / RES * SIZE - 480;
			this.height[iz * 169 + ix] = this.rawHeight(x, z);
		}
	}
	heightAt(x, z) {
		const u = (x + 480) / SIZE * RES;
		const v = (z + 480) / SIZE * RES;
		const x0 = Math.max(0, Math.min(167, Math.floor(u)));
		const z0 = Math.max(0, Math.min(167, Math.floor(v)));
		const fx = u - x0;
		const fz = v - z0;
		const i = (zz, xx) => this.height[zz * 169 + xx];
		return i(z0, x0) * (1 - fx) * (1 - fz) + i(z0, x0 + 1) * fx * (1 - fz) + i(z0 + 1, x0) * (1 - fx) * fz + i(z0 + 1, x0 + 1) * fx * fz;
	}
	inWater(x, z) {
		return Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r - 4 && this.heightAt(x, z) < this.waterY - .2;
	}
	nearShore(x, z) {
		const d = Math.hypot(x - this.lake.x, z - this.lake.z);
		return d < this.lake.r + 14 && d > this.lake.r - 18 && !this.inWater(x, z);
	}
	makeTerrain() {
		const geo = new PlaneGeometry(SIZE, SIZE, RES, RES);
		geo.rotateX(-Math.PI / 2);
		const pos = geo.attributes.position;
		const cols = new Float32Array(pos.count * 3);
		const c = new Color();
		for (let i = 0; i < pos.count; i++) {
			const x = pos.getX(i);
			const z = pos.getZ(i);
			const y = this.heightAt(x, z);
			pos.setY(i, y);
			const b = biomeAt(x, z);
			const rd = this.distToRoad(x, z);
			const n = (hash2(Math.floor(x), Math.floor(z)) - .5) * .08;
			if (rd.dist < rd.width * .52) c.setRGB(.15 + n, .16 + n, .18 + n);
			else if (rd.dist < rd.width * .52 + 2.4 && b === "city") c.setRGB(.52 + n, .52 + n, .5 + n);
			else if (rd.dist < rd.width * .7) c.setRGB(.4 + n, .4 + n, .41 + n);
			else if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 62) c.setRGB(.28 + n, .27 + n, .25 + n);
			else if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 88) c.setRGB(.22 + n, .23 + n, .24 + n);
			else if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < 20) c.setRGB(.28 + n, .48 + n, .3 + n);
			else if (b === "city") {
				const cell = hash2(Math.floor(x / 16), Math.floor(z / 16));
				if (cell > .78) c.setRGB(.3 + n, .48 + n, .28 + n);
				else if (cell > .52) c.setRGB(.62 + n, .56 + n, .46 + n);
				else c.setRGB(.46 + n, .46 + n, .48 + n);
			} else if (b === "suburb") c.setRGB(.36 + n, .48 + n, .3 + n);
			else if (b === "forest") c.setRGB(.15 + n, .3 + n, .16 + n);
			else if (b === "desert") c.setRGB(.78 + n, .63 + n, .36 + n);
			else if (b === "country") {
				if (Math.sin(x * .18) > 0) c.setRGB(.64 + n, .58 + n, .26 + n);
				else c.setRGB(.34 + n, .54 + n, .2 + n);
			} else if (b === "coast") c.setRGB(.74 + n, .67 + n, .46 + n);
			else c.setRGB(.3 + n, .46 + n, .24 + n);
			if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 10 && y < this.waterY + 1.2) c.setRGB(.8, .72, .5);
			cols[i * 3] = c.r;
			cols[i * 3 + 1] = c.g;
			cols[i * 3 + 2] = c.b;
		}
		geo.setAttribute("color", new BufferAttribute(cols, 3));
		geo.computeVertexNormals();
		const mat = new MeshStandardMaterial({
			vertexColors: true,
			roughness: .95,
			metalness: .02,
			map: groundNoiseTexture()
		});
		mat.map.repeat.set(40, 40);
		mat.map.wrapS = mat.map.wrapT = RepeatWrapping;
		const mesh = new Mesh(geo, mat);
		mesh.receiveShadow = true;
		return mesh;
	}
	makeWater() {
		const geo = new CircleGeometry(this.lake.r, 56);
		geo.rotateX(-Math.PI / 2);
		const mat = new MeshStandardMaterial({
			color: "#2a6a80",
			transparent: true,
			opacity: .84,
			roughness: .12,
			metalness: .35,
			map: waterTexture()
		});
		mat.map.repeat.set(6, 6);
		mat.map.wrapS = mat.map.wrapT = RepeatWrapping;
		const mesh = new Mesh(geo, mat);
		mesh.position.set(this.lake.x, this.waterY, this.lake.z);
		this.waterMesh = mesh;
		return mesh;
	}
	makeSky() {
		const geo = new SphereGeometry(920, 28, 18);
		const mat = new ShaderMaterial({
			side: 1,
			depthWrite: false,
			uniforms: {},
			vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
			fragmentShader: `varying vec3 vW; void main(){
        vec3 n = normalize(vW);
        float h = n.y;
        vec3 zen = vec3(0.20, 0.46, 0.78);
        vec3 hor = vec3(0.80, 0.84, 0.90);
        vec3 glow = vec3(0.95, 0.76, 0.52);
        vec3 col = mix(hor, zen, clamp(h * 1.2, 0.0, 1.0));
        col = mix(glow, col, clamp((h + 0.1) * 2.6, 0.0, 1.0));
        vec3 sunDir = normalize(vec3(0.42, 0.52, 0.32));
        float sun = pow(max(0.0, dot(n, sunDir)), 120.0);
        float halo = pow(max(0.0, dot(n, sunDir)), 8.0);
        col += vec3(1.0, 0.92, 0.7) * sun * 1.6;
        col += vec3(1.0, 0.8, 0.5) * halo * 0.18;
        gl_FragColor = vec4(col, 1.0);
      }`
		});
		return new Mesh(geo, mat);
	}
	makeRoadMarks() {
		const geo = new BoxGeometry(.28, .05, 3.2);
		const mat = new MeshBasicMaterial({ color: 14080736 });
		const dummy = new Object3D();
		const marks = [];
		for (const r of this.roads) {
			const dx = r.bx - r.ax;
			const dz = r.bz - r.az;
			const len = Math.hypot(dx, dz) || 1;
			const yaw = Math.atan2(dx, dz);
			const nx = -dz / len;
			const nz = dx / len;
			const lanes = r.width >= 16 ? [-r.width * .18, r.width * .18] : [0];
			for (const off of lanes) for (let s = 3; s < len - 3; s += 9) {
				if (marks.length > 4200) break;
				const t = s / len;
				marks.push({
					x: r.ax + dx * t + nx * off,
					z: r.az + dz * t + nz * off,
					yaw
				});
			}
		}
		const mesh = new InstancedMesh(geo, mat, marks.length);
		for (let i = 0; i < marks.length; i++) {
			const m = marks[i];
			dummy.position.set(m.x, this.heightAt(m.x, m.z) + .06, m.z);
			dummy.rotation.set(0, m.yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(mesh);
		const edgeGeo = new BoxGeometry(.16, .045, 5.2);
		const edgeMat = new MeshBasicMaterial({ color: 15856372 });
		const edges = [];
		const yellows = [];
		for (const r of this.roads) {
			const dx = r.bx - r.ax;
			const dz = r.bz - r.az;
			const len = Math.hypot(dx, dz) || 1;
			const yaw = Math.atan2(dx, dz);
			const nx = -dz / len;
			const nz = dx / len;
			for (let s = 1; s < len - 1; s += 5.4) {
				if (edges.length > 2800) break;
				const t = s / len;
				const cx = r.ax + dx * t;
				const cz = r.az + dz * t;
				const off = r.width * .46;
				edges.push({
					x: cx + nx * off,
					z: cz + nz * off,
					yaw
				});
				edges.push({
					x: cx - nx * off,
					z: cz - nz * off,
					yaw
				});
				if (r.width >= 16 && yellows.length < 1400) {
					yellows.push({
						x: cx + nx * .28,
						z: cz + nz * .28,
						yaw
					});
					yellows.push({
						x: cx - nx * .28,
						z: cz - nz * .28,
						yaw
					});
				}
			}
		}
		const edgeMesh = new InstancedMesh(edgeGeo, edgeMat, Math.max(1, edges.length));
		edgeMesh.count = edges.length;
		for (let i = 0; i < edges.length; i++) {
			const m = edges[i];
			dummy.position.set(m.x, this.heightAt(m.x, m.z) + .05, m.z);
			dummy.rotation.set(0, m.yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			edgeMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(edgeMesh);
		if (yellows.length) {
			const yelGeo = new BoxGeometry(.14, .05, 3.4);
			const yelMat = new MeshBasicMaterial({ color: 15251565 });
			const yelMesh = new InstancedMesh(yelGeo, yelMat, yellows.length);
			for (let i = 0; i < yellows.length; i++) {
				const m = yellows[i];
				dummy.position.set(m.x, this.heightAt(m.x, m.z) + .055, m.z);
				dummy.rotation.set(0, m.yaw, 0);
				dummy.scale.set(1, 1, 1);
				dummy.updateMatrix();
				yelMesh.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(yelMesh);
		}
	}
	skipNear(x, z, r = 18) {
		for (const p of POIS) if (Math.hypot(p.x - x, p.z - z) < r) return true;
		if (Math.hypot(x, z) < 22) return true;
		if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < 22) return true;
		if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 55) return true;
		if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 80) return true;
		return false;
	}
	isLandmarkCell(gx, gz) {
		return gx === -3 && gz === -1 || gx === 2 && gz === -1 || gx === 2 && gz === 1 || gx === 0 && gz === -3;
	}
	findLot(gx, gz) {
		const cx = gx * 28 + 14;
		const cz = gz * 28 + 14;
		for (const [ox, oz] of [
			[0, 0],
			[7, 0],
			[-7, 0],
			[0, 7],
			[0, -7],
			[8, 6],
			[-6, 8]
		]) {
			const x = cx + ox;
			const z = cz + oz;
			if (!this.onRoad(x, z) && !this.skipNear(x, z, 11)) return {
				x,
				z
			};
		}
		return null;
	}
	isParkCell(gx, gz) {
		return gx === 1 && gz === -2 || gx === -2 && gz === 1 || (gx + gz * 3) % 7 === 0;
	}
	placeCity() {
		const facades = [
			facadeTexture(),
			brickFacadeTexture(),
			glassFacadeTexture(),
			shopFacadeTexture()
		];
		const bodyGeo = new BoxGeometry(1, 1, 1);
		bodyGeo.translate(0, .5, 0);
		const dummy = new Object3D();
		const color = new Color();
		const buckets = [
			[],
			[],
			[],
			[]
		];
		for (let gx = -4; gx <= 3; gx++) for (let gz = -4; gz <= 3; gz++) {
			if (this.isParkCell(gx, gz) || this.isLandmarkCell(gx, gz)) continue;
			const cx = gx * 28 + 14;
			const cz = gz * 28 + 14;
			if (this.skipNear(cx, cz, 16)) continue;
			if (Math.hypot(cx, cz) > 128) continue;
			const n = 1 + Math.floor(hash2(gx, gz) * 3);
			for (let k = 0; k < n; k++) {
				const ox = (hash3(gx, gz, k) - .5) * 8;
				const oz = (hash3(gx + 3, gz, k + 1) - .5) * 8;
				const kind = Math.floor(hash3(gx, k, gz + 4) * 4);
				const w = kind === 3 ? 9 + hash3(gx, k, gz) * 4 : 7 + hash3(gx, k, gz) * 6;
				const d = kind === 3 ? 8 + hash3(k, gx, gz) * 3 : 7 + hash3(k, gx, gz) * 6;
				const h = kind === 3 ? 5.5 + hash2(gx, gz) * 3 : kind === 2 ? 18 + hash2(gx * 9 + k, gz * 7) * 28 : 9 + hash2(gx * 9 + k, gz * 7) * 22;
				const x = cx + ox;
				const z = cz + oz;
				if (this.onRoad(x, z) || this.skipNear(x, z)) continue;
				const pal = [
					[
						16774894,
						15986662,
						15199986,
						16249316
					],
					[
						16774122,
						16180440,
						15980492,
						16314340
					],
					[
						16054267,
						15199990,
						14017262,
						16251387
					],
					[
						16775408,
						16183268,
						16639954,
						15988458
					]
				][gz <= -2 ? 2 : gz >= 2 ? 1 : gx <= -2 ? 0 : 3];
				const col = pal[Math.floor(hash2(x, z) * pal.length)];
				const yaw = Math.floor(hash3(gx, gz, k + 9) * 4) * (Math.PI / 2);
				buckets[kind].push({
					x,
					z,
					w,
					d,
					h,
					col,
					kind,
					yaw
				});
				this.buildings.push({
					x,
					z,
					w,
					d,
					h
				});
				if (kind === 2 && h > 24) {
					buckets[0].push({
						x,
						z,
						w: w + 3.2,
						d: d + 3.2,
						h: 6.2,
						col: 7107194,
						kind: 0,
						yaw
					});
					this.buildings.push({
						x,
						z,
						w: w + 3.2,
						d: d + 3.2,
						h: 6.2
					});
				}
			}
		}
		for (let kind = 0; kind < 4; kind++) {
			const list = buckets[kind];
			if (!list.length) continue;
			const mat = new MeshStandardMaterial({
				map: facades[kind],
				roughness: kind === 2 ? .28 : .68,
				metalness: kind === 2 ? .45 : .1
			});
			const mesh = new InstancedMesh(bodyGeo, mat, list.length);
			mesh.castShadow = true;
			mesh.receiveShadow = true;
			for (let i = 0; i < list.length; i++) {
				const b = list[i];
				dummy.position.set(b.x, this.heightAt(b.x, b.z), b.z);
				dummy.scale.set(b.w, b.h, b.d);
				dummy.rotation.set(0, b.yaw, 0);
				dummy.updateMatrix();
				mesh.setMatrixAt(i, dummy.matrix);
				color.setHex(b.col);
				mesh.setColorAt(i, color);
			}
			if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
			this.group.add(mesh);
		}
		const face = (x, y, z, yaw, tz, sx, sy, sz) => {
			dummy.position.set(x, y, z);
			dummy.rotation.set(0, yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			dummy.translateZ(tz);
			dummy.scale.set(sx, sy, sz);
			dummy.updateMatrix();
		};
		const shops = buckets[3];
		if (shops.length) {
			const awnGeo = new BoxGeometry(1, .12, 1.15);
			const awnMat = new MeshStandardMaterial({
				color: "#c45c3a",
				roughness: .7
			});
			const awn = new InstancedMesh(awnGeo, awnMat, shops.length);
			const awnCols = [
				12868666,
				4021370,
				5925690,
				15251565,
				1985932
			];
			for (let i = 0; i < shops.length; i++) {
				const b = shops[i];
				face(b.x, this.heightAt(b.x, b.z) + 3.15, b.z, b.yaw, b.d * .5 + .2, b.w * .92, 1, 1);
				awn.setMatrixAt(i, dummy.matrix);
				color.setHex(awnCols[i % awnCols.length]);
				awn.setColorAt(i, color);
			}
			if (awn.instanceColor) awn.instanceColor.needsUpdate = true;
			this.group.add(awn);
			const winGeo = new PlaneGeometry(1, 1);
			const winMat = new MeshStandardMaterial({
				color: "#b7d4e4",
				emissive: "#d5eaf4",
				emissiveIntensity: .45,
				roughness: .08,
				metalness: .45,
				transparent: true,
				opacity: .86
			});
			const wins = new InstancedMesh(winGeo, winMat, shops.length);
			for (let i = 0; i < shops.length; i++) {
				const b = shops[i];
				face(b.x, this.heightAt(b.x, b.z) + 1.65, b.z, b.yaw, b.d * .5 + .06, b.w * .7, 1.7, 1);
				wins.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(wins);
			const labels = [
				["PÉK", "#c45c3a"],
				["TEJ", "#3d5c7a"],
				["VIRÁG", "#5a6b3a"],
				["JÁTÉK", "#e24a3b"],
				["KÖNYV", "#1e4d8c"],
				["FAGYI", "#c45c78"],
				["POSTA", "#c4923a"],
				["PIAC", "#8a1f1a"]
			];
			for (let k = 0; k < labels.length; k++) {
				const list = shops.filter((_, i) => i % labels.length === k);
				if (!list.length) continue;
				const [label, bg] = labels[k];
				const mat = new MeshBasicMaterial({
					map: shopSignTexture(label, bg),
					side: 2
				});
				const sign = new InstancedMesh(new PlaneGeometry(1, 1), mat, list.length);
				for (let i = 0; i < list.length; i++) {
					const b = list[i];
					face(b.x, this.heightAt(b.x, b.z) + 4.15, b.z, b.yaw, b.d * .5 + .18, 2.8, .78, 1);
					sign.setMatrixAt(i, dummy.matrix);
				}
				this.group.add(sign);
			}
		}
		const all = buckets.flat();
		const roofGeo = new BoxGeometry(1, .28, 1);
		const roofMat = new MeshStandardMaterial({
			color: "#3a4048",
			roughness: .86
		});
		const roofMesh = new InstancedMesh(roofGeo, roofMat, all.length);
		const roofCols = [
			6963256,
			3817544,
			5910568,
			2765632
		];
		for (let i = 0; i < all.length; i++) {
			const b = all[i];
			dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h + .08, b.z);
			dummy.scale.set(b.w + .35, 1, b.d + .35);
			dummy.rotation.set(0, b.yaw, 0);
			dummy.updateMatrix();
			roofMesh.setMatrixAt(i, dummy.matrix);
			color.setHex(roofCols[b.kind]);
			roofMesh.setColorAt(i, color);
		}
		if (roofMesh.instanceColor) roofMesh.instanceColor.needsUpdate = true;
		this.group.add(roofMesh);
		const pitched = all.filter((b) => b.h < 12 && b.kind !== 2);
		if (pitched.length) {
			const cone = new ConeGeometry(.72, 1, 4);
			cone.rotateY(Math.PI / 4);
			cone.translate(0, .5, 0);
			const pitchMat = new MeshStandardMaterial({
				color: "#8a4034",
				roughness: .9
			});
			const pitch = new InstancedMesh(cone, pitchMat, pitched.length);
			pitch.castShadow = true;
			const pitchCols = [
				9060404,
				5910568,
				3819604,
				6968128
			];
			for (let i = 0; i < pitched.length; i++) {
				const b = pitched[i];
				dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h, b.z);
				dummy.scale.set(b.w * .78, 2.4 + hash2(b.x, b.z) * 1.3, b.d * .78);
				dummy.rotation.set(0, b.yaw, 0);
				dummy.updateMatrix();
				pitch.setMatrixAt(i, dummy.matrix);
				color.setHex(pitchCols[i % pitchCols.length]);
				pitch.setColorAt(i, color);
			}
			if (pitch.instanceColor) pitch.instanceColor.needsUpdate = true;
			this.group.add(pitch);
		}
		const caps = all.filter((b) => b.kind === 2 && b.h > 20);
		if (caps.length) {
			const capGeo = new BoxGeometry(1, 1, 1);
			capGeo.translate(0, .5, 0);
			const capMat = new MeshStandardMaterial({
				map: facades[2],
				roughness: .22,
				metalness: .55,
				color: "#e7eef6"
			});
			const capMesh = new InstancedMesh(capGeo, capMat, caps.length);
			capMesh.castShadow = true;
			for (let i = 0; i < caps.length; i++) {
				const b = caps[i];
				const extra = 6 + hash2(b.x, b.h) * 8;
				dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h, b.z);
				dummy.scale.set(b.w * .62, extra, b.d * .62);
				dummy.rotation.set(0, b.yaw, 0);
				dummy.updateMatrix();
				capMesh.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(capMesh);
		}
		const bals = all.filter((b) => b.h > 14).slice(0, 70);
		if (bals.length) {
			const balGeo = new BoxGeometry(1, .1, .55);
			const balMat = new MeshStandardMaterial({
				color: "#d8dce2",
				roughness: .6
			});
			const bal = new InstancedMesh(balGeo, balMat, bals.length);
			const railGeo = new BoxGeometry(1, .35, .05);
			const rail = new InstancedMesh(railGeo, balMat, bals.length);
			for (let i = 0; i < bals.length; i++) {
				const b = bals[i];
				const y = this.heightAt(b.x, b.z) + b.h * .48;
				face(b.x, y, b.z, b.yaw, b.d * .5 + .12, b.w * .48, 1, 1);
				bal.setMatrixAt(i, dummy.matrix);
				face(b.x, y + .38, b.z, b.yaw, b.d * .5 + .34, b.w * .48, 1, 1);
				rail.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(bal, rail);
		}
		const acList = all.filter((b) => b.h > 12).slice(0, 80);
		if (acList.length) {
			const acGeo = new BoxGeometry(1.6, .7, 1.1);
			const acMat = new MeshStandardMaterial({
				color: "#8a9098",
				roughness: .55,
				metalness: .35
			});
			const ac = new InstancedMesh(acGeo, acMat, acList.length);
			for (let i = 0; i < acList.length; i++) {
				const b = acList[i];
				dummy.position.set(b.x + 1.2, this.heightAt(b.x, b.z) + b.h + .55, b.z - .8);
				dummy.scale.set(1, 1, 1);
				dummy.rotation.set(0, b.yaw, 0);
				dummy.updateMatrix();
				ac.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(ac);
		}
		const lampGeo = new CylinderGeometry(.08, .1, 5.2, 6);
		lampGeo.translate(0, 2.6, 0);
		const lampMat = new MeshStandardMaterial({ color: "#2a2c30" });
		const lamps = [];
		for (let i = -4; i <= 4; i++) for (const s of [-1, 1]) {
			lamps.push({
				x: i * 28 + 5,
				z: s * 118
			});
			lamps.push({
				x: s * 118,
				z: i * 28 + 5
			});
		}
		for (let i = -3; i <= 3; i++) {
			lamps.push({
				x: i * 28 + 8,
				z: 8
			});
			lamps.push({
				x: 8,
				z: i * 28 + 8
			});
		}
		const lampMesh = new InstancedMesh(lampGeo, lampMat, lamps.length);
		const bulbGeo = new SphereGeometry(.22, 8, 8);
		const bulbMat = new MeshStandardMaterial({
			color: "#f0e6c0",
			emissive: "#e8d090",
			emissiveIntensity: .85
		});
		const bulbs = new InstancedMesh(bulbGeo, bulbMat, lamps.length);
		for (let i = 0; i < lamps.length; i++) {
			const p = lamps[i];
			const y = this.heightAt(p.x, p.z);
			dummy.position.set(p.x, y, p.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			lampMesh.setMatrixAt(i, dummy.matrix);
			dummy.position.y = y + 5.15;
			dummy.updateMatrix();
			bulbs.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(lampMesh, bulbs);
		const statue = new Group();
		const plinth = new Mesh(new BoxGeometry(4.2, 1.3, 4.2), new MeshStandardMaterial({
			color: "#8b9098",
			roughness: .55,
			metalness: .2
		}));
		plinth.position.y = .65;
		const fig = new Mesh(new ConeGeometry(1.15, 4.4, 7), new MeshStandardMaterial({
			color: "#a8b0bc",
			metalness: .45,
			roughness: .32
		}));
		fig.position.y = 3.4;
		const head = new Mesh(new SphereGeometry(.55, 10, 8), new MeshStandardMaterial({
			color: "#b4bcc4",
			metalness: .4,
			roughness: .35
		}));
		head.position.y = 5.7;
		statue.add(plinth, fig, head);
		statue.position.set(0, this.heightAt(0, 0), 0);
		this.group.add(statue);
		this.buildings.push({
			x: 0,
			z: 0,
			w: 4.6,
			d: 4.6,
			h: 6
		});
	}
	placeSkyline() {
		const stone = new MeshStandardMaterial({
			color: "#e7e2d8",
			roughness: .78
		});
		const brick = new MeshStandardMaterial({
			color: "#8a4a3c",
			roughness: .86
		});
		const glass = new MeshStandardMaterial({
			color: "#c5d6e4",
			roughness: .22,
			metalness: .48
		});
		const dark = new MeshStandardMaterial({
			color: "#2a2c30",
			roughness: .7
		});
		const gold = new MeshStandardMaterial({
			color: "#e8b86d",
			roughness: .4,
			metalness: .45
		});
		const churchAt = this.findLot(-3, -1);
		if (churchAt) {
			const { x, z } = churchAt;
			const y = this.heightAt(x, z);
			const g = new Group();
			const nave = new Mesh(new BoxGeometry(16, 8, 10), stone);
			nave.position.y = 4;
			nave.castShadow = true;
			const tower = new Mesh(new BoxGeometry(4.2, 16, 4.2), stone);
			tower.position.set(-5.2, 8, 0);
			tower.castShadow = true;
			const spire = new Mesh(new ConeGeometry(2.3, 7.5, 4), dark);
			spire.position.set(-5.2, 19.2, 0);
			spire.rotation.y = Math.PI / 4;
			const crossV = new Mesh(new BoxGeometry(.18, 1.5, .18), gold);
			crossV.position.set(-5.2, 23.4, 0);
			const crossH = new Mesh(new BoxGeometry(.9, .16, .16), gold);
			crossH.position.set(-5.2, 23.7, 0);
			const door = new Mesh(new BoxGeometry(2.2, 3.4, .2), dark);
			door.position.set(1.2, 1.7, 5.1);
			const windowM = new MeshStandardMaterial({
				color: "#7ec8c4",
				emissive: "#3a6a78",
				emissiveIntensity: .35,
				transparent: true,
				opacity: .85
			});
			const rose = new Mesh(new CircleGeometry(1.15, 10), windowM);
			rose.position.set(1.2, 5.4, 5.12);
			g.add(nave, tower, spire, crossV, crossH, door, rose);
			g.position.set(x, y, z);
			this.group.add(g);
			this.buildings.push({
				x,
				z,
				w: 16,
				d: 10,
				h: 22
			});
		}
		const hotelAt = this.findLot(2, -1);
		if (hotelAt) {
			const { x, z } = hotelAt;
			const y = this.heightAt(x, z);
			const g = new Group();
			for (const t of [
				{
					w: 16,
					d: 14,
					h: 10,
					yy: 0
				},
				{
					w: 12,
					d: 10,
					h: 12,
					yy: 10
				},
				{
					w: 8,
					d: 7,
					h: 10,
					yy: 22
				}
			]) {
				const body = new Mesh(new BoxGeometry(t.w, t.h, t.d), glass);
				body.position.y = t.yy + t.h / 2;
				body.castShadow = true;
				const band = new Mesh(new BoxGeometry(t.w + .3, .35, t.d + .3), gold);
				band.position.y = t.yy + t.h;
				g.add(body, band);
			}
			const mast = new Mesh(new CylinderGeometry(.08, .12, 6, 6), dark);
			mast.position.y = 35;
			g.add(mast);
			g.position.set(x, y, z);
			this.group.add(g);
			this.buildings.push({
				x,
				z,
				w: 16,
				d: 14,
				h: 32
			});
		}
		const clockAt = this.findLot(2, 1);
		if (clockAt) {
			const { x, z } = clockAt;
			const y = this.heightAt(x, z);
			const g = new Group();
			const shaft = new Mesh(new BoxGeometry(5.2, 22, 5.2), brick);
			shaft.position.y = 11;
			shaft.castShadow = true;
			const cap = new Mesh(new ConeGeometry(3.6, 5.2, 4), dark);
			cap.position.y = 24.4;
			cap.rotation.y = Math.PI / 4;
			const faceMat = new MeshStandardMaterial({
				color: "#f7f1d4",
				emissive: "#f2e4a8",
				emissiveIntensity: .35
			});
			for (const [fx, fz] of [
				[0, 2.65],
				[0, -2.65],
				[2.65, 0],
				[-2.65, 0]
			]) {
				const face = new Mesh(new CircleGeometry(1.05, 12), faceMat);
				face.position.set(fx, 16.5, fz);
				if (Math.abs(fx) > 1) face.rotation.y = Math.PI / 2;
				g.add(face);
			}
			g.add(shaft, cap);
			g.position.set(x, y, z);
			this.group.add(g);
			this.buildings.push({
				x,
				z,
				w: 5.4,
				d: 5.4,
				h: 26
			});
		}
		const arcadeAt = this.findLot(0, -3);
		if (arcadeAt) {
			const colors = [
				"#c45c3a",
				"#e8b86d",
				"#3d5c7a",
				"#5a6b3a",
				"#1e4d8c",
				"#8a1f1a"
			];
			for (let i = 0; i < 6; i++) {
				const x = arcadeAt.x - 7.5 + i * 3.1;
				const z = arcadeAt.z;
				if (this.onRoad(x, z)) continue;
				const y = this.heightAt(x, z);
				const stall = new Mesh(new BoxGeometry(2.4, 2.2, 2.2), new MeshStandardMaterial({
					color: "#f4efe6",
					roughness: .8
				}));
				stall.position.set(x, y + 1.1, z);
				stall.castShadow = true;
				const awn = new Mesh(new BoxGeometry(2.7, .12, 1.5), new MeshStandardMaterial({ color: colors[i] }));
				awn.position.set(x, y + 2.35, z + 1.1);
				const fruit = new Mesh(new SphereGeometry(.28, 8, 6), new MeshStandardMaterial({ color: i % 2 ? "#c45c3a" : "#e8b86d" }));
				fruit.position.set(x, y + 2.7, z + .2);
				this.group.add(stall, awn, fruit);
				this.buildings.push({
					x,
					z,
					w: 2.5,
					d: 2.3,
					h: 2.4
				});
			}
		}
	}
	placeCityDetails() {
		const dummy = new Object3D();
		const color = new Color();
		const walk = [];
		for (const r of this.roads) {
			if (Math.hypot(r.ax, r.az) > 145 && Math.hypot(r.bx, r.bz) > 145) continue;
			const dx = r.bx - r.ax;
			const dz = r.bz - r.az;
			const len = Math.hypot(dx, dz) || 1;
			const nx = -dz / len;
			const nz = dx / len;
			const yaw = Math.atan2(dx, dz);
			for (const side of [-1, 1]) {
				const off = r.width * .52 + 1.15;
				for (let s = 2; s < len - 2; s += 4.4) {
					if (walk.length > 1600) break;
					const t = s / len;
					const x = r.ax + dx * t + nx * off * side;
					const z = r.az + dz * t + nz * off * side;
					if (Math.hypot(x, z) > 140) continue;
					walk.push({
						x,
						z,
						yaw
					});
				}
			}
		}
		this.sidewalks = walk.filter((_, i) => i % 3 === 0 && !this.onRoad(walk[i].x, walk[i].z));
		if (walk.length) {
			const geo = new BoxGeometry(2.05, .16, 4.2);
			const mat = new MeshStandardMaterial({
				color: "#e7e2d6",
				roughness: .92
			});
			const mesh = new InstancedMesh(geo, mat, walk.length);
			mesh.receiveShadow = true;
			for (let i = 0; i < walk.length; i++) {
				const p = walk[i];
				dummy.position.set(p.x, this.heightAt(p.x, p.z) + .08, p.z);
				dummy.rotation.set(0, p.yaw, 0);
				dummy.scale.set(1, 1, 1);
				dummy.updateMatrix();
				mesh.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(mesh);
		}
		const planters = [];
		for (let i = 0; i < walk.length; i += 18) {
			const p = walk[i];
			if (this.onRoad(p.x, p.z)) continue;
			planters.push(p);
		}
		if (planters.length) {
			const pot = new CylinderGeometry(.38, .42, .5, 8);
			pot.translate(0, .25, 0);
			const bush = new SphereGeometry(.42, 8, 6);
			const potM = new MeshStandardMaterial({
				color: "#6a4038",
				roughness: .88
			});
			const bushM = new MeshStandardMaterial({
				color: "#2f5a34",
				roughness: .85
			});
			const pots = new InstancedMesh(pot, potM, planters.length);
			const bushes = new InstancedMesh(bush, bushM, planters.length);
			for (let i = 0; i < planters.length; i++) {
				const p = planters[i];
				const y = this.heightAt(p.x, p.z);
				dummy.position.set(p.x, y, p.z);
				dummy.scale.set(1, 1, 1);
				dummy.rotation.set(0, 0, 0);
				dummy.updateMatrix();
				pots.setMatrixAt(i, dummy.matrix);
				dummy.position.y = y + .7;
				dummy.updateMatrix();
				bushes.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(pots, bushes);
		}
		const saplings = [];
		for (let i = 0; i < walk.length; i += 26) {
			const p = walk[i];
			if (this.onRoad(p.x, p.z) || this.skipNear(p.x, p.z, 8)) continue;
			saplings.push({
				x: p.x,
				z: p.z,
				s: .55 + hash2(p.x, p.z) * .35
			});
			this.trees.push({
				x: p.x,
				z: p.z,
				r: .35
			});
		}
		if (saplings.length) {
			const trunkGeo = new CylinderGeometry(.1, .14, 1.5, 5);
			trunkGeo.translate(0, .75, 0);
			const leafGeo = new SphereGeometry(.7, 7, 5);
			const trunkM = new MeshStandardMaterial({
				color: "#4a3424",
				roughness: .95
			});
			const leafM = new MeshStandardMaterial({
				color: "#ffffff",
				roughness: .85
			});
			const trunks = new InstancedMesh(trunkGeo, trunkM, saplings.length);
			const leaves = new InstancedMesh(leafGeo, leafM, saplings.length);
			const leafCols = [
				3107384,
				4028994,
				6982194,
				2054720
			];
			for (let i = 0; i < saplings.length; i++) {
				const p = saplings[i];
				const y = this.heightAt(p.x, p.z);
				dummy.position.set(p.x, y, p.z);
				dummy.scale.setScalar(p.s);
				dummy.rotation.set(0, 0, 0);
				dummy.updateMatrix();
				trunks.setMatrixAt(i, dummy.matrix);
				dummy.position.y = y + 1.7 * p.s;
				dummy.scale.setScalar(p.s * 1.15);
				dummy.updateMatrix();
				leaves.setMatrixAt(i, dummy.matrix);
				color.setHex(leafCols[i % leafCols.length]);
				leaves.setColorAt(i, color);
			}
			if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
			this.group.add(trunks, leaves);
		}
	}
	placeParks() {
		const dummy = new Object3D();
		const grass = new MeshStandardMaterial({
			color: "#3d6a38",
			roughness: .95
		});
		const padGeo = new BoxGeometry(22, .12, 22);
		const parks = [{
			x: PLAZA.x,
			z: PLAZA.z
		}];
		for (let gx = -4; gx <= 3; gx++) for (let gz = -4; gz <= 3; gz++) {
			if (!this.isParkCell(gx, gz)) continue;
			const x = gx * 28 + 14;
			const z = gz * 28 + 14;
			if (Math.hypot(x, z) > 120) continue;
			parks.push({
				x,
				z
			});
		}
		const pads = new InstancedMesh(padGeo, grass, parks.length);
		for (let i = 0; i < parks.length; i++) {
			const p = parks[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z) + .08, p.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			pads.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(pads);
		const benchSeat = new BoxGeometry(1.6, .12, .42);
		const benchMat = new MeshStandardMaterial({
			color: "#6a5340",
			roughness: .85
		});
		const benches = [];
		for (const p of parks) {
			benches.push({
				x: p.x - 6,
				z: p.z - 4,
				yaw: .2
			});
			benches.push({
				x: p.x + 5,
				z: p.z + 3,
				yaw: 1.2
			});
			benches.push({
				x: p.x - 2,
				z: p.z + 6,
				yaw: -.4
			});
		}
		const benchMesh = new InstancedMesh(benchSeat, benchMat, benches.length);
		for (let i = 0; i < benches.length; i++) {
			const b = benches[i];
			dummy.position.set(b.x, this.heightAt(b.x, b.z) + .45, b.z);
			dummy.rotation.set(0, b.yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			benchMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(benchMesh);
		const pathMat = new MeshStandardMaterial({
			color: "#cfc6b4",
			roughness: .95
		});
		const pathA = new BoxGeometry(1.6, .06, 16);
		const pathB = new BoxGeometry(16, .06, 1.6);
		const pathsA = new InstancedMesh(pathA, pathMat, parks.length);
		const pathsB = new InstancedMesh(pathB, pathMat, parks.length);
		for (let i = 0; i < parks.length; i++) {
			const p = parks[i];
			const y = this.heightAt(p.x, p.z) + .12;
			dummy.position.set(p.x, y, p.z);
			dummy.rotation.set(0, 0, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			pathsA.setMatrixAt(i, dummy.matrix);
			pathsB.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(pathsA, pathsB);
		const treeSpots = [];
		for (const p of parks) for (const [ox, oz] of [
			[-7, -7],
			[7, -6],
			[-6, 7],
			[7, 7]
		]) {
			const x = p.x + ox;
			const z = p.z + oz;
			if (this.onRoad(x, z)) continue;
			treeSpots.push({
				x,
				z
			});
			this.trees.push({
				x,
				z,
				r: .55
			});
		}
		if (treeSpots.length) {
			const trunkGeo = new CylinderGeometry(.16, .24, 1.8, 5);
			trunkGeo.translate(0, .9, 0);
			const leafGeo = new SphereGeometry(1.15, 7, 5);
			const trunks = new InstancedMesh(trunkGeo, new MeshStandardMaterial({
				color: "#4a3424",
				roughness: .95
			}), treeSpots.length);
			const leaves = new InstancedMesh(leafGeo, new MeshStandardMaterial({
				color: "#3d7a42",
				roughness: .82
			}), treeSpots.length);
			for (let i = 0; i < treeSpots.length; i++) {
				const p = treeSpots[i];
				const y = this.heightAt(p.x, p.z);
				dummy.position.set(p.x, y, p.z);
				dummy.scale.set(1, 1, 1);
				dummy.rotation.set(0, 0, 0);
				dummy.updateMatrix();
				trunks.setMatrixAt(i, dummy.matrix);
				dummy.position.y = y + 2.3;
				dummy.updateMatrix();
				leaves.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(trunks, leaves);
		}
		const fountain = new Group();
		const rim = new Mesh(new CylinderGeometry(3.2, 3.4, .55, 16), new MeshStandardMaterial({
			color: "#8b9098",
			roughness: .5,
			metalness: .25
		}));
		rim.position.y = .3;
		const pool = new Mesh(new CircleGeometry(2.8, 16), new MeshStandardMaterial({
			color: "#2a6a80",
			roughness: .12,
			metalness: .35,
			transparent: true,
			opacity: .85
		}));
		pool.rotation.x = -Math.PI / 2;
		pool.position.y = .48;
		const jet = new Mesh(new CylinderGeometry(.12, .18, 2.2, 8), new MeshStandardMaterial({
			color: "#dce0e6",
			roughness: .2,
			metalness: .5
		}));
		jet.position.y = 1.4;
		fountain.add(rim, pool, jet);
		fountain.position.set(PLAZA.x, this.heightAt(PLAZA.x, PLAZA.z), PLAZA.z);
		this.group.add(fountain);
		this.buildings.push({
			x: PLAZA.x,
			z: PLAZA.z,
			w: 6.4,
			d: 6.4,
			h: 1.2
		});
	}
	placeStreetFurniture() {
		const dummy = new Object3D();
		const poleGeo = new CylinderGeometry(.07, .09, 3.4, 6);
		poleGeo.translate(0, 1.7, 0);
		const poleMat = new MeshStandardMaterial({ color: "#2a2c30" });
		const kinds = [
			"stop",
			"yield",
			"speed",
			"cross",
			"noentry"
		];
		const signs = [];
		const spots = [
			[28, 28],
			[-28, 28],
			[28, -28],
			[-28, -28],
			[56, 0],
			[-56, 0],
			[0, 56],
			[0, -56],
			[84, 28],
			[-84, -28],
			[42, -42],
			[-42, 42],
			[FACTORY.x + 40, FACTORY.z],
			[AIRPORT.x - 18, AIRPORT.z + 70]
		];
		for (let i = 0; i < spots.length; i++) {
			const [x, z] = spots[i];
			signs.push({
				x: x + 6,
				z: z + 6,
				yaw: hash2(i, 2) * Math.PI,
				kind: i % kinds.length
			});
		}
		const poles = new InstancedMesh(poleGeo, poleMat, signs.length);
		for (let i = 0; i < signs.length; i++) {
			const s = signs[i];
			dummy.position.set(s.x, this.heightAt(s.x, s.z), s.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			poles.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(poles);
		const boardGeo = new PlaneGeometry(1.15, 1.15);
		for (let k = 0; k < kinds.length; k++) {
			const list = signs.filter((s) => s.kind === k);
			if (!list.length) continue;
			const mat = new MeshBasicMaterial({
				map: signTexture(kinds[k]),
				transparent: true,
				side: 2,
				depthWrite: false
			});
			const mesh = new InstancedMesh(boardGeo, mat, list.length);
			for (let i = 0; i < list.length; i++) {
				const s = list[i];
				dummy.position.set(s.x, this.heightAt(s.x, s.z) + 3.35, s.z);
				dummy.rotation.set(0, s.yaw, 0);
				dummy.scale.set(1, 1, 1);
				dummy.updateMatrix();
				mesh.setMatrixAt(i, dummy.matrix);
			}
			this.group.add(mesh);
		}
		const lightPole = new CylinderGeometry(.1, .12, 4.6, 6);
		lightPole.translate(0, 2.3, 0);
		const crossings = [
			[28, 0],
			[-28, 0],
			[0, 28],
			[0, -28],
			[56, 28],
			[-56, -28],
			[PLAZA.x + 16, PLAZA.z],
			[84, 0],
			[0, 84]
		];
		const lp = new InstancedMesh(lightPole, new MeshStandardMaterial({ color: "#1c1f26" }), crossings.length);
		const bulbGeo = new BoxGeometry(.26, .2, .2);
		const redM = new MeshStandardMaterial({
			color: "#e24a3b",
			emissive: "#e24a3b",
			emissiveIntensity: .15
		});
		const ambM = new MeshStandardMaterial({
			color: "#e8b86d",
			emissive: "#e8b86d",
			emissiveIntensity: .12
		});
		const grnM = new MeshStandardMaterial({
			color: "#5ecf9a",
			emissive: "#5ecf9a",
			emissiveIntensity: .85
		});
		this.signalRed = redM;
		this.signalGreen = grnM;
		const reds = new InstancedMesh(bulbGeo, redM, crossings.length);
		const ambs = new InstancedMesh(bulbGeo, ambM, crossings.length);
		const grns = new InstancedMesh(bulbGeo, grnM, crossings.length);
		for (let i = 0; i < crossings.length; i++) {
			const [x, z] = crossings[i];
			const y = this.heightAt(x, z);
			dummy.position.set(x + 5.5, y, z + 5.5);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			lp.setMatrixAt(i, dummy.matrix);
			dummy.position.set(x + 5.5, y + 4.85, z + 5.5);
			dummy.updateMatrix();
			reds.setMatrixAt(i, dummy.matrix);
			dummy.position.y = y + 4.55;
			dummy.updateMatrix();
			ambs.setMatrixAt(i, dummy.matrix);
			dummy.position.y = y + 4.25;
			dummy.updateMatrix();
			grns.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(lp, reds, ambs, grns);
		const crossGeo = new BoxGeometry(.42, .04, 2.8);
		const crossMat = new MeshBasicMaterial({ color: 15856372 });
		const stripes = [];
		for (const [x, z] of crossings) for (let k = -3; k <= 3; k++) stripes.push({
			x: x + k * .7,
			z,
			yaw: 0
		});
		const stripeMesh = new InstancedMesh(crossGeo, crossMat, stripes.length);
		for (let i = 0; i < stripes.length; i++) {
			const s = stripes[i];
			dummy.position.set(s.x, this.heightAt(s.x, s.z) + .07, s.z);
			dummy.rotation.set(0, s.yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			stripeMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(stripeMesh);
	}
	placeFactory() {
		const cx = FACTORY.x;
		const cz = FACTORY.z;
		const rust = new MeshStandardMaterial({
			color: "#6a5340",
			roughness: .92,
			metalness: .18
		});
		const dark = new MeshStandardMaterial({
			color: "#2a2c30",
			roughness: .88
		});
		const halls = [
			{
				x: cx - 22,
				z: cz - 8,
				w: 28,
				d: 14,
				h: 11
			},
			{
				x: cx + 24,
				z: cz + 10,
				w: 22,
				d: 12,
				h: 9
			},
			{
				x: cx + 8,
				z: cz - 22,
				w: 16,
				d: 10,
				h: 7
			}
		];
		for (const h of halls) {
			const body = new Mesh(new BoxGeometry(h.w, h.h, h.d), rust);
			body.position.set(h.x, this.heightAt(h.x, h.z) + h.h / 2, h.z);
			body.castShadow = true;
			const roof = new Mesh(new BoxGeometry(h.w + 1.2, .4, h.d + 1.2), dark);
			roof.position.set(h.x, this.heightAt(h.x, h.z) + h.h + .15, h.z);
			const chimney = new Mesh(new CylinderGeometry(1.1, 1.4, 8, 8), dark);
			chimney.position.set(h.x + h.w * .3, this.heightAt(h.x, h.z) + h.h + 4, h.z);
			this.group.add(body, roof, chimney);
			this.buildings.push({
				x: h.x,
				z: h.z,
				w: h.w,
				d: h.d,
				h: h.h
			});
		}
		const tank = new Mesh(new CylinderGeometry(4.2, 4.2, 7.5, 12), new MeshStandardMaterial({
			color: "#4a5560",
			roughness: .55,
			metalness: .4
		}));
		tank.position.set(cx - 8, this.heightAt(cx, cz) + 3.8, cz + 22);
		this.group.add(tank);
		this.buildings.push({
			x: cx - 8,
			z: cz + 22,
			w: 8.4,
			d: 8.4,
			h: 7.5
		});
		const dummy = new Object3D();
		const barrelGeo = new CylinderGeometry(.42, .42, .9, 8);
		const barrelMat = new MeshStandardMaterial({
			color: "#4a5560",
			roughness: .55,
			metalness: .3
		});
		const barrels = [];
		for (let i = 0; i < 16; i++) barrels.push({
			x: cx - 36 + i % 8 * 1.1,
			z: cz + 18 + Math.floor(i / 8) * 1.2
		});
		const barrelMesh = new InstancedMesh(barrelGeo, barrelMat, barrels.length);
		for (let i = 0; i < barrels.length; i++) {
			const p = barrels[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z) + .45, p.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			barrelMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(barrelMesh);
		const crateGeo = new BoxGeometry(1.4, 1.1, 1.4);
		const crateMat = new MeshStandardMaterial({
			color: "#6a5340",
			roughness: .9
		});
		const crates = new InstancedMesh(crateGeo, crateMat, 8);
		for (let i = 0; i < 8; i++) {
			dummy.position.set(cx + 32 + i % 4 * 1.8, this.heightAt(cx, cz) + .55, cz - 6 + Math.floor(i / 4) * 1.8);
			dummy.rotation.set(0, i * .2, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			crates.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(crates);
		const coneGeo = new ConeGeometry(.28, .8, 6);
		const coneMat = new MeshStandardMaterial({ color: "#e24a3b" });
		const cones = [];
		for (let i = 0; i < 22; i++) {
			const t = i / 22 * Math.PI * 2;
			cones.push({
				x: cx + Math.cos(t) * 40,
				z: cz + Math.sin(t) * 28
			});
		}
		const coneMesh = new InstancedMesh(coneGeo, coneMat, cones.length);
		for (let i = 0; i < cones.length; i++) {
			const p = cones[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z) + .4, p.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			coneMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(coneMesh);
		const stack = new Mesh(new CylinderGeometry(1.5, 2.1, 18, 8), new MeshStandardMaterial({
			color: "#3a4048",
			roughness: .8,
			metalness: .25
		}));
		stack.position.set(cx - 28, this.heightAt(cx - 28, cz - 6) + 9, cz - 6);
		const band = new Mesh(new CylinderGeometry(1.7, 1.7, .45, 8), new MeshStandardMaterial({ color: "#c45c3a" }));
		band.position.set(cx - 28, this.heightAt(cx - 28, cz - 6) + 14, cz - 6);
		this.group.add(stack, band);
		this.buildings.push({
			x: cx - 28,
			z: cz - 6,
			w: 4.2,
			d: 4.2,
			h: 18
		});
		const tireGeo = new TorusGeometry(.55, .18, 6, 10);
		const tireMat = new MeshStandardMaterial({
			color: "#1c1f26",
			roughness: .9
		});
		const tires = new InstancedMesh(tireGeo, tireMat, 14);
		for (let i = 0; i < 14; i++) {
			const col = i % 7;
			const row = Math.floor(i / 7);
			dummy.position.set(cx + 16 + col * 1.3, this.heightAt(cx, cz) + .55 + row * .35, cz + 16);
			dummy.rotation.set(Math.PI / 2, 0, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			tires.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(tires);
		const label = document.createElement("canvas");
		label.width = 512;
		label.height = 128;
		const lctx = label.getContext("2d");
		lctx.clearRect(0, 0, 512, 128);
		lctx.fillStyle = "#e24a3b";
		lctx.font = "900 96px sans-serif";
		lctx.textAlign = "center";
		lctx.textBaseline = "middle";
		lctx.fillText("DRIFT", 256, 68);
		const ltex = new CanvasTexture(label);
		ltex.colorSpace = SRGBColorSpace;
		const decal = new Mesh(new PlaneGeometry(26, 6.5), new MeshBasicMaterial({
			map: ltex,
			transparent: true,
			depthWrite: false
		}));
		decal.rotation.x = -Math.PI / 2;
		decal.position.set(cx, this.heightAt(cx, cz) + .18, cz);
		this.group.add(decal);
		this.addSign(cx, cz, "GYÁR", "#67e8f9");
	}
	placeAirport() {
		const cx = AIRPORT.x;
		const cz = AIRPORT.z;
		const tarmac = new Mesh(new BoxGeometry(28, .08, 160), new MeshStandardMaterial({
			color: "#2a2c30",
			roughness: .92
		}));
		tarmac.position.set(cx, this.heightAt(cx, cz) + .05, cz);
		this.group.add(tarmac);
		const line = new Mesh(new BoxGeometry(.5, .04, 150), new MeshBasicMaterial({ color: 15856372 }));
		line.position.set(cx, this.heightAt(cx, cz) + .12, cz);
		this.group.add(line);
		const start = new Mesh(new BoxGeometry(22, .08, 1.4), new MeshStandardMaterial({ color: "#e24a3b" }));
		start.position.set(cx, this.heightAt(cx, cz) + .14, cz + 62);
		this.group.add(start);
		const num = document.createElement("canvas");
		num.width = 256;
		num.height = 256;
		const nctx = num.getContext("2d");
		nctx.clearRect(0, 0, 256, 256);
		nctx.fillStyle = "#f4f6f8";
		nctx.font = "900 150px sans-serif";
		nctx.textAlign = "center";
		nctx.textBaseline = "middle";
		nctx.fillText("09", 128, 132);
		const ntex = new CanvasTexture(num);
		ntex.colorSpace = SRGBColorSpace;
		const number = new Mesh(new PlaneGeometry(10, 10), new MeshBasicMaterial({
			map: ntex,
			transparent: true,
			depthWrite: false
		}));
		number.rotation.x = -Math.PI / 2;
		number.position.set(cx, this.heightAt(cx, cz) + .16, cz + 48);
		this.group.add(number);
		const chevGeo = new BoxGeometry(6.5, .05, .7);
		const chevMat = new MeshBasicMaterial({ color: 15856372 });
		const chevs = new InstancedMesh(chevGeo, chevMat, 8);
		const chevDummy = new Object3D();
		for (let i = 0; i < 8; i++) {
			chevDummy.position.set(cx, this.heightAt(cx, cz) + .15, cz + 58 - i * 4.2);
			chevDummy.rotation.set(0, i % 2 === 0 ? .55 : -.55, 0);
			chevDummy.scale.set(1, 1, 1);
			chevDummy.updateMatrix();
			chevs.setMatrixAt(i, chevDummy.matrix);
		}
		this.group.add(chevs);
		const hangarMat = new MeshStandardMaterial({
			color: "#8a9098",
			roughness: .7,
			metalness: .2
		});
		for (const ox of [-38, 38]) {
			const hall = new Mesh(new BoxGeometry(22, 8, 28), hangarMat);
			hall.position.set(cx + ox, this.heightAt(cx + ox, cz + 10) + 4, cz + 10);
			hall.castShadow = true;
			this.group.add(hall);
			this.buildings.push({
				x: cx + ox,
				z: cz + 10,
				w: 22,
				d: 28,
				h: 8
			});
		}
		const tower = new Mesh(new CylinderGeometry(2.2, 2.8, 14, 8), new MeshStandardMaterial({
			color: "#d8dce2",
			roughness: .55
		}));
		tower.position.set(cx + 48, this.heightAt(cx + 48, cz - 20) + 7, cz - 20);
		const cap = new Mesh(new CylinderGeometry(3.4, 2.4, 2.2, 8), new MeshStandardMaterial({
			color: "#3d5c7a",
			roughness: .3,
			metalness: .4,
			transparent: true,
			opacity: .85
		}));
		cap.position.set(cx + 48, this.heightAt(cx + 48, cz - 20) + 15.2, cz - 20);
		this.group.add(tower, cap);
		this.buildings.push({
			x: cx + 48,
			z: cz - 20,
			w: 6,
			d: 6,
			h: 16
		});
		const plane = new Group();
		const alum = new MeshStandardMaterial({
			color: "#d8dce2",
			roughness: .35,
			metalness: .55
		});
		const fuse = new Mesh(new CylinderGeometry(.7, .55, 9.2, 10), alum);
		fuse.rotation.x = Math.PI / 2;
		fuse.position.y = 1.4;
		const wing = new Mesh(new BoxGeometry(14, .14, 2.2), alum);
		wing.position.set(0, 1.35, .2);
		const tail = new Mesh(new BoxGeometry(.14, 2.1, 1.6), alum);
		tail.position.set(0, 2.35, 4.2);
		const stab = new Mesh(new BoxGeometry(4.2, .1, 1.1), alum);
		stab.position.set(0, 2.7, 4.1);
		const nose = new Mesh(new SphereGeometry(.62, 10, 8), alum);
		nose.scale.set(1, 1, 1.3);
		nose.position.set(0, 1.4, -4.7);
		const stripe = new Mesh(new BoxGeometry(.02, .28, 8.4), new MeshStandardMaterial({ color: "#1e4d8c" }));
		stripe.position.set(.72, 1.55, 0);
		const eng = new Mesh(new CylinderGeometry(.28, .32, 1.5, 8), alum);
		eng.rotation.x = Math.PI / 2;
		eng.position.set(-2.4, 1.05, .3);
		const eng2 = eng.clone();
		eng2.position.x = 2.4;
		plane.add(fuse, wing, tail, stab, nose, stripe, eng, eng2);
		plane.position.set(cx + 38, this.heightAt(cx + 38, cz - 40), cz - 40);
		plane.rotation.y = .4;
		this.group.add(plane);
		this.buildings.push({
			x: cx + 38,
			z: cz - 40,
			w: 11,
			d: 10,
			h: 3
		});
		const sock = new Mesh(new ConeGeometry(.35, 1.8, 6), new MeshStandardMaterial({
			color: "#e24a3b",
			roughness: .7
		}));
		sock.rotation.z = Math.PI / 2;
		sock.position.set(cx - 22, this.heightAt(cx - 22, cz + 50) + 4.2, cz + 50);
		const pole = new Mesh(new CylinderGeometry(.08, .1, 4.4, 6), new MeshStandardMaterial({ color: "#dce0e6" }));
		pole.position.set(cx - 22, this.heightAt(cx - 22, cz + 50) + 2.2, cz + 50);
		this.group.add(sock, pole);
		this.addSign(cx, cz + 50, "REPÜLŐ", "#e24a3b");
	}
	placeSuburb() {
		const dummy = new Object3D();
		const bodyGeo = new BoxGeometry(1, 1, 1);
		bodyGeo.translate(0, .5, 0);
		const wall = new MeshStandardMaterial({
			map: houseFacadeTexture(),
			roughness: .85
		});
		const houses = [];
		for (let i = 0; i < 90; i++) {
			const a = hash2(i, 2) * Math.PI * 2;
			const r = 142 + hash2(i, 5) * 40;
			const x = Math.cos(a) * r;
			const z = Math.sin(a) * r;
			if (this.onRoad(x, z) || this.skipNear(x, z, 14)) continue;
			const b = biomeAt(x, z);
			if (b !== "suburb" && b !== "hills") continue;
			houses.push({
				x,
				z,
				s: 6.5 + hash2(i, 8) * 2.2,
				yaw: Math.floor(hash2(i, 9) * 4) * (Math.PI / 2),
				col: [
					13153434,
					12108976,
					13682876,
					11055268
				][i % 4]
			});
			this.buildings.push({
				x,
				z,
				w: 8,
				d: 8,
				h: 4.2
			});
		}
		const mesh = new InstancedMesh(bodyGeo, wall, houses.length);
		mesh.castShadow = true;
		mesh.receiveShadow = true;
		const color = new Color();
		for (let i = 0; i < houses.length; i++) {
			const h = houses[i];
			dummy.position.set(h.x, this.heightAt(h.x, h.z), h.z);
			dummy.scale.set(h.s, 3.6, h.s * .85);
			dummy.rotation.set(0, h.yaw, 0);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
			color.setHex(h.col);
			mesh.setColorAt(i, color);
		}
		if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
		this.group.add(mesh);
		const roofGeo = new ConeGeometry(.85, 1.1, 4);
		roofGeo.rotateY(Math.PI / 4);
		const roofMat = new MeshStandardMaterial({
			color: "#6a4038",
			roughness: .9
		});
		const roofs = new InstancedMesh(roofGeo, roofMat, houses.length);
		for (let i = 0; i < houses.length; i++) {
			const h = houses[i];
			dummy.position.set(h.x, this.heightAt(h.x, h.z) + 4.15, h.z);
			dummy.scale.set(h.s * .85, 1.4, h.s * .75);
			dummy.rotation.set(0, h.yaw, 0);
			dummy.updateMatrix();
			roofs.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(roofs);
	}
	placeNature() {
		const dummy = new Object3D();
		const trunkGeo = new CylinderGeometry(.18, .28, 2.2, 5);
		trunkGeo.translate(0, 1.1, 0);
		const trunkMat = new MeshStandardMaterial({
			color: "#4a3424",
			roughness: .95
		});
		const leafGeo = new ConeGeometry(1.4, 3.6, 6);
		leafGeo.translate(0, 3.4, 0);
		const leafMat = new MeshStandardMaterial({
			color: "#2f5a34",
			roughness: .85
		});
		const leaf2Geo = new ConeGeometry(1.05, 2.4, 6);
		leaf2Geo.translate(0, 4.6, 0);
		const treePos = [];
		for (let i = 0; i < 300; i++) {
			const x = (hash2(i, 11) - .5) * SIZE * .92;
			const z = (hash2(i, 29) - .5) * SIZE * .92;
			const b = biomeAt(x, z);
			if (b !== "forest" && b !== "hills" && b !== "suburb" && b !== "coast") continue;
			if (b === "suburb" && hash2(i, 3) > .28) continue;
			if (b === "coast" && hash2(i, 4) > .18) continue;
			if (this.onRoad(x, z)) continue;
			if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 6) continue;
			if (Math.hypot(x + 412, z - 118) < 10) continue;
			if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 58) continue;
			if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 90) continue;
			const s = .75 + hash2(i, 7) * 1.15;
			treePos.push({
				x,
				z,
				s
			});
			this.trees.push({
				x,
				z,
				r: .9 * s
			});
		}
		const trunks = new InstancedMesh(trunkGeo, trunkMat, treePos.length);
		trunks.castShadow = true;
		const leaves = new InstancedMesh(leafGeo, leafMat, treePos.length);
		leaves.castShadow = true;
		const leaves2 = new InstancedMesh(leaf2Geo, leafMat, treePos.length);
		const leafCol = new Color();
		for (let i = 0; i < treePos.length; i++) {
			const t = treePos[i];
			dummy.position.set(t.x, this.heightAt(t.x, t.z), t.z);
			dummy.scale.setScalar(t.s);
			dummy.rotation.y = hash2(i, 1) * Math.PI * 2;
			dummy.updateMatrix();
			trunks.setMatrixAt(i, dummy.matrix);
			dummy.scale.set(t.s * (.85 + hash2(i, 2) * .4), t.s, t.s * (.85 + hash2(i, 5) * .4));
			dummy.updateMatrix();
			leaves.setMatrixAt(i, dummy.matrix);
			dummy.scale.set(t.s * .9, t.s * .95, t.s * .9);
			dummy.updateMatrix();
			leaves2.setMatrixAt(i, dummy.matrix);
			leafCol.setHSL(.28 + hash2(i, 8) * .08, .44, .28 + hash2(i, 9) * .1);
			leaves.setColorAt(i, leafCol);
			leaves2.setColorAt(i, leafCol);
		}
		if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
		if (leaves2.instanceColor) leaves2.instanceColor.needsUpdate = true;
		this.group.add(trunks, leaves, leaves2);
		const rockGeo = new DodecahedronGeometry(1.1, 0);
		const rockMat = new MeshStandardMaterial({
			color: "#8a8074",
			roughness: .95
		});
		const rocks = [];
		for (let i = 0; i < 160; i++) {
			const x = (hash2(i, 41) - .5) * SIZE * .9;
			const z = (hash2(i, 43) - .5) * SIZE * .9;
			const b = biomeAt(x, z);
			if (b !== "desert" && b !== "hills" && b !== "coast") continue;
			if (this.onRoad(x, z)) continue;
			rocks.push({
				x,
				z,
				s: .6 + hash2(i, 12) * 1.8
			});
		}
		const rockMesh = new InstancedMesh(rockGeo, rockMat, rocks.length);
		for (let i = 0; i < rocks.length; i++) {
			const r = rocks[i];
			dummy.position.set(r.x, this.heightAt(r.x, r.z) + .2, r.z);
			dummy.scale.setScalar(r.s);
			dummy.rotation.set(hash2(i, 1), hash2(i, 2), hash2(i, 3));
			dummy.updateMatrix();
			rockMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(rockMesh);
		const cactGeo = new CylinderGeometry(.18, .22, 2.4, 6);
		cactGeo.translate(0, 1.2, 0);
		const cactMat = new MeshStandardMaterial({ color: "#3d6a3a" });
		const cacti = [];
		for (let i = 0; i < 110; i++) {
			const x = (hash2(i, 61) - .5) * 520;
			const z = -240 - hash2(i, 62) * 220;
			if (biomeAt(x, z) !== "desert" || this.onRoad(x, z)) continue;
			cacti.push({
				x,
				z
			});
		}
		const cactMesh = new InstancedMesh(cactGeo, cactMat, cacti.length);
		for (let i = 0; i < cacti.length; i++) {
			const p = cacti[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z), p.z);
			dummy.scale.set(1, .8 + hash2(i, 3) * 1.4, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			cactMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(cactMesh);
		const hayGeo = new CylinderGeometry(.85, .85, 1.3, 8);
		hayGeo.rotateZ(Math.PI / 2);
		const hayMat = new MeshStandardMaterial({
			color: "#c8a84a",
			roughness: .92
		});
		const hays = [];
		for (let i = 0; i < 70; i++) {
			const x = 240 + hash2(i, 71) * 200;
			const z = (hash2(i, 72) - .5) * 220;
			if (biomeAt(x, z) !== "country" || this.onRoad(x, z)) continue;
			hays.push({
				x,
				z
			});
		}
		const hayMesh = new InstancedMesh(hayGeo, hayMat, hays.length);
		for (let i = 0; i < hays.length; i++) {
			const p = hays[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z) + .7, p.z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, hash2(i, 3) * Math.PI, .1);
			dummy.updateMatrix();
			hayMesh.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(hayMesh);
		const palmTrunkGeo = new CylinderGeometry(.16, .28, 5.2, 6);
		palmTrunkGeo.translate(0, 2.6, 0);
		const palmTrunkMat = new MeshStandardMaterial({
			color: "#6a5340",
			roughness: .92
		});
		const palmLeafGeo = new SphereGeometry(1.6, 6, 5);
		palmLeafGeo.scale(1, .28, 1);
		const palmLeafMat = new MeshStandardMaterial({
			color: "#2f6a38",
			roughness: .82
		});
		const palms = [];
		for (let i = 0; i < 70; i++) {
			const x = (hash2(i, 81) - .5) * 280;
			const z = 280 + hash2(i, 82) * 180;
			if (biomeAt(x, z) !== "coast") continue;
			if (this.onRoad(x, z)) continue;
			if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 8) continue;
			palms.push({
				x,
				z,
				s: .85 + hash2(i, 83) * .7
			});
			this.trees.push({
				x,
				z,
				r: .55
			});
		}
		const palmTrunks = new InstancedMesh(palmTrunkGeo, palmTrunkMat, palms.length);
		palmTrunks.castShadow = true;
		const palmLeaves = new InstancedMesh(palmLeafGeo, palmLeafMat, palms.length);
		palmLeaves.castShadow = true;
		for (let i = 0; i < palms.length; i++) {
			const p = palms[i];
			dummy.position.set(p.x, this.heightAt(p.x, p.z), p.z);
			dummy.scale.setScalar(p.s);
			dummy.rotation.set(0, hash2(i, 4) * Math.PI, 0);
			dummy.updateMatrix();
			palmTrunks.setMatrixAt(i, dummy.matrix);
			dummy.position.y += 5.1 * p.s;
			dummy.scale.set(p.s * 1.4, p.s, p.s * 1.4);
			dummy.updateMatrix();
			palmLeaves.setMatrixAt(i, dummy.matrix);
		}
		this.group.add(palmTrunks, palmLeaves);
	}
	placeLandmarks() {
		const garage = this.makeShed(18, 7, 14, "#6a7380", "#3a4048");
		garage.position.set(52, this.heightAt(52, 28), 28);
		this.group.add(garage);
		this.buildings.push({
			x: 52,
			z: 28,
			w: 18,
			d: 14,
			h: 7
		});
		this.addSign(52, 28, "MŰHELY", "#8aa4b8");
		const dealer = this.makeShed(20, 6, 16, "#d8dce2", "#2a3038");
		dealer.position.set(-56, this.heightAt(-56, 28), 28);
		this.group.add(dealer);
		this.buildings.push({
			x: -56,
			z: 28,
			w: 20,
			d: 16,
			h: 6
		});
		this.addSign(-56, 28, "AUTÓ", "#dce0e6");
		const taxi = this.makeShed(10, 3.4, 8, "#e8b86d", "#2a2c30");
		taxi.position.set(8, this.heightAt(8, 88), 88);
		this.group.add(taxi);
		this.buildings.push({
			x: 8,
			z: 88,
			w: 10,
			d: 8,
			h: 3.4
		});
		this.addSign(8, 88, "TAXI", "#e8b86d");
		const courier = this.makeShed(14, 6.2, 12, "#3d6a58", "#1c2a24");
		courier.position.set(-88, this.heightAt(-88, -44), -44);
		this.group.add(courier);
		this.buildings.push({
			x: -88,
			z: -44,
			w: 14,
			d: 12,
			h: 6.2
		});
		this.addSign(-88, -44, "FUTÁR", "#5ecf9a");
		const market = this.makeShed(12, 4.5, 10, "#c45c3a", "#5a3028");
		market.position.set(92, this.heightAt(92, -36), -36);
		this.group.add(market);
		this.buildings.push({
			x: 92,
			z: -36,
			w: 12,
			d: 10,
			h: 4.5
		});
		this.addSign(92, -36, "PIAC", "#c45c3a");
		const house = this.makeShed(8, 4.2, 8, "#e8c4a8", "#6a4038");
		house.position.set(318, this.heightAt(318, 42), 42);
		this.group.add(house);
		this.buildings.push({
			x: 318,
			z: 42,
			w: 8,
			d: 8,
			h: 4.2
		});
		const dock = new Mesh(new BoxGeometry(4.2, .28, 18), new MeshStandardMaterial({ color: "#6a5340" }));
		dock.position.set(-36, this.waterY + .2, 392);
		this.group.add(dock);
		const secret = new Mesh(new BoxGeometry(3.4, 1.15, 4.4), new MeshStandardMaterial({
			color: "#c8d4dc",
			emissive: "#3a6a78",
			emissiveIntensity: .3,
			metalness: .6,
			roughness: .25
		}));
		secret.position.set(-412, this.heightAt(-412, 118) + .7, 118);
		secret.name = "hiddenCar";
		this.hiddenMesh = secret;
		this.group.add(secret);
		const van = this.makeIceCreamVan();
		van.position.set(48, this.heightAt(48, 348), 348);
		this.group.add(van);
		this.buildings.push({
			x: 48,
			z: 348,
			w: 5,
			d: 7,
			h: 3.2
		});
		const umbrellaGeo = new ConeGeometry(1.8, .45, 8);
		const umbrellaMat = new MeshStandardMaterial({ color: "#e8b86d" });
		for (let i = 0; i < 6; i++) {
			const x = 30 + i * 8;
			const z = 370 + i % 2 * 8;
			const u = new Mesh(umbrellaGeo, umbrellaMat);
			u.position.set(x, this.heightAt(x, z) + 2.2, z);
			const pole = new Mesh(new CylinderGeometry(.05, .05, 2.2, 5), new MeshStandardMaterial({ color: "#dce0e6" }));
			pole.position.set(x, this.heightAt(x, z) + 1.1, z);
			this.group.add(u, pole);
		}
		this.addWindmill(372, 88);
		this.addDog(312, 46);
		this.addParkedCars();
	}
	addSign(x, z, _label, color) {
		const pole = new Mesh(new CylinderGeometry(.08, .1, 3.6, 6), new MeshStandardMaterial({ color: "#2a2c30" }));
		pole.position.set(x - 8, this.heightAt(x, z) + 1.8, z + 8);
		const board = new Mesh(new BoxGeometry(2.4, .9, .12), new MeshStandardMaterial({
			color,
			emissive: color,
			emissiveIntensity: .2
		}));
		board.position.set(x - 8, this.heightAt(x, z) + 3.4, z + 8);
		this.group.add(pole, board);
	}
	makeIceCreamVan() {
		const g = new Group();
		const body = new Mesh(new BoxGeometry(2.2, 1.6, 4.2), new MeshStandardMaterial({ color: "#f2efe8" }));
		body.position.y = 1.15;
		const stripe = new Mesh(new BoxGeometry(2.24, .28, 4.24), new MeshStandardMaterial({ color: "#5ecf9a" }));
		stripe.position.y = 1.35;
		const roof = new Mesh(new BoxGeometry(2, .35, 2.2), new MeshStandardMaterial({ color: "#e24a3b" }));
		roof.position.set(0, 2.1, .2);
		const scoop = new Mesh(new SphereGeometry(.45, 10, 8), new MeshStandardMaterial({ color: "#f2d2c4" }));
		scoop.position.set(0, 2.55, .2);
		g.add(body, stripe, roof, scoop);
		return g;
	}
	makeShed(w, h, d, wall, roof) {
		const g = new Group();
		const body = new Mesh(new BoxGeometry(w, h, d), new MeshStandardMaterial({
			color: wall,
			roughness: .8
		}));
		body.position.y = h / 2;
		const rf = new Mesh(new BoxGeometry(w + .8, .35, d + .8), new MeshStandardMaterial({ color: roof }));
		rf.position.y = h + .1;
		const door = new Mesh(new BoxGeometry(w * .35, h * .55, .12), new MeshStandardMaterial({ color: "#1c1f26" }));
		door.position.set(0, h * .32, d / 2 + .02);
		g.add(body, rf, door);
		return g;
	}
	addWindmill(x, z) {
		const y = this.heightAt(x, z);
		const tower = new Mesh(new CylinderGeometry(1.1, 1.6, 11, 8), new MeshStandardMaterial({
			color: "#d8d4c8",
			roughness: .86
		}));
		tower.position.set(x, y + 5.5, z);
		tower.castShadow = true;
		const cap = new Mesh(new ConeGeometry(1.6, 1.8, 8), new MeshStandardMaterial({ color: "#6a4038" }));
		cap.position.set(x, y + 12.1, z);
		const blades = new Group();
		const bladeMat = new MeshStandardMaterial({
			color: "#ece8e0",
			roughness: .7
		});
		for (let i = 0; i < 4; i++) {
			const b = new Mesh(new BoxGeometry(.28, 7.2, .7), bladeMat);
			b.position.y = 3.2;
			const arm = new Group();
			arm.rotation.z = i * Math.PI / 2;
			arm.add(b);
			blades.add(arm);
		}
		blades.position.set(x, y + 11.2, z + 1.2);
		this.windmillBlades = blades;
		this.group.add(tower, cap, blades);
		this.buildings.push({
			x,
			z,
			w: 3.4,
			d: 3.4,
			h: 12
		});
	}
	addDog(x, z) {
		const g = new Group();
		const fur = new MeshStandardMaterial({
			color: "#6a5340",
			roughness: .9
		});
		const body = new Mesh(new CapsuleGeometry(.22, .45, 3, 6), fur);
		body.rotation.z = Math.PI / 2;
		body.position.y = .32;
		const head = new Mesh(new SphereGeometry(.18, 8, 6), fur);
		head.position.set(.38, .42, 0);
		const ear = new Mesh(new ConeGeometry(.08, .16, 5), fur);
		ear.position.set(.32, .58, .1);
		const tail = new Mesh(new CylinderGeometry(.04, .03, .35, 5), fur);
		tail.position.set(-.38, .42, 0);
		tail.rotation.z = .7;
		g.add(body, head, ear, tail);
		g.position.set(x, this.heightAt(x, z), z);
		g.name = "bodri";
		this.group.add(g);
	}
	addParkedCars() {
		const dummy = new Object3D();
		const bodyGeo = new BoxGeometry(1.7, .55, 3.6);
		bodyGeo.translate(0, .55, 0);
		const bodyMat = new MeshStandardMaterial({
			roughness: .38,
			metalness: .42
		});
		const spots = [];
		const cols = [
			4021370,
			9080984,
			12868666,
			1985932,
			2763824,
			14210248
		];
		for (let i = 0; i < 18; i++) {
			const a = i / 18 * Math.PI * 2;
			const r = 148 + i % 3 * 4;
			const x = Math.cos(a) * r;
			const z = Math.sin(a) * r;
			if (this.onRoad(x, z) || this.skipNear(x, z, 12)) continue;
			spots.push({
				x,
				z,
				yaw: a + Math.PI / 2,
				col: cols[i % cols.length]
			});
			this.buildings.push({
				x,
				z,
				w: 2.2,
				d: 4.2,
				h: 1.4
			});
		}
		const mesh = new InstancedMesh(bodyGeo, bodyMat, spots.length);
		mesh.castShadow = true;
		const color = new Color();
		for (let i = 0; i < spots.length; i++) {
			const s = spots[i];
			dummy.position.set(s.x, this.heightAt(s.x, s.z), s.z);
			dummy.rotation.set(0, s.yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
			color.setHex(s.col);
			mesh.setColorAt(i, color);
		}
		if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
		this.group.add(mesh);
	}
	placePois() {
		for (const p of POIS) {
			if (p.id === "statue" || p.id === "hidden") continue;
			const ring = new Mesh(new TorusGeometry(2.4, .09, 6, 22), new MeshStandardMaterial({
				color: p.color,
				emissive: p.color,
				emissiveIntensity: .4
			}));
			ring.rotation.x = Math.PI / 2;
			ring.position.set(p.x, this.heightAt(p.x, p.z) + .22, p.z);
			ring.userData.poi = p.id;
			this.group.add(ring);
			const sprite = new Sprite(new SpriteMaterial({
				map: poiLabelTexture(p.name, p.color),
				transparent: true,
				depthWrite: false
			}));
			sprite.position.set(p.x, this.heightAt(p.x, p.z) + 4.6, p.z);
			sprite.scale.set(10.5, 2, 1);
			this.group.add(sprite);
		}
	}
	placeClouds() {
		const g = new Group();
		const geo = new SphereGeometry(1, 8, 6);
		const mat = new MeshBasicMaterial({
			color: 16054008,
			transparent: true,
			opacity: .55
		});
		const dummy = new Object3D();
		const n = 36;
		const mesh = new InstancedMesh(geo, mat, n);
		for (let i = 0; i < n; i++) {
			dummy.position.set((hash2(i, 1) - .5) * 900, 70 + hash2(i, 2) * 50, (hash2(i, 3) - .5) * 900);
			dummy.scale.set(18 + hash2(i, 4) * 22, 6 + hash2(i, 5) * 6, 12 + hash2(i, 6) * 16);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		g.add(mesh);
		this.clouds = g;
		this.group.add(g);
	}
	collide(x, z, radius) {
		let best = null;
		let bestD = 0;
		for (const b of this.buildings) {
			const px = clamp$1(x, b.x - b.w / 2, b.x + b.w / 2);
			const pz = clamp$1(z, b.z - b.d / 2, b.z + b.d / 2);
			const dx = x - px;
			const dz = z - pz;
			const d2 = dx * dx + dz * dz;
			if (d2 < radius * radius) {
				const d = Math.sqrt(d2) || 1e-4;
				const depth = radius - d;
				if (depth > bestD) {
					bestD = depth;
					best = {
						nx: dx / d,
						nz: dz / d,
						depth
					};
				}
			}
		}
		for (const t of this.trees) {
			const dx = x - t.x;
			const dz = z - t.z;
			const d = Math.hypot(dx, dz) || 1e-4;
			const min = radius + t.r;
			if (d < min) {
				const depth = min - d;
				if (depth > bestD) {
					bestD = depth;
					best = {
						nx: dx / d,
						nz: dz / d,
						depth
					};
				}
			}
		}
		const lim = 476;
		if (Math.abs(x) > lim) {
			const depth = Math.abs(x) - lim;
			if (depth > bestD) best = {
				nx: -Math.sign(x),
				nz: 0,
				depth
			};
		}
		if (Math.abs(z) > lim) {
			const depth = Math.abs(z) - lim;
			if (depth > bestD) best = {
				nx: 0,
				nz: -Math.sign(z),
				depth
			};
		}
		return best;
	}
};
function clamp$1(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function clamp01(v) {
	return clamp$1(v, 0, 1);
}
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
var _fwd = new Vector3();
var Vehicle = class {
	x = 18;
	y = .5;
	z = 48;
	yaw = 0;
	vx = 0;
	vz = 0;
	vy = 0;
	speed = 0;
	steerAngle = 0;
	airborne = false;
	drifting = false;
	driftCharge = 0;
	boostT = 0;
	rpm = 900;
	gear = 1;
	wheelSpin = 0;
	airTime = 0;
	jumpPeak = 0;
	smoothnessAcc = 0;
	lastImpact = 0;
	braking = false;
	squash = 1;
	reset(x, z, yaw = 0) {
		this.x = x;
		this.z = z;
		this.y = .5;
		this.yaw = yaw;
		this.vx = this.vz = this.vy = 0;
		this.speed = 0;
		this.airborne = false;
		this.driftCharge = 0;
		this.boostT = 0;
		this.airTime = 0;
		this.squash = 1;
	}
	forward(out = _fwd) {
		out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
		return out;
	}
	step(dt, steer, throttle, brake, handbrake, stats, groundY, surfaceMul, offroad) {
		const hit = {
			impact: 0,
			landed: 0,
			drifting: false,
			boostPop: false
		};
		this.braking = brake > .15 && Math.abs(this.speed) > 1;
		const maxSpd = stats.maxSpeed * (this.boostT > 0 ? 1.12 + stats.turbo * .04 : 1) * surfaceMul;
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const rx = Math.cos(this.yaw);
		const rz = -Math.sin(this.yaw);
		if (!this.airborne) {
			this.vx += fx * stats.accel * throttle * dt * (offroad ? .72 : 1);
			this.vz += fz * stats.accel * throttle * dt * (offroad ? .72 : 1);
			if (brake > .05) {
				const sp = Math.hypot(this.vx, this.vz);
				if (sp > 1.2) {
					const k = stats.brake * brake * dt;
					this.vx -= this.vx / sp * k;
					this.vz -= this.vz / sp * k;
				} else {
					this.vx -= fx * stats.accel * .42 * brake * dt;
					this.vz -= fz * stats.accel * .42 * brake * dt;
				}
			}
		}
		let fwd = this.vx * fx + this.vz * fz;
		let lat = this.vx * rx + this.vz * rz;
		const absFwd = Math.abs(fwd);
		const speedFactor = clamp(absFwd / 7, 0, 1) * (1 - .42 * clamp(absFwd / Math.max(8, maxSpd), 0, 1));
		const reverse = fwd >= 0 ? 1 : -1;
		this.yaw += steer * stats.turn * speedFactor * reverse * dt;
		this.steerAngle += (steer * .42 - this.steerAngle) * (1 - Math.exp(-12 * dt));
		const wantDrift = handbrake && absFwd > 8 && Math.abs(steer) > .2 || Math.abs(lat) > 4.2 && absFwd > 12 && Math.abs(steer) > .35;
		const wasDrift = this.drifting;
		this.drifting = wantDrift && !this.airborne;
		hit.drifting = this.drifting;
		const gripK = this.drifting ? stats.grip * .38 : stats.grip * (offroad ? .55 : 1);
		lat *= Math.exp(-gripK * dt);
		if (this.drifting) {
			lat += -steer * fwd * .55 * dt;
			this.driftCharge = clamp(this.driftCharge + dt * (.55 + Math.abs(steer) * .5), 0, 1);
		} else if (wasDrift && this.driftCharge > .35) {
			this.boostT = .9 + this.driftCharge * .5;
			this.driftCharge = 0;
			hit.boostPop = true;
		} else this.driftCharge = Math.max(0, this.driftCharge - dt * .8);
		fwd *= Math.exp(-((offroad ? 1.15 : .32) + (throttle < .05 ? .55 : 0) + (handbrake ? 1.1 : 0)) * dt);
		if (this.boostT > 0) {
			fwd += stats.accel * .55 * dt;
			this.boostT = Math.max(0, this.boostT - dt);
		}
		fwd = clamp(fwd, -maxSpd * .32, maxSpd);
		this.vx = fx * fwd + rx * lat;
		this.vz = fz * fwd + rz * lat;
		this.speed = fwd;
		this.x += this.vx * dt;
		this.z += this.vz * dt;
		if (!Number.isFinite(this.x) || !Number.isFinite(this.z)) {
			this.reset(18, 52, 0);
			return hit;
		}
		const g = groundY + .42;
		if (this.y > g + .28 || this.vy > .8) {
			this.airborne = true;
			this.vy -= 26 * dt;
			this.y += this.vy * dt;
			this.airTime += dt;
			this.jumpPeak = Math.max(this.jumpPeak, this.y - g);
			this.squash = clamp(1 + Math.abs(this.vy) * .012, .92, 1.12);
			if (this.y <= g) {
				hit.landed = Math.max(0, -this.vy);
				this.y = g;
				this.vy = 0;
				this.airborne = false;
				this.squash = clamp(1 - hit.landed * .018, .78, 1);
				if (hit.landed > 8) {
					this.vx *= .82;
					this.vz *= .82;
				}
			}
		} else {
			this.airborne = false;
			this.vy = 0;
			this.y += (g - this.y) * (1 - Math.exp(-18 * dt));
			this.airTime = 0;
			this.jumpPeak = 0;
			this.squash += (1 - this.squash) * (1 - Math.exp(-10 * dt));
		}
		const kmh = Math.abs(this.speed) * 3.6;
		const gearTop = [
			0,
			18,
			32,
			48,
			70,
			100,
			160,
			260
		];
		let gIdx = 1;
		while (gIdx < 6 && kmh > gearTop[gIdx + 1]) gIdx++;
		this.gear = gIdx;
		const g0 = gearTop[gIdx];
		const g1 = gearTop[gIdx + 1];
		const t = clamp((kmh - g0) / Math.max(1, g1 - g0), 0, 1);
		this.rpm = 900 + t * 5200 + throttle * 400;
		this.wheelSpin += this.speed / .32 * dt;
		this.smoothnessAcc += (Math.abs(lat) * .04 + (handbrake ? .3 : 0)) * dt;
		return hit;
	}
	applyCollision(nx, nz, depth) {
		this.x += nx * depth;
		this.z += nz * depth;
		const vn = this.vx * nx + this.vz * nz;
		if (vn < 0) {
			this.vx -= vn * nx * 1.55;
			this.vz -= vn * nz * 1.55;
			this.lastImpact = -vn;
			return -vn;
		}
		this.lastImpact = 0;
		return 0;
	}
};
function mat(color, extra) {
	return new MeshStandardMaterial({
		color,
		roughness: .38,
		metalness: .42,
		...extra
	});
}
function buildCarMesh(def, opts) {
	const g = new Group();
	g.name = "car";
	const shiny = def.body === "super" || def.body === "coupe" || def.body === "ev" || def.body === "cabrio";
	const bodyMat = mat(def.color, {
		roughness: shiny ? .22 : def.body === "van" || def.body === "pickup" ? .55 : .34,
		metalness: shiny ? .62 : .38
	});
	const accent = mat(def.accent, {
		roughness: .46,
		metalness: .35
	});
	const glass = mat(def.glass, {
		roughness: .08,
		metalness: .55,
		transparent: true,
		opacity: .62
	});
	const dark = mat("#141518", {
		roughness: .72,
		metalness: .15
	});
	const chrome = mat("#c8ccd2", {
		roughness: .16,
		metalness: .88
	});
	const lightMat = new MeshStandardMaterial({
		color: "#f7f1d4",
		emissive: "#f2e4a8",
		emissiveIntensity: 1.1,
		roughness: .28
	});
	const tailMat = new MeshStandardMaterial({
		color: "#e24a3b",
		emissive: "#c02820",
		emissiveIntensity: .45,
		roughness: .38
	});
	const tailMat2 = tailMat.clone();
	const style = def.body;
	let w = 1.72, h = .5, len = 4.1;
	if (style === "hatch") {
		w = 1.64;
		h = .48;
		len = 3.62;
	}
	if (style === "van") {
		w = 1.88;
		h = .88;
		len = 4.7;
	}
	if (style === "pickup") {
		w = 1.82;
		h = .52;
		len = 4.55;
	}
	if (style === "coupe" || style === "super") {
		w = 1.82;
		h = .38;
		len = 4.28;
	}
	if (style === "muscle") {
		w = 1.9;
		h = .46;
		len = 4.55;
	}
	if (style === "ev") {
		w = 1.84;
		h = .38;
		len = 4.22;
	}
	if (style === "estate") {
		w = 1.78;
		h = .52;
		len = 4.55;
	}
	if (style === "moto") {
		w = .72;
		h = .42;
		len = 2.15;
	}
	if (style === "bus") {
		w = 2.35;
		h = 1.35;
		len = 8.4;
	}
	if (style === "truck") {
		w = 2.2;
		h = .7;
		len = 8.8;
	}
	if (style === "suv") {
		w = 1.92;
		h = .72;
		len = 4.45;
	}
	if (style === "cabrio") {
		w = 1.78;
		h = .36;
		len = 4.15;
	}
	const add = (mesh) => {
		if (mesh instanceof Mesh) {
			mesh.castShadow = true;
			mesh.receiveShadow = true;
		}
		g.add(mesh);
		return mesh;
	};
	const box = (bw, bh, bd, m, x, y, z) => {
		const mesh = new Mesh(new BoxGeometry(bw, bh, bd), m);
		mesh.position.set(x, y, z);
		add(mesh);
		return mesh;
	};
	const chassisY = .34;
	box(w * .92, .16, len * .92, dark, 0, chassisY, 0);
	if (style === "van") {
		box(w, h, len * .55, bodyMat, 0, .52 + h / 2, .55);
		box(w * .96, 1.12, 2.55, accent, 0, 1.18, .62);
		const cab = box(w * .9, .72, 1.15, glass, 0, 1.08, -1.42);
		cab.rotation.x = -.08;
		box(w * .98, .22, .9, bodyMat, 0, .6200000000000001, -1.85);
	} else if (style === "pickup") {
		box(w, h, len * .62, bodyMat, 0, .46 + h / 2, -.35);
		box(w * .9, .68, 1.28, glass, 0, .98, -.52);
		box(w * .92, .22, 1.72, dark, 0, .58, 1.22);
		box(w * .08, .38, 1.7, accent, -w * .42, .72, 1.22);
		box(w * .08, .38, 1.7, accent, w * .42, .72, 1.22);
		box(w * .9, .08, .08, accent, 0, .9, 2.05);
	} else if (style === "moto") {
		box(.22, .28, 1.55, dark, 0, .42, 0);
		box(.38, .18, .55, bodyMat, 0, .62, -.15);
		box(.32, .12, .4, accent, 0, .55, .55);
		box(.28, .2, .7, bodyMat, 0, .72, -.05);
		box(.42, .08, .28, dark, 0, .92, .12);
		const rider = new Mesh(new CapsuleGeometry(.16, .32, 3, 6), mat("#3d5c7a", {
			roughness: .75,
			metalness: .1
		}));
		rider.position.set(0, 1.05, .05);
		rider.rotation.x = .35;
		add(rider);
		const helm = new Mesh(new SphereGeometry(.16, 8, 6), accent);
		helm.position.set(0, 1.38, -.12);
		add(helm);
	} else if (style === "bus") {
		box(w, 1.55, len * .96, bodyMat, 0, 1.15, 0);
		box(w * .92, .85, len * .72, glass, 0, 1.55, .15);
		box(w * .7, .7, .9, glass, 0, 1.45, -len * .42);
		box(w * .98, .18, len * .98, accent, 0, .52, 0);
		box(.18, .9, .06, dark, w * .48, 1.05, -.8);
		box(.18, .9, .06, dark, w * .48, 1.05, 1.4);
	} else if (style === "truck") {
		box(w * .92, .85, 2.2, bodyMat, 0, 1.05, -2.8);
		box(w * .82, .7, 1.15, glass, 0, 1.55, -2.95);
		box(w * .96, 1.7, 5.4, accent, 0, 1.45, 1.15);
		box(w * .7, .22, .7, dark, 0, .48, -2.2);
	} else if (style === "suv") {
		box(w, h, len * .78, bodyMat, 0, .46 + h / 2, .05);
		box(w * .86, .62, 1.55, glass, 0, chassisY + h + .42, -.05);
		box(w * .9, .08, 1.7, dark, 0, chassisY + h + .78, -.02);
		box(.08, .12, len * .55, chrome, -w * .48, chassisY + h + .72, 0);
		box(.08, .12, len * .55, chrome, w * .48, chassisY + h + .72, 0);
		box(w * .92, .18, .55, dark, 0, .6200000000000001, len * .32);
	} else if (style === "cabrio") {
		box(w, h, len * .76, bodyMat, 0, .44000000000000006 + h / 2, 0);
		const cabHood = box(w * .9, h * .7, 1.05, bodyMat, 0, .42000000000000004 + h * .38, -len * .28);
		cabHood.rotation.x = .06;
		box(w * .82, .28, .12, glass, 0, chassisY + h + .32, -.55);
		box(.28, .12, .38, dark, -.32, chassisY + h + .18, .12);
		box(.28, .12, .38, dark, .32, chassisY + h + .18, .12);
		const driver = new Mesh(new CapsuleGeometry(.16, .28, 3, 6), mat("#3d5c7a", {
			roughness: .75,
			metalness: .1
		}));
		driver.position.set(-.28, .95, .05);
		add(driver);
	} else {
		const bodyH = h;
		const bodyZ = style === "hatch" ? .08 : 0;
		box(w, bodyH, len * .78, bodyMat, 0, .44000000000000006 + bodyH / 2, bodyZ);
		const hoodLen = style === "muscle" ? 1.35 : style === "super" ? 1.2 : 1.05;
		const hood = box(w * .92, bodyH * .72, hoodLen, bodyMat, 0, .42000000000000004 + bodyH * .4, -len * .28);
		hood.rotation.x = style === "super" || style === "coupe" ? .08 : .04;
		const cabinL = style === "hatch" ? 1.28 : style === "sedan" || style === "estate" ? 1.5 : 1.62;
		const cabin = box(w * .82, .52, cabinL, glass, 0, chassisY + bodyH + .38, style === "hatch" ? .12 : -.08);
		cabin.rotation.x = -.12;
		box(w * .78, .06, cabinL * .92, dark, 0, chassisY + bodyH + .64, cabin.position.z);
		if (style === "sedan" || style === "hatch") box(w * .94, bodyH * .62, .78, bodyMat, 0, .42000000000000004 + bodyH * .32, len * .32);
		if (style === "estate") {
			box(w * .9, .62, 1.35, bodyMat, 0, chassisY + bodyH * .55, len * .28);
			box(w * .78, .45, 1.1, glass, 0, chassisY + bodyH + .28, len * .22);
		}
	}
	if (style === "super" || style === "coupe" || style === "ev") {
		const spoiler = box(w * .88, .05, .28, accent, 0, .92, len * .42);
		spoiler.rotation.x = .12;
		box(.05, .2, .05, accent, -.58, .84, len * .4);
		box(.05, .2, .05, accent, .58, .84, len * .4);
		box(w * .96, .08, len * .7, dark, 0, .36000000000000004, .1);
	}
	if (style === "muscle") {
		box(.55, .1, .72, dark, 0, chassisY + h + .18, -.85);
		box(.22, .08, .4, chrome, 0, chassisY + h + .26, -.85);
	}
	box(w * .96, .2, .22, dark, 0, .28, -len / 2 + .04);
	box(w * .96, .2, .22, dark, 0, .28, len / 2 - .04);
	box(w * .42, .16, .06, chrome, 0, .38, -len / 2 - .02);
	box(.32, .13, .08, lightMat, -w * .32, .44, -len / 2 - .03);
	box(.32, .13, .08, lightMat, w * .32, .44, -len / 2 - .03);
	box(.3, .1, .07, tailMat, -w * .32, .44, len / 2 + .03);
	box(.3, .1, .07, tailMat2, w * .32, .44, len / 2 + .03);
	const coneGeo = new ConeGeometry(.22, 1.6, 8);
	coneGeo.rotateX(-Math.PI / 2);
	const coneMat = new MeshBasicMaterial({
		color: 15918768,
		transparent: true,
		opacity: .14,
		depthWrite: false
	});
	const coneL = new Mesh(coneGeo, coneMat);
	coneL.position.set(-w * .32, .44, -len / 2 - .85);
	const coneR = coneL.clone();
	coneR.position.x = w * .32;
	add(coneL);
	add(coneR);
	if (opts?.lights !== false) {
		const spotL = new SpotLight(16773584, 5.5, 34, .4, .55, 1.15);
		spotL.position.set(-w * .32, .5, -len / 2 - .1);
		spotL.target.position.set(-w * .28, .05, -len / 2 - 14);
		const spotR = new SpotLight(16773584, 5.5, 34, .4, .55, 1.15);
		spotR.position.set(w * .32, .5, -len / 2 - .1);
		spotR.target.position.set(w * .28, .05, -len / 2 - 14);
		g.add(spotL, spotL.target, spotR, spotR.target);
	}
	box(.08, .08, .22, chrome, -w * .48, .82, -.35);
	box(.08, .08, .22, chrome, w * .48, .82, -.35);
	box(.28, .18, .04, chrome, 0, .78, -.2);
	box(.42, .12, .04, dark, 0, .32, len / 2 + .04);
	box(.38, .1, .02, chrome, 0, .32, len / 2 + .055);
	if (style !== "ev") {
		box(.1, .08, .28, chrome, -.42, .22, len / 2 - .15);
		box(.1, .08, .28, chrome, .42, .22, len / 2 - .15);
	}
	const wheelGeo = new CylinderGeometry(style === "moto" ? .36 : .33, style === "moto" ? .36 : .33, style === "moto" ? .16 : .24, 14);
	wheelGeo.rotateZ(Math.PI / 2);
	const tire = mat("#1a1a1a", {
		roughness: .92,
		metalness: .04
	});
	const wheels = [];
	const wx = w * .5 - .04;
	let positions = [
		[
			-wx,
			.33,
			-len * .32
		],
		[
			wx,
			.33,
			-len * .32
		],
		[
			-wx,
			.33,
			len * .32
		],
		[
			wx,
			.33,
			len * .32
		]
	];
	if (style === "moto") positions = [[
		0,
		.36,
		-.72
	], [
		0,
		.36,
		.78
	]];
	else if (style === "bus" || style === "truck") positions = [
		[
			-wx,
			.38,
			-len * .38
		],
		[
			wx,
			.38,
			-len * .38
		],
		[
			-wx,
			.38,
			.15
		],
		[
			wx,
			.38,
			.15
		],
		[
			-wx,
			.38,
			len * .38
		],
		[
			wx,
			.38,
			len * .38
		]
	];
	for (const p of positions) {
		const wh = new Group();
		wh.add(new Mesh(wheelGeo, tire));
		const rimM = new Mesh(new CylinderGeometry(.19, .19, .26, 12).rotateZ(Math.PI / 2), chrome);
		wh.add(rimM);
		const hub = new Mesh(new CylinderGeometry(.07, .07, .28, 8).rotateZ(Math.PI / 2), dark);
		wh.add(hub);
		wh.position.set(p[0], p[1], p[2]);
		g.add(wh);
		wheels.push(wh);
	}
	const shadow = new Mesh(new CircleGeometry(1.45, 18), new MeshBasicMaterial({
		color: 0,
		transparent: true,
		opacity: .3,
		depthWrite: false
	}));
	shadow.rotation.x = -Math.PI / 2;
	shadow.position.y = .03;
	g.add(shadow);
	g.userData = {
		wheels,
		tails: [tailMat, tailMat2],
		width: w,
		length: len
	};
	return g;
}
function setCarPose(mesh, v, dt) {
	mesh.position.set(v.x, v.y, v.z);
	mesh.rotation.order = "YXZ";
	mesh.rotation.y = v.yaw;
	const bank = -v.steerAngle * .2;
	mesh.rotation.z += (bank - mesh.rotation.z) * (1 - Math.exp(-8 * dt));
	mesh.rotation.x = v.airborne ? clamp(v.vy * .02, -.25, .2) : mesh.rotation.x * .9;
	const sy = v.squash;
	mesh.scale.set(2 - sy, sy, 2 - sy);
	const wheels = mesh.userData.wheels;
	if (wheels) for (let i = 0; i < wheels.length; i++) {
		const w = wheels[i];
		w.rotation.x = v.wheelSpin;
		if (i < 2) w.rotation.y = v.steerAngle;
		else w.rotation.y = 0;
	}
	const tails = mesh.userData.tails;
	if (tails) {
		const em = v.braking ? 1.6 : .4;
		for (const t of tails) t.emissiveIntensity = em;
	}
}
var FIXED = 1 / 60;
function lerpExp(cur, target, k, dt) {
	return cur + (target - cur) * (1 - Math.exp(-k * dt));
}
var GameEngine = class {
	canvas;
	renderer;
	scene = new Scene();
	camera = new PerspectiveCamera(62, 1, .1, 1400);
	world;
	vehicle = new Vehicle();
	carMesh;
	audio = new GameAudio();
	npcs = [];
	camPos = new Vector3(0, 18, 40);
	camLook = new Vector3();
	titleT = 0;
	playing = false;
	frozen = false;
	disposed = false;
	acc = 0;
	hudT = 0;
	statueHonk = 0;
	statueWindow = 0;
	trauma = 0;
	minimap;
	dust;
	dustAges;
	dustGeo;
	beacon;
	lastCar;
	hood = false;
	lastTime = 0;
	sun;
	skid;
	passenger;
	cargo;
	dogHonk = 0;
	wasWater = false;
	walkers = [];
	gpsMarks;
	gpsDummy = new Object3D();
	lastWpKey = "";
	gpsOriginX = 1e9;
	gpsOriginZ = 1e9;
	gpsPts = [];
	baseMap = null;
	tmpA = new Vector3();
	tmpB = new Vector3();
	constructor(canvas) {
		this.canvas = canvas;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			powerPreference: "high-performance",
			alpha: false
		});
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
		this.renderer.setClearColor(12109012, 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.renderer.toneMappingExposure = 1.12;
		this.scene.fog = new FogExp2(12109012, .00145);
		const hemi = new HemisphereLight(10405100, 4016696, .78);
		this.sun = new DirectionalLight(16773848, 1.62);
		this.sun.position.set(90, 140, 50);
		this.sun.target.position.set(0, 0, 0);
		this.scene.add(hemi, this.sun, this.sun.target, new AmbientLight(16777215, .12));
		if (typeof window !== "undefined" && window.innerWidth >= 720) {
			this.renderer.shadowMap.enabled = true;
			this.renderer.shadowMap.type = 1;
			this.sun.castShadow = true;
			this.sun.shadow.mapSize.set(1024, 1024);
			this.sun.shadow.camera.near = 8;
			this.sun.shadow.camera.far = 200;
			this.sun.shadow.camera.left = -46;
			this.sun.shadow.camera.right = 46;
			this.sun.shadow.camera.top = 46;
			this.sun.shadow.camera.bottom = -46;
			this.sun.shadow.bias = -7e-4;
		}
		useGame.getState().setProgress(.2);
		this.world = new World();
		this.scene.add(this.world.group);
		useGame.getState().setProgress(.7);
		this.lastCar = useGame.getState().currentCar;
		this.carMesh = buildCarMesh(CAR_BY_ID[this.lastCar], { lights: this.useCarLights() });
		this.scene.add(this.carMesh);
		this.vehicle.reset(18, 52, 0);
		this.passenger = makePassenger();
		this.carMesh.add(this.passenger);
		this.cargo = makeCargo();
		this.carMesh.add(this.cargo);
		this.skid = new SkidTrail(this.scene);
		this.spawnWalkers();
		this.beacon = new Mesh(new ConeGeometry(1.1, 3.2, 5), new MeshStandardMaterial({
			color: "#e8eaee",
			emissive: "#dce0e6",
			emissiveIntensity: .6
		}));
		this.beacon.rotation.x = Math.PI;
		this.scene.add(this.beacon);
		const chevron = new ConeGeometry(.45, 1.6, 4);
		chevron.rotateX(Math.PI / 2);
		this.gpsMarks = new InstancedMesh(chevron, new MeshBasicMaterial({
			color: 15264494,
			transparent: true,
			opacity: .85
		}), 96);
		this.gpsMarks.count = 0;
		this.gpsMarks.frustumCulled = false;
		this.scene.add(this.gpsMarks);
		this.minimap = document.createElement("canvas");
		this.minimap.width = 256;
		this.minimap.height = 256;
		this.bakeMinimapBase();
		this.spawnNpcs();
		this.dust = this.makeDust();
		this.dustGeo = this.dust.geometry;
		this.dustAges = /* @__PURE__ */ new Float32Array(80);
		this.onResize();
		window.addEventListener("resize", this.onResize);
		input.attach();
		this.wireControlsTest();
		useGame.getState().setProgress(1);
		useGame.getState().setReady(true);
		if (useGame.getState().screen === "loading") useGame.getState().setScreen("title");
	}
	makeDust() {
		const geo = new BufferGeometry();
		const pos = /* @__PURE__ */ new Float32Array(240);
		geo.setAttribute("position", new BufferAttribute(pos, 3));
		const mat = new PointsMaterial({
			color: 13156528,
			size: .55,
			transparent: true,
			opacity: .55,
			depthWrite: false
		});
		const p = new Points(geo, mat);
		this.scene.add(p);
		return p;
	}
	spawnNpcs() {
		const ring = [];
		for (let i = 0; i < 24; i++) {
			const t = i / 24 * Math.PI * 2;
			ring.push({
				x: Math.cos(t) * 168,
				z: Math.sin(t) * 182
			});
		}
		const factory = [];
		for (let i = 0; i < 16; i++) {
			const t = i / 16 * Math.PI * 2;
			factory.push({
				x: FACTORY.x + Math.cos(t) * 38,
				z: FACTORY.z + Math.sin(t) * 26
			});
		}
		const air = [
			{
				x: 8,
				z: -220
			},
			{
				x: AIRPORT.x,
				z: AIRPORT.z + 70
			},
			{
				x: AIRPORT.x,
				z: AIRPORT.z - 60
			}
		];
		const plaza = [];
		for (let i = 0; i < 12; i++) {
			const t = i / 12 * Math.PI * 2;
			plaza.push({
				x: Math.cos(t) * 28,
				z: Math.sin(t) * 28
			});
		}
		const paths = [
			ring,
			ring.slice().reverse(),
			factory,
			air,
			plaza
		];
		const ids = [
			"utca",
			"taxika",
			"furgon",
			"busz",
			"kamion",
			"motor",
			"kombi",
			"hegy",
			"csibe",
			"pampa"
		];
		const paints = [
			"#c45c3a",
			"#1e4d8c",
			"#f2efe8",
			"#3a4a3c",
			"#8a1f1a",
			"#5a6b7a",
			"#e8b86d",
			"#2a2c30"
		];
		for (let i = 0; i < 10; i++) {
			const path = paths[i % paths.length];
			const def = CAR_BY_ID[ids[i % ids.length]];
			const keep = def.body === "bus" || def.body === "truck" || def.id === "taxika";
			const mesh = buildCarMesh({
				...def,
				color: keep ? def.color : paints[i % paints.length]
			}, { lights: false });
			mesh.scale.setScalar(def.body === "bus" || def.body === "truck" ? .92 : .95);
			this.scene.add(mesh);
			const start = path[i % path.length];
			this.npcs.push({
				x: start.x,
				z: start.z,
				yaw: 0,
				speed: def.body === "bus" || def.body === "truck" ? 10 : 12 + i % 4 * 2,
				path,
				i: i % path.length,
				mesh
			});
		}
	}
	bakeMinimapBase() {
		const ctx = this.minimap.getContext("2d");
		const w = 256;
		const img = ctx.createImageData(w, w);
		for (let y = 0; y < w; y++) for (let x = 0; x < w; x++) {
			const wx = x / w * 480 * 2 - 480;
			const wz = y / w * 480 * 2 - 480;
			const b = biomeAt(wx, wz);
			let r = 60, g = 70, bl = 60;
			if (b === "city") {
				r = 70;
				g = 74;
				bl = 80;
			}
			if (b === "forest") {
				r = 32;
				g = 68;
				bl = 40;
			}
			if (b === "desert") {
				r = 180;
				g = 148;
				bl = 88;
			}
			if (b === "country") {
				r = 92;
				g = 130;
				bl = 52;
			}
			if (b === "coast") {
				r = 170;
				g = 156;
				bl = 100;
			}
			if (this.world.onRoad(wx, wz)) {
				r = 48;
				g = 50;
				bl = 54;
			}
			if (Math.hypot(wx - this.world.lake.x, wz - this.world.lake.z) < this.world.lake.r) {
				r = 48;
				g = 110;
				bl = 140;
			}
			const i = (y * w + x) * 4;
			img.data[i] = r;
			img.data[i + 1] = g;
			img.data[i + 2] = bl;
			img.data[i + 3] = 255;
		}
		ctx.putImageData(img, 0, 0);
		this.baseMap = ctx.getImageData(0, 0, w, w);
	}
	drawMinimap() {
		const ctx = this.minimap.getContext("2d");
		const size = 256;
		if (this.baseMap) ctx.putImageData(this.baseMap, 0, 0);
		const to = (x, z) => ({
			x: (x + 480) / 960 * size,
			y: (z + 480) / 960 * size
		});
		if (this.gpsPts.length > 1) {
			ctx.strokeStyle = "rgba(241,242,244,0.85)";
			ctx.lineWidth = 2;
			ctx.beginPath();
			const a = to(this.gpsPts[0].x, this.gpsPts[0].z);
			ctx.moveTo(a.x, a.y);
			for (let i = 1; i < this.gpsPts.length; i++) {
				const p = to(this.gpsPts[i].x, this.gpsPts[i].z);
				ctx.lineTo(p.x, p.y);
			}
			ctx.stroke();
		}
		const hidden = useGame.getState().foundSecret;
		for (const p of POIS) {
			if (p.id === "hidden" && !hidden) continue;
			const pt = to(p.x, p.z);
			ctx.fillStyle = p.color;
			ctx.beginPath();
			ctx.arc(pt.x, pt.y, 3.2, 0, Math.PI * 2);
			ctx.fill();
			ctx.strokeStyle = "rgba(9,10,12,0.7)";
			ctx.lineWidth = 1;
			ctx.stroke();
		}
		const wp = useGame.getState().waypoint;
		if (wp) {
			const p = to(wp.x, wp.z);
			ctx.fillStyle = "#f1f2f4";
			ctx.beginPath();
			ctx.arc(p.x, p.y, 6, 0, Math.PI * 2);
			ctx.fill();
		}
		const me = to(this.vehicle.x, this.vehicle.z);
		ctx.save();
		ctx.translate(me.x, me.y);
		ctx.rotate(-this.vehicle.yaw);
		ctx.fillStyle = "#e24a3b";
		ctx.beginPath();
		ctx.moveTo(0, -8);
		ctx.lineTo(5.5, 7);
		ctx.lineTo(-5.5, 7);
		ctx.closePath();
		ctx.fill();
		ctx.restore();
		useGame.getState().setTelemetry({
			speedKmh: Math.abs(this.vehicle.speed) * 3.6,
			rpm: this.vehicle.rpm,
			gear: this.vehicle.gear,
			biomeLabel: biomeLabel(biomeAt(this.vehicle.x, this.vehicle.z)),
			prompt: useGame.getState().prompt,
			minimap: this.minimap.toDataURL("image/png")
		});
	}
	rebuildGps() {
		const wp = useGame.getState().waypoint;
		const key = wp ? `${wp.x.toFixed(0)},${wp.z.toFixed(0)}` : "";
		const moved = Math.hypot(this.vehicle.x - this.gpsOriginX, this.vehicle.z - this.gpsOriginZ);
		if (key === this.lastWpKey && moved < 34) return;
		this.lastWpKey = key;
		this.gpsOriginX = this.vehicle.x;
		this.gpsOriginZ = this.vehicle.z;
		if (!wp) {
			this.gpsMarks.count = 0;
			this.gpsPts = [];
			return;
		}
		const raw = this.world.nav.path(this.vehicle.x, this.vehicle.z, wp.x, wp.z);
		this.gpsPts = densify(raw, 14);
		const n = Math.min(96, this.gpsPts.length);
		this.gpsMarks.count = n;
		for (let i = 0; i < n; i++) {
			const p = this.gpsPts[i];
			const nxt = this.gpsPts[Math.min(this.gpsPts.length - 1, i + 1)];
			const yaw = Math.atan2(nxt.x - p.x, nxt.z - p.z);
			this.gpsDummy.position.set(p.x, this.world.heightAt(p.x, p.z) + .35, p.z);
			this.gpsDummy.rotation.set(0, yaw, 0);
			this.gpsDummy.scale.set(1, 1, 1);
			this.gpsDummy.updateMatrix();
			this.gpsMarks.setMatrixAt(i, this.gpsDummy.matrix);
		}
		this.gpsMarks.instanceMatrix.needsUpdate = true;
	}
	onResize = () => {
		const w = this.canvas.clientWidth || window.innerWidth;
		const h = this.canvas.clientHeight || window.innerHeight;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
	};
	start() {
		this.lastTime = performance.now();
		this.renderer.setAnimationLoop(this.loop);
	}
	dispose() {
		this.disposed = true;
		this.renderer.setAnimationLoop(null);
		window.removeEventListener("resize", this.onResize);
		input.detach();
		this.renderer.dispose();
		this.scene.clear();
	}
	beginPlay() {
		this.audio.unlock();
		this.playing = true;
		this.frozen = false;
		input.blocked = false;
		this.vehicle.reset(18, 52, 0);
		this.swapCar(useGame.getState().currentCar, true);
		if (useGame.getState().foundSecret && this.world.hiddenMesh) this.world.hiddenMesh.visible = false;
		this.camPos.set(this.vehicle.x, this.vehicle.y + 8, this.vehicle.z + 16);
		this.camLook.set(this.vehicle.x, this.vehicle.y, this.vehicle.z);
		useGame.getState().setScreen("play");
	}
	setFrozen(v) {
		this.frozen = v;
		input.blocked = v;
	}
	swapCar(id, snap = false) {
		this.carMesh.remove(this.passenger);
		this.carMesh.remove(this.cargo);
		this.scene.remove(this.carMesh);
		this.carMesh.traverse((o) => {
			if (o instanceof Mesh) {
				o.geometry.dispose();
				const m = o.material;
				if (Array.isArray(m)) m.forEach((x) => x.dispose());
				else m.dispose();
			}
		});
		this.carMesh = buildCarMesh(CAR_BY_ID[id], { lights: this.useCarLights() });
		this.scene.add(this.carMesh);
		this.carMesh.add(this.passenger);
		this.carMesh.add(this.cargo);
		this.lastCar = id;
		if (snap) setCarPose(this.carMesh, this.vehicle, .016);
	}
	useCarLights() {
		return typeof window !== "undefined" && window.innerWidth >= 900;
	}
	loop = (time) => {
		if (this.disposed) return;
		let dt = (time - this.lastTime) / 1e3;
		this.lastTime = time;
		if (!Number.isFinite(dt) || dt <= 0) dt = .016;
		dt = Math.min(dt, .1);
		this.acc += dt;
		let steps = 0;
		while (this.acc >= FIXED && steps < 5) {
			this.fixed(FIXED);
			this.acc -= FIXED;
			steps++;
		}
		this.visual(dt);
		this.renderer.render(this.scene, this.camera);
	};
	fixed(dt) {
		const st = useGame.getState();
		if (st.screen === "title") {
			this.titleT += dt;
			return;
		}
		input.poll();
		if (input.pausePressed && st.screen === "play") {
			st.setScreen("pause");
			this.setFrozen(true);
			return;
		}
		if (input.pausePressed && (st.screen === "pause" || st.screen === "map" || st.screen === "help")) {
			st.setScreen("play");
			this.setFrozen(false);
		}
		if (input.mapPressed && st.screen === "play") {
			st.setScreen("map");
			this.setFrozen(true);
		}
		if (input.cameraPressed) {
			this.hood = !this.hood;
			st.setHood(this.hood);
		}
		if (this.frozen || st.screen !== "play") return;
		if (st.currentCar !== this.lastCar) this.swapCar(st.currentCar);
		const stats = effectiveStats(st.currentCar);
		const onRoad = this.world.onRoad(this.vehicle.x, this.vehicle.z);
		const inWater = this.world.inWater(this.vehicle.x, this.vehicle.z);
		const offroad = !onRoad;
		let surface = 1;
		if (offroad) surface = stats.body === "pickup" || stats.body === "suv" ? .88 : .72;
		if (inWater) surface = .35;
		const ground = this.world.heightAt(this.vehicle.x, this.vehicle.z);
		const hit = this.vehicle.step(dt, input.steer, input.throttle, input.brake, input.handbrake, stats, ground, surface, offroad);
		const col = this.world.collide(this.vehicle.x, this.vehicle.z, 1.15);
		let impact = hit.landed;
		if (col) {
			const imp = this.vehicle.applyCollision(col.nx, col.nz, col.depth);
			if (imp > 3) {
				impact = Math.max(impact, imp);
				this.audio.impact(imp / 12);
				this.trauma = Math.min(1, this.trauma + .25);
				if (st.job) st.job.hits += 1;
			}
		}
		this.npcStep(dt);
		if (hit.boostPop) this.audio.blip(520, .08);
		if (hit.landed > 6) {
			this.audio.impact(hit.landed / 14);
			this.trauma = Math.min(1, this.trauma + .2);
		}
		const poi = nearestPoi(this.vehicle.x, this.vehicle.z, 12);
		const fishingOk = this.world.nearShore(this.vehicle.x, this.vehicle.z);
		const parked = Math.abs(this.vehicle.speed) < 1.15;
		let prompt = promptFor(poi, fishingOk, parked, st.job);
		if (st.job) {
			if (Math.hypot(this.vehicle.x - st.job.targetX, this.vehicle.z - st.job.targetZ) < 12) prompt = "Leszállítás  ·  E";
		}
		let wayRel = null;
		let wayDist = null;
		if (st.waypoint) {
			const dx = st.waypoint.x - this.vehicle.x;
			const dz = st.waypoint.z - this.vehicle.z;
			wayDist = Math.hypot(dx, dz);
			let rel = Math.atan2(-dx, -dz) - this.vehicle.yaw;
			while (rel > Math.PI) rel -= Math.PI * 2;
			while (rel < -Math.PI) rel += Math.PI * 2;
			wayRel = rel;
		}
		st.setTelemetry({
			speedKmh: Math.abs(this.vehicle.speed) * 3.6,
			rpm: this.vehicle.rpm,
			gear: this.vehicle.gear,
			biomeLabel: biomeLabel(biomeAt(this.vehicle.x, this.vehicle.z)),
			prompt,
			posX: this.vehicle.x,
			posZ: this.vehicle.z,
			heading: this.vehicle.yaw,
			wayRel,
			wayDist,
			drifting: hit.drifting
		});
		this.rebuildGps();
		if (inWater && !this.wasWater) this.audio.splash();
		this.wasWater = inWater;
		this.skid.emit(this.vehicle.x, this.vehicle.y, this.vehicle.z, this.vehicle.yaw, dt, hit.drifting, this.vehicle.speed);
		if (parked) {
			const vid = tryViewpoint(this.vehicle.x, this.vehicle.z, true);
			if (vid && st.markView(vid)) {
				st.addMoney(140);
				st.toastMsg(`Kilátó: ${viewName(vid)}. +140 Ft`);
				this.audio.chime();
			}
		}
		this.passenger.visible = Boolean(st.job?.passenger);
		this.cargo.visible = st.job?.id === "courier" || st.job?.id === "secret" || st.job?.id === "grandma";
		if (st.foundSecret && this.world.hiddenMesh) this.world.hiddenMesh.visible = false;
		if (input.interactPressed) {
			if (st.job && Math.hypot(this.vehicle.x - st.job.targetX, this.vehicle.z - st.job.targetZ) < 12) tickJob(this.vehicle, 0, 0);
			else {
				const act = tryInteract(this.vehicle, poi, fishingOk && parked);
				if (act === "garage") {
					st.setScreen("garage");
					this.setFrozen(true);
				} else if (act === "dealer") {
					st.setScreen("dealer");
					this.setFrozen(true);
				} else if (act === "fishing") {
					st.setScreen("fishing");
					this.setFrozen(true);
				} else if (act === "fagyi") {
					if (st.money >= 60) {
						st.addMoney(-60);
						st.toastMsg("Eper-vanília. A napod jobb lett.");
					} else st.toastMsg("A fagyis néni meghívott egy gombócra.");
					st.bumpStat("iceCreams");
					this.audio.chime();
				} else if (act === "hidden") {
					st.ownCar("holdfeny");
					st.markSecret();
					if (this.world.hiddenMesh) this.world.hiddenMesh.visible = false;
					st.toastMsg("Megtaláltad a Holdfényt — a rejtett prototípust!");
					this.audio.cash();
				}
			}
		}
		tickJob(this.vehicle, impact, dt);
		tickChallenge(this.vehicle, hit.drifting, dt);
		if (input.hornPressed) {
			this.audio.horn();
			const statue = POI_BY_ID.statue;
			if (Math.hypot(this.vehicle.x - statue.x, this.vehicle.z - statue.z) < 14) {
				if (this.statueWindow <= 0) this.statueHonk = 0;
				this.statueHonk += 1;
				this.statueWindow = 2.2;
				if (this.statueHonk >= 3) {
					this.statueHonk = 0;
					st.addMoney(250);
					st.bumpStat("statueHonks");
					st.toastMsg("A szobor bólogat. +250 Ft a kasszába.");
					this.audio.cash();
				}
			}
			if (Math.hypot(this.vehicle.x - 318, this.vehicle.z - 42) < 18 && this.dogHonk <= 0) {
				this.dogHonk = 8;
				this.audio.bark();
				st.toastMsg("Bodri ugat egyet, majd a labdáját hozza.");
			}
		}
		this.statueWindow = Math.max(0, this.statueWindow - dt);
		this.dogHonk = Math.max(0, this.dogHonk - dt);
		this.trauma = Math.max(0, this.trauma - dt * 1.6);
		this.audio.update({
			rpm: this.vehicle.rpm,
			throttle: input.throttle,
			speed: this.vehicle.speed,
			drifting: hit.drifting,
			roar: stats.roar,
			ev: stats.body === "ev",
			paused: false
		});
		this.hudT += dt;
		if (this.hudT > .12) {
			this.hudT = 0;
			this.drawMinimap();
		}
	}
	npcStep(dt) {
		for (const n of this.npcs) {
			const tgt = n.path[n.i];
			const dx = tgt.x - n.x;
			const dz = tgt.z - n.z;
			if ((Math.hypot(dx, dz) || 1) < 6) n.i = (n.i + 1) % n.path.length;
			let dyaw = Math.atan2(-dx, -dz) - n.yaw;
			while (dyaw > Math.PI) dyaw -= Math.PI * 2;
			while (dyaw < -Math.PI) dyaw += Math.PI * 2;
			n.yaw += dyaw * Math.min(1, 3 * dt);
			n.x += -Math.sin(n.yaw) * n.speed * dt;
			n.z += -Math.cos(n.yaw) * n.speed * dt;
			const y = this.world.heightAt(n.x, n.z) + .42;
			n.mesh.position.set(n.x, y, n.z);
			n.mesh.rotation.y = n.yaw;
			const pdx = n.x - this.vehicle.x;
			const pdz = n.z - this.vehicle.z;
			const pd = Math.hypot(pdx, pdz);
			if (pd < 2.4) {
				const nx = pdx / (pd || 1);
				const nz = pdz / (pd || 1);
				this.vehicle.applyCollision(-nx, -nz, 2.4 - pd);
				n.x += nx * .8;
				n.z += nz * .8;
			}
		}
		this.walkerStep(dt);
	}
	visual(dt) {
		const st = useGame.getState();
		setCarPose(this.carMesh, this.vehicle, dt);
		const wp = st.waypoint;
		if (wp) {
			this.beacon.visible = true;
			const y = this.world.heightAt(wp.x, wp.z) + 4 + Math.sin(performance.now() * .004) * .4;
			this.beacon.position.set(wp.x, y, wp.z);
		} else this.beacon.visible = false;
		const pos = this.dustGeo.getAttribute("position");
		if (Math.abs(this.vehicle.speed) > 8 && Math.random() < .4) {
			for (let i = 0; i < this.dustAges.length; i++) if (this.dustAges[i] <= 0) {
				this.dustAges[i] = .6;
				const fx = Math.sin(this.vehicle.yaw);
				const fz = Math.cos(this.vehicle.yaw);
				pos.setXYZ(i, this.vehicle.x + fx * 1.2 + (Math.random() - .5), this.vehicle.y, this.vehicle.z + fz * 1.2 + (Math.random() - .5));
				break;
			}
		}
		for (let i = 0; i < this.dustAges.length; i++) if (this.dustAges[i] > 0) {
			this.dustAges[i] -= dt;
			pos.setY(i, pos.getY(i) + dt * .4);
		} else pos.setXYZ(i, 0, -20, 0);
		pos.needsUpdate = true;
		if (this.world.waterMesh) {
			const mat = this.world.waterMesh.material;
			if (mat.map) {
				mat.map.offset.x += dt * .012;
				mat.map.offset.y += dt * .008;
			}
			this.world.waterMesh.position.y = this.world.waterY + Math.sin(performance.now() * .0012) * .1;
		}
		if (this.world.clouds) this.world.clouds.rotation.y += dt * .004;
		if (this.world.windmillBlades) this.world.windmillBlades.rotation.z += dt * .55;
		if (this.world.signalRed && this.world.signalGreen) {
			const go = Math.floor(performance.now() / 3200) % 2 === 0;
			this.world.signalRed.emissiveIntensity = go ? .08 : 1.15;
			this.world.signalGreen.emissiveIntensity = go ? 1.15 : .08;
		}
		this.sun.position.set(this.vehicle.x + 55, 110, this.vehicle.z + 32);
		this.sun.target.position.set(this.vehicle.x, this.vehicle.y, this.vehicle.z);
		this.sun.target.updateMatrixWorld();
		if (st.screen === "title") {
			const t = this.titleT;
			this.camera.position.set(Math.sin(t * .18) * 48, 22, Math.cos(t * .18) * 48);
			this.camera.lookAt(0, 4, 0);
			this.audio.update({
				rpm: 1200,
				throttle: .1,
				speed: 0,
				drifting: false,
				roar: .4,
				ev: false,
				paused: true
			});
			return;
		}
		const fwd = this.vehicle.forward();
		const follow = this.hood ? 2.2 : 8.6;
		const height = this.hood ? 1.15 : 3.4;
		const lookAhead = this.hood ? 10 : 7;
		const desired = this.tmpA.set(this.vehicle.x + fwd.x * -follow, this.vehicle.y + height, this.vehicle.z + fwd.z * -follow);
		this.camPos.x = lerpExp(this.camPos.x, desired.x, 4.2, dt);
		this.camPos.y = lerpExp(this.camPos.y, desired.y, 5.2, dt);
		this.camPos.z = lerpExp(this.camPos.z, desired.z, 4.2, dt);
		const shake = this.trauma * this.trauma;
		const look = this.tmpB.set(this.vehicle.x + fwd.x * lookAhead, this.vehicle.y + .8, this.vehicle.z + fwd.z * lookAhead);
		this.camLook.x = lerpExp(this.camLook.x, look.x, 6, dt);
		this.camLook.y = lerpExp(this.camLook.y, look.y, 6, dt);
		this.camLook.z = lerpExp(this.camLook.z, look.z, 6, dt);
		this.camera.position.copy(this.camPos);
		if (shake > .01) {
			this.camera.position.x += (Math.random() - .5) * shake * .55;
			this.camera.position.y += (Math.random() - .5) * shake * .35;
		}
		this.camera.lookAt(this.camLook);
		const kmh = Math.abs(this.vehicle.speed) * 3.6;
		this.camera.fov = lerpExp(this.camera.fov, 62 + Math.min(14, kmh * .05), 3, dt);
		this.camera.updateProjectionMatrix();
	}
	spawnWalkers() {
		const shirts = [
			12868666,
			1985932,
			15251565,
			5925690,
			15921128,
			9051930,
			4021370,
			13660312
		];
		const variants = [
			"adult",
			"kid",
			"elder",
			"woman"
		];
		const bands = [
			42,
			68,
			96
		];
		const paths = [];
		for (const r of bands) {
			const near = this.world.sidewalks.filter((p) => Math.abs(Math.hypot(p.x, p.z) - r) < 16);
			near.sort((a, b) => Math.atan2(a.z, a.x) - Math.atan2(b.z, b.x));
			const loop = [];
			for (let i = 0; i < near.length; i += 2) loop.push(near[i]);
			if (loop.length >= 4) paths.push(loop);
		}
		const plaza = [
			{
				x: PLAZA.x - 8,
				z: PLAZA.z - 8
			},
			{
				x: PLAZA.x + 8,
				z: PLAZA.z - 8
			},
			{
				x: PLAZA.x + 8,
				z: PLAZA.z + 8
			},
			{
				x: PLAZA.x - 8,
				z: PLAZA.z + 8
			}
		].filter((p) => !this.world.onRoad(p.x, p.z));
		if (plaza.length >= 3) paths.push(plaza);
		if (!paths.length) paths.push([
			{
				x: 36,
				z: 36
			},
			{
				x: 36,
				z: -20
			},
			{
				x: -20,
				z: -20
			},
			{
				x: -20,
				z: 36
			}
		]);
		for (let i = 0; i < 28; i++) {
			const variant = variants[i % variants.length];
			const made = makePerson(shirts[i % shirts.length], variant);
			this.scene.add(made.mesh);
			const path = paths[i % paths.length];
			const pi = i % path.length;
			const start = path[pi];
			this.walkers.push({
				x: start.x,
				z: start.z,
				yaw: 0,
				t: i * .45,
				speed: variant === "kid" ? 2.05 : variant === "elder" ? .78 : 1.32,
				path,
				pi,
				mesh: made.mesh,
				lArm: made.lArm,
				rArm: made.rArm,
				lLeg: made.lLeg,
				rLeg: made.rLeg
			});
		}
	}
	walkerStep(dt) {
		for (const w of this.walkers) {
			w.t += dt;
			const goal = w.path[w.pi];
			const dx = goal.x - w.x;
			const dz = goal.z - w.z;
			if (Math.hypot(dx, dz) < 1.15) w.pi = (w.pi + 1) % w.path.length;
			else {
				w.yaw = Math.atan2(-dx, -dz);
				w.x += -Math.sin(w.yaw) * w.speed * dt;
				w.z += -Math.cos(w.yaw) * w.speed * dt;
			}
			const hit = this.world.collide(w.x, w.z, .35);
			if (hit) {
				w.x += hit.nx * (hit.depth + .02);
				w.z += hit.nz * (hit.depth + .02);
				w.pi = (w.pi + 1) % w.path.length;
			}
			if (this.world.onRoad(w.x, w.z)) {
				const len = Math.hypot(w.x, w.z) || 1;
				w.x += w.x / len * 1.6 * dt;
				w.z += w.z / len * 1.6 * dt;
			}
			const swing = Math.sin(w.t * (5.2 + w.speed * 2.4)) * .72;
			w.lArm.rotation.x = swing;
			w.rArm.rotation.x = -swing;
			w.lLeg.rotation.x = -swing * .95;
			w.rLeg.rotation.x = swing * .95;
			const bob = Math.abs(Math.sin(w.t * (5.2 + w.speed * 2.4))) * .045;
			w.mesh.position.set(w.x, this.world.heightAt(w.x, w.z) + bob, w.z);
			w.mesh.rotation.y = w.yaw;
		}
	}
	wireControlsTest() {
		window.__controlsTest = {
			getYaw: () => this.vehicle.yaw,
			getSpeed: () => this.vehicle.speed,
			setSteer: (v) => {
				input.qaSteer = v;
			},
			setKeys: (codes) => input.setKeys(codes)
		};
	}
};
function makePassenger() {
	const g = new Group();
	g.name = "passenger";
	const body = new Mesh(new CapsuleGeometry(.2, .42, 3, 6), new MeshStandardMaterial({
		color: "#3d5c7a",
		roughness: .7
	}));
	body.position.set(.42, .92, .08);
	const head = new Mesh(new SphereGeometry(.15, 8, 6), new MeshStandardMaterial({
		color: "#e8c4a8",
		roughness: .7
	}));
	head.position.set(.42, 1.32, .08);
	g.add(body, head);
	g.visible = false;
	return g;
}
function makeCargo() {
	const mesh = new Mesh(new BoxGeometry(.7, .45, .7), new MeshStandardMaterial({
		color: "#c45c3a",
		roughness: .8
	}));
	mesh.position.set(-.05, .95, .7);
	mesh.visible = false;
	return mesh;
}
function makePerson(shirt, variant = "adult") {
	const g = new Group();
	const skin = new MeshStandardMaterial({
		color: 15254696,
		roughness: .72
	});
	const shirtM = new MeshStandardMaterial({
		color: shirt,
		roughness: .78
	});
	const pantsM = new MeshStandardMaterial({
		color: variant === "woman" ? 2765632 : 2763824,
		roughness: .85
	});
	const hairM = new MeshStandardMaterial({
		color: variant === "elder" ? 13159634 : variant === "kid" ? 12868666 : 3811874,
		roughness: .9
	});
	const torso = new Mesh(new BoxGeometry(.4, .5, .22), shirtM);
	torso.position.y = 1.08;
	const hips = new Mesh(new BoxGeometry(.36, .22, .22), pantsM);
	hips.position.y = .74;
	const head = new Mesh(new SphereGeometry(.17, 10, 8), skin);
	head.position.y = 1.48;
	const eyeM = new MeshStandardMaterial({
		color: 1711136,
		roughness: .4
	});
	const eyeGeo = new SphereGeometry(.028, 6, 5);
	const le = new Mesh(eyeGeo, eyeM);
	le.position.set(-.055, 1.5, .145);
	const re = new Mesh(eyeGeo, eyeM);
	re.position.set(.055, 1.5, .145);
	const hair = new Mesh(new SphereGeometry(variant === "woman" ? .19 : .175, 10, 8), hairM);
	hair.position.y = variant === "woman" ? 1.52 : 1.56;
	hair.scale.set(1, variant === "woman" ? .85 : .5, variant === "woman" ? 1.15 : 1);
	if (variant === "woman") {
		const skirt = new Mesh(new ConeGeometry(.28, .42, 8), shirtM);
		skirt.position.y = .78;
		g.add(skirt);
	}
	if (variant === "elder") {
		const hat = new Mesh(new CylinderGeometry(.2, .2, .08, 8), new MeshStandardMaterial({
			color: 3817544,
			roughness: .8
		}));
		hat.position.y = 1.68;
		const brim = new Mesh(new CylinderGeometry(.28, .28, .03, 8), new MeshStandardMaterial({ color: 2763824 }));
		brim.position.y = 1.64;
		g.add(hat, brim);
	}
	if (variant === "adult" || variant === "woman") {
		const bag = new Mesh(new BoxGeometry(.12, .16, .08), new MeshStandardMaterial({
			color: 6968128,
			roughness: .85
		}));
		bag.position.set(.26, .95, .02);
		g.add(bag);
	}
	const lArm = new Group();
	const rArm = new Group();
	const armGeo = new CapsuleGeometry(.055, .34, 3, 5);
	const la = new Mesh(armGeo, shirtM);
	la.position.y = -.22;
	lArm.add(la);
	lArm.position.set(-.26, 1.24, 0);
	const ra = new Mesh(armGeo, shirtM);
	ra.position.y = -.22;
	rArm.add(ra);
	rArm.position.set(.26, 1.24, 0);
	const lLeg = new Group();
	const rLeg = new Group();
	const legGeo = new CapsuleGeometry(.07, .36, 3, 5);
	const ll = new Mesh(legGeo, pantsM);
	ll.position.y = -.26;
	lLeg.add(ll);
	const shoeGeo = new BoxGeometry(.11, .06, .18);
	const shoeM = new MeshStandardMaterial({
		color: 1711136,
		roughness: .7
	});
	const sl = new Mesh(shoeGeo, shoeM);
	sl.position.set(0, -.48, .03);
	lLeg.add(sl);
	lLeg.position.set(-.1, .64, 0);
	const rl = new Mesh(legGeo, pantsM);
	rl.position.y = -.26;
	rLeg.add(rl);
	const sr = new Mesh(shoeGeo, shoeM);
	sr.position.set(0, -.48, .03);
	rLeg.add(sr);
	rLeg.position.set(.1, .64, 0);
	g.add(torso, hips, head, hair, le, re, lArm, rArm, lLeg, rLeg);
	if (variant === "kid") g.scale.setScalar(.64);
	if (variant === "elder") g.scale.setScalar(.92);
	return {
		mesh: g,
		lArm,
		rArm,
		lLeg,
		rLeg
	};
}
//#endregion
export { GameEngine };
