export type Biome =
  | "city"
  | "suburb"
  | "forest"
  | "desert"
  | "country"
  | "coast"
  | "hills";

export type CarBody =
  | "hatch"
  | "sedan"
  | "coupe"
  | "van"
  | "pickup"
  | "muscle"
  | "super"
  | "ev"
  | "estate"
  | "moto"
  | "bus"
  | "truck"
  | "suv"
  | "cabrio";

export type CarId =
  | "csibe"
  | "utca"
  | "furgon"
  | "pampa"
  | "siraly"
  | "villam"
  | "nyil"
  | "holdfeny"
  | "taxika"
  | "kombi"
  | "motor"
  | "busz"
  | "kamion"
  | "hegy"
  | "bravo";

export type UpgradeKind = "engine" | "tires" | "brakes" | "turbo";

export type JobId = "taxi" | "courier" | "grandma" | "secret" | "party";

export type ChallengeId = "drift" | "accel" | "topspeed" | "jump" | "circuit";

export type PassengerKind = "kid" | "elder" | "adult";

export type DestKind = "work" | "challenge" | "party";

export type Screen =
  | "loading"
  | "title"
  | "play"
  | "pause"
  | "garage"
  | "dealer"
  | "map"
  | "fishing"
  | "help";

export type CarDef = {
  id: CarId;
  name: string;
  klass: string;
  price: number;
  color: string;
  accent: string;
  glass: string;
  maxSpeed: number;
  accel: number;
  brake: number;
  turn: number;
  grip: number;
  mass: number;
  body: CarBody;
  roar: number;
  secret?: boolean;
  blurb: string;
};

export type PoiId =
  | "garage"
  | "dealer"
  | "taxi"
  | "courier"
  | "market"
  | "grandma"
  | "secret"
  | "drift"
  | "accel"
  | "topspeed"
  | "jump"
  | "circuit"
  | "fishing"
  | "statue"
  | "hidden"
  | "fagyi"
  | "party";

export type Poi = {
  id: PoiId;
  name: string;
  x: number;
  z: number;
  hint: string;
  color: string;
};

export type Destination = {
  id: string;
  kind: DestKind;
  name: string;
  blurb: string;
  x: number;
  z: number;
  poi?: PoiId;
};

export type Waypoint = { x: number; z: number; label?: string };

export type JobState = {
  id: JobId;
  step: number;
  title: string;
  detail: string;
  pay: number;
  targetX: number;
  targetZ: number;
  smoothness: number;
  samples: number;
  hits: number;
  passenger?: string;
  passengerKind?: PassengerKind;
  jumpCheers?: number;
} | null;

export type ChallengeState = {
  id: ChallengeId;
  title: string;
  detail: string;
  t: number;
  value: number;
  active: boolean;
  done: boolean;
} | null;

export type SaveData = {
  version: number;
  money: number;
  owned: CarId[];
  currentCar: CarId;
  upgrades: Partial<Record<CarId, Partial<Record<UpgradeKind, number>>>>;
  stars: Partial<Record<ChallengeId, number>>;
  foundSecret: boolean;
  statueHonks: number;
  fishCaught: number;
  jobsDone: number;
  iceCreams: number;
  viewsFound: string[];
  champion: boolean;
};
