import * as THREE from "three";
import { AIRPORT, FACTORY, PLAZA, POIS, WORLD_HALF } from "./data";
import { NavGraph } from "./nav";
import { fbm, hash2, hash3 } from "./noise";
import {
  brickFacadeTexture,
  facadeTexture,
  glassFacadeTexture,
  groundNoiseTexture,
  houseFacadeTexture,
  poiLabelTexture,
  shopFacadeTexture,
  shopSignTexture,
  signTexture,
  waterTexture,
} from "./textures";
import type { Biome } from "./types";

export type Aabb = { x: number; z: number; w: number; d: number; h: number };
export type Circle = { x: number; z: number; r: number };
export type RoadSeg = { ax: number; az: number; bx: number; bz: number; width: number };

const RES = 168;
const SIZE = WORLD_HALF * 2;

export function biomeAt(x: number, z: number): Biome {
  const r = Math.hypot(x, z);
  if (r < 138) return "city";
  if (r < 188) return "suburb";
  if (z < -210 && Math.abs(x) < 300) return "desert";
  if (x < -210) return "forest";
  if (x > 210) return "country";
  if (z > 250) return "coast";
  return "hills";
}

export function biomeLabel(b: Biome): string {
  switch (b) {
    case "city":
      return "Belváros";
    case "suburb":
      return "Külváros";
    case "forest":
      return "Erdő";
    case "desert":
      return "Sivatag";
    case "country":
      return "Mező";
    case "coast":
      return "Part";
    default:
      return "Dombvidék";
  }
}

export class World {
  group = new THREE.Group();
  roads: RoadSeg[] = [];
  buildings: Aabb[] = [];
  trees: Circle[] = [];
  height = new Float32Array((RES + 1) * (RES + 1));
  waterY = 1.35;
  lake = { x: -20, z: 400, r: 88 };
  waterMesh: THREE.Mesh | null = null;
  clouds: THREE.Group | null = null;
  windmillBlades: THREE.Group | null = null;
  hiddenMesh: THREE.Object3D | null = null;
  nav!: NavGraph;
  sidewalks: { x: number; z: number; yaw: number }[] = [];
  crosswalks: { x: number; z: number; yaw: number; nx: number; nz: number; side: number; span: number }[] = [];
  signalRed: THREE.MeshStandardMaterial | null = null;
  signalGreen: THREE.MeshStandardMaterial | null = null;
  private tmp = new THREE.Vector3();
  private rdRes = 220;
  private rdDist!: Float32Array;
  private rdW!: Float32Array;

  constructor() {
    this.buildRoads();
    this.nav = new NavGraph(this.roads);
    this.bakeRoadField();
    this.buildHeight();
    this.group.add(this.makeTerrain());
    this.group.add(this.makeWater());
    this.group.add(this.makeSky());
    this.makeRoadMarks();
    this.placeCity();
    this.placeSkyline();
    this.placeParks();
    this.placeStreetFurniture();
    this.placeCityDetails();
    this.placeSuburb();
    this.placeNature();
    this.placeFactory();
    this.placeAirport();
    this.placeLandmarks();
    this.placePois();
    this.placeClouds();
    void this.tmp;
  }

  private addRoad(ax: number, az: number, bx: number, bz: number, width: number) {
    this.roads.push({ ax, az, bx, bz, width });
  }

  private addCurve(
    ax: number,
    az: number,
    cx: number,
    cz: number,
    bx: number,
    bz: number,
    width: number,
    segs = 7,
  ) {
    let px = ax;
    let pz = az;
    for (let i = 1; i <= segs; i++) {
      const t = i / segs;
      const mt = 1 - t;
      const x = mt * mt * ax + 2 * mt * t * cx + t * t * bx;
      const z = mt * mt * az + 2 * mt * t * cz + t * t * bz;
      this.addRoad(px, pz, x, z, width);
      px = x;
      pz = z;
    }
  }

  private buildRoads() {
    const H = WORLD_HALF;
    this.addCurve(0, -H, 52, -340, -14, -200, 20, 7);
    this.addCurve(-14, -200, -40, -140, 0, -90, 20, 5);
    this.addRoad(0, -90, 0, -30, 20);
    this.addRoad(0, 30, 0, 90, 20);
    this.addCurve(0, 90, -30, 210, 10, 330, 18, 6);
    this.addCurve(10, 330, 18, 410, 0, H, 16, 4);

    this.addCurve(-H, 0, -310, 44, -180, -10, 18, 6);
    this.addCurve(-180, -10, -122, -24, -90, 0, 18, 4);
    this.addRoad(-90, 0, -30, 0, 20);
    this.addRoad(30, 0, 90, 0, 20);
    this.addCurve(90, 0, 168, -32, 286, 12, 16, 6);
    this.addCurve(286, 12, 386, -16, H, 8, 16, 5);

    const rr = 28;
    const rn = 24;
    for (let i = 0; i < rn; i++) {
      const t0 = (i / rn) * Math.PI * 2;
      const t1 = ((i + 1) / rn) * Math.PI * 2;
      this.addRoad(Math.cos(t0) * rr, Math.sin(t0) * rr, Math.cos(t1) * rr, Math.sin(t1) * rr, 14);
    }

    const n = 40;
    for (let i = 0; i < n; i++) {
      const t0 = (i / n) * Math.PI * 2;
      const t1 = ((i + 1) / n) * Math.PI * 2;
      const rx0 = 168 * (1 + Math.sin(t0 * 2) * 0.09);
      const rz0 = 182 * (1 + Math.cos(t0 * 3) * 0.07);
      const rx1 = 168 * (1 + Math.sin(t1 * 2) * 0.09);
      const rz1 = 182 * (1 + Math.cos(t1 * 3) * 0.07);
      this.addRoad(Math.cos(t0) * rx0, Math.sin(t0) * rz0, Math.cos(t1) * rx1, Math.sin(t1) * rz1, 14);
    }

    for (let i = -4; i <= 4; i++) {
      if (i === 0) continue;
      const bulge = (i % 2 === 0 ? 1 : -1) * (34 + Math.abs(i) * 5);
      const y = i * 28;
      const w = i % 2 === 0 ? 12 : 9;
      this.addCurve(-126, y, -48, y + bulge, 6, y - bulge * 0.38, w, 6);
      this.addCurve(6, y - bulge * 0.38, 58, y + bulge * 0.48, 126, y, w, 5);
      const x = i * 28;
      this.addCurve(x, -126, x + bulge, -42, x - bulge * 0.32, 8, 9, 6);
      this.addCurve(x - bulge * 0.32, 8, x + bulge * 0.42, 72, x, 126, 9, 5);
    }

    this.addCurve(-120, 120, -18, 38, 112, -104, 16, 8);
    this.addCurve(-108, -92, 12, -8, 102, 112, 12, 7);
    this.addCurve(PLAZA.x - 40, PLAZA.z + 22, PLAZA.x, PLAZA.z - 18, PLAZA.x + 42, PLAZA.z + 14, 11, 6);

    this.addCurve(-170, 40, -222, 80, FACTORY.x + 20, FACTORY.z - 10, 12, 6);
    const dr = 38;
    for (let i = 0; i < 20; i++) {
      const t0 = (i / 20) * Math.PI * 2;
      const t1 = ((i + 1) / 20) * Math.PI * 2;
      this.addRoad(
        FACTORY.x + Math.cos(t0) * dr,
        FACTORY.z + Math.sin(t0) * 26,
        FACTORY.x + Math.cos(t1) * dr,
        FACTORY.z + Math.sin(t1) * 26,
        11,
      );
    }

    this.addCurve(8, -220, 54, -308, AIRPORT.x, AIRPORT.z + 70, 16, 6);
    this.addRoad(AIRPORT.x, AIRPORT.z + 78, AIRPORT.x, AIRPORT.z - 78, 22);
    this.addRoad(AIRPORT.x - 28, AIRPORT.z + 20, AIRPORT.x + 40, AIRPORT.z + 20, 10);

    this.addCurve(220, 18, 340, 8, 460, 22, 14, 5);
    this.addCurve(-18, -220, -8, -340, -18, -470, 16, 5);
    this.addRoad(70, 250, 110, 360, 10);
    this.addRoad(-36, 340, -36, 430, 8);
    this.addRoad(20, 300, 70, 360, 8);
  }

  private bakeRoadField() {
    const R = this.rdRes;
    const n = (R + 1) * (R + 1);
    this.rdDist = new Float32Array(n);
    this.rdW = new Float32Array(n);
    for (let iz = 0; iz <= R; iz++) {
      for (let ix = 0; ix <= R; ix++) {
        const x = (ix / R) * SIZE - WORLD_HALF;
        const z = (iz / R) * SIZE - WORLD_HALF;
        const d = this.distToRoadRaw(x, z);
        const i = iz * (R + 1) + ix;
        this.rdDist[i] = d.dist;
        this.rdW[i] = d.width;
      }
    }
  }

  private distToRoadRaw(x: number, z: number): { dist: number; width: number } {
    let best = 1e9;
    let w = 8;
    for (const r of this.roads) {
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len2 = dx * dx + dz * dz || 1;
      let t = ((x - r.ax) * dx + (z - r.az) * dz) / len2;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(x - (r.ax + dx * t), z - (r.az + dz * t));
      if (d < best) {
        best = d;
        w = r.width;
      }
    }
    return { dist: best, width: w };
  }

  distToRoad(x: number, z: number): { dist: number; width: number } {
    const u = ((x + WORLD_HALF) / SIZE) * this.rdRes;
    const v = ((z + WORLD_HALF) / SIZE) * this.rdRes;
    const x0 = Math.max(0, Math.min(this.rdRes - 1, Math.floor(u)));
    const z0 = Math.max(0, Math.min(this.rdRes - 1, Math.floor(v)));
    const fx = u - x0;
    const fz = v - z0;
    const i = (zz: number, xx: number) => zz * (this.rdRes + 1) + xx;
    const d00 = this.rdDist[i(z0, x0)]!;
    const d10 = this.rdDist[i(z0, x0 + 1)]!;
    const d01 = this.rdDist[i(z0 + 1, x0)]!;
    const d11 = this.rdDist[i(z0 + 1, x0 + 1)]!;
    const dist =
      d00 * (1 - fx) * (1 - fz) + d10 * fx * (1 - fz) + d01 * (1 - fx) * fz + d11 * fx * fz;
    return { dist, width: this.rdW[i(z0, x0)]! };
  }

  onRoad(x: number, z: number) {
    const d = this.distToRoad(x, z);
    return d.dist < d.width * 0.55;
  }

  private rawHeight(x: number, z: number): number {
    const b = biomeAt(x, z);
    let h = (fbm(x * 0.007, z * 0.007, 5) - 0.5) * 10;
    h += (fbm(x * 0.02, z * 0.02, 3) - 0.5) * 3.2;
    if (b === "city") h *= 0.08;
    if (b === "suburb") h *= 0.25;
    if (b === "desert") {
      h += Math.abs(Math.sin(x * 0.028 + z * 0.01)) * 7.5;
      h += (fbm(x * 0.015, z * 0.015) - 0.4) * 4;
    }
    if (b === "forest") h += (fbm(x * 0.012, z * 0.012) - 0.4) * 9;
    if (b === "country") h += Math.sin(x * 0.01) * 1.4;
    if (b === "coast" || b === "hills") h += (fbm(x * 0.01, z * 0.01) - 0.35) * 12;
    const lake = Math.hypot(x - this.lake.x, z - this.lake.z);
    if (lake < this.lake.r + 24) {
      const k = clamp01((this.lake.r + 24 - lake) / 40);
      h = h * (1 - k) - 3.2 * k;
    }
    const ramp1 = Math.hypot(x - 96, z - 300);
    if (ramp1 < 28) h += (1 - ramp1 / 28) * 9 * (z > 290 ? 1 : 0.4);
    const ramp2 = Math.hypot(x - 70, z - 340);
    if (ramp2 < 22) h += (1 - ramp2 / 22) * 7;
    const fac = Math.hypot(x - FACTORY.x, z - FACTORY.z);
    if (fac < 70) h *= 1 - 0.92 * (1 - fac / 70);
    const air = Math.hypot(x - AIRPORT.x, z - AIRPORT.z);
    if (air < 95) h *= 1 - 0.94 * (1 - air / 95);
    const plaza = Math.hypot(x - PLAZA.x, z - PLAZA.z);
    if (plaza < 22) h *= 0.15;
    const rd = this.distToRoad(x, z);
    if (rd.dist < rd.width * 0.58) {
      const k = 1 - rd.dist / (rd.width * 0.58);
      h *= 1 - 0.85 * k;
    }
    return h;
  }

  private buildHeight() {
    for (let iz = 0; iz <= RES; iz++) {
      for (let ix = 0; ix <= RES; ix++) {
        const x = (ix / RES) * SIZE - WORLD_HALF;
        const z = (iz / RES) * SIZE - WORLD_HALF;
        this.height[iz * (RES + 1) + ix] = this.rawHeight(x, z);
      }
    }
  }

  heightAt(x: number, z: number): number {
    const u = ((x + WORLD_HALF) / SIZE) * RES;
    const v = ((z + WORLD_HALF) / SIZE) * RES;
    const x0 = Math.max(0, Math.min(RES - 1, Math.floor(u)));
    const z0 = Math.max(0, Math.min(RES - 1, Math.floor(v)));
    const fx = u - x0;
    const fz = v - z0;
    const i = (zz: number, xx: number) => this.height[zz * (RES + 1) + xx]!;
    return (
      i(z0, x0) * (1 - fx) * (1 - fz) +
      i(z0, x0 + 1) * fx * (1 - fz) +
      i(z0 + 1, x0) * (1 - fx) * fz +
      i(z0 + 1, x0 + 1) * fx * fz
    );
  }

  inWater(x: number, z: number) {
    return (
      Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r - 4 &&
      this.heightAt(x, z) < this.waterY - 0.2
    );
  }

  nearShore(x: number, z: number) {
    const d = Math.hypot(x - this.lake.x, z - this.lake.z);
    return d < this.lake.r + 14 && d > this.lake.r - 18 && !this.inWater(x, z);
  }

  private makeTerrain() {
    const geo = new THREE.PlaneGeometry(SIZE, SIZE, RES, RES);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position!;
    const cols = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const y = this.heightAt(x, z);
      pos.setY(i, y);
      const b = biomeAt(x, z);
      const rd = this.distToRoad(x, z);
      const n = (hash2(Math.floor(x), Math.floor(z)) - 0.5) * 0.08;
      if (rd.dist < rd.width * 0.5) {
        c.setRGB(0.15 + n, 0.16 + n, 0.18 + n);
      } else if (rd.dist < rd.width * 0.5 + 0.85 && b === "city") {
        c.setRGB(0.62 + n, 0.6 + n, 0.56 + n);
      } else if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 62) {
        c.setRGB(0.28 + n, 0.27 + n, 0.25 + n);
      } else if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 88) {
        c.setRGB(0.22 + n, 0.23 + n, 0.24 + n);
      } else if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < 20) {
        c.setRGB(0.28 + n, 0.48 + n, 0.3 + n);
      } else if (b === "city") {
        const cell = hash2(Math.floor(x / 16), Math.floor(z / 16));
        if (cell > 0.78) c.setRGB(0.3 + n, 0.48 + n, 0.28 + n);
        else if (cell > 0.52) c.setRGB(0.62 + n, 0.56 + n, 0.46 + n);
        else c.setRGB(0.46 + n, 0.46 + n, 0.48 + n);
      } else if (b === "suburb") {
        c.setRGB(0.36 + n, 0.48 + n, 0.3 + n);
      } else if (b === "forest") {
        c.setRGB(0.15 + n, 0.3 + n, 0.16 + n);
      } else if (b === "desert") {
        c.setRGB(0.78 + n, 0.63 + n, 0.36 + n);
      } else if (b === "country") {
        if (Math.sin(x * 0.18) > 0) c.setRGB(0.64 + n, 0.58 + n, 0.26 + n);
        else c.setRGB(0.34 + n, 0.54 + n, 0.2 + n);
      } else if (b === "coast") {
        c.setRGB(0.74 + n, 0.67 + n, 0.46 + n);
      } else {
        c.setRGB(0.3 + n, 0.46 + n, 0.24 + n);
      }
      if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 10 && y < this.waterY + 1.2) {
        c.setRGB(0.8, 0.72, 0.5);
      }
      cols[i * 3] = c.r;
      cols[i * 3 + 1] = c.g;
      cols[i * 3 + 2] = c.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(cols, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.95,
      metalness: 0.02,
      map: groundNoiseTexture(),
    });
    mat.map!.repeat.set(40, 40);
    mat.map!.wrapS = mat.map!.wrapT = THREE.RepeatWrapping;
    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    return mesh;
  }

  private makeWater() {
    const geo = new THREE.CircleGeometry(this.lake.r, 56);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({
      color: "#2a6a80",
      transparent: true,
      opacity: 0.84,
      roughness: 0.12,
      metalness: 0.35,
      map: waterTexture(),
    });
    mat.map!.repeat.set(6, 6);
    mat.map!.wrapS = mat.map!.wrapT = THREE.RepeatWrapping;
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(this.lake.x, this.waterY, this.lake.z);
    this.waterMesh = mesh;
    return mesh;
  }

  private makeSky() {
    const geo = new THREE.SphereGeometry(920, 28, 18);
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {},
      vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: `varying vec3 vW; void main(){
        vec3 n = normalize(vW);
        float h = n.y;
        vec3 zen = vec3(0.20, 0.46, 0.78);
        vec3 hor = vec3(0.80, 0.84, 0.90);
        vec3 glow = vec3(0.95, 0.76, 0.52);
        vec3 col = mix(hor, zen, clamp(h * 1.2, 0.0, 1.0));
        col = mix(glow, col, clamp((h + 0.1) * 2.6, 0.0, 1.0));
        vec3 sunDir = normalize(vec3(0.42, 0.52, 0.32));
        float sun = pow(max(0.0, dot(n, sunDir)), 120.0);
        float halo = pow(max(0.0, dot(n, sunDir)), 8.0);
        col += vec3(1.0, 0.92, 0.7) * sun * 1.6;
        col += vec3(1.0, 0.8, 0.5) * halo * 0.18;
        gl_FragColor = vec4(col, 1.0);
      }`,
    });
    return new THREE.Mesh(geo, mat);
  }

  private nearestRoad(x: number, z: number) {
    let best = Infinity;
    let width = 8;
    let yaw = 0;
    let nx = 1;
    let nz = 0;
    for (const r of this.roads) {
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len2 = dx * dx + dz * dz;
      if (len2 < 0.04) continue;
      let t = ((x - r.ax) * dx + (z - r.az) * dz) / len2;
      t = Math.max(0, Math.min(1, t));
      const px = r.ax + dx * t;
      const pz = r.az + dz * t;
      const d = Math.hypot(x - px, z - pz);
      if (d < best) {
        best = d;
        width = r.width;
        const len = Math.sqrt(len2);
        yaw = Math.atan2(dx, dz);
        const lx = -dz / len;
        const lz = dx / len;
        const side = (x - px) * lx + (z - pz) * lz >= 0 ? 1 : -1;
        nx = lx * side;
        nz = lz * side;
      }
    }
    return { dist: best, width, yaw, nx, nz };
  }

  private blockedByOther(x: number, z: number, self: RoadSeg) {
    for (const r of this.roads) {
      if (r === self) continue;
      const joined =
        Math.hypot(r.ax - self.ax, r.az - self.az) < 1.5 ||
        Math.hypot(r.bx - self.bx, r.bz - self.bz) < 1.5 ||
        Math.hypot(r.ax - self.bx, r.az - self.bz) < 1.5 ||
        Math.hypot(r.bx - self.ax, r.bz - self.az) < 1.5;
      if (joined) continue;
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len2 = dx * dx + dz * dz;
      if (len2 < 1) continue;
      let t = ((x - r.ax) * dx + (z - r.az) * dz) / len2;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(x - (r.ax + dx * t), z - (r.az + dz * t));
      if (d < r.width * 0.46) return true;
    }
    return false;
  }

  private onAsphalt(x: number, z: number) {
    const h = this.nearestRoad(x, z);
    return h.dist < h.width * 0.48;
  }

  private pushOffRoad(x: number, z: number, margin = 1.3) {
    for (let i = 0; i < 3; i++) {
      const h = this.nearestRoad(x, z);
      if (h.dist >= h.width * 0.5 + margin) break;
      const need = h.width * 0.5 + margin - h.dist + 0.15;
      x += h.nx * need;
      z += h.nz * need;
    }
    return { x, z };
  }

  private makeRoadMarks() {
    const dummy = new THREE.Object3D();
    const taken = new Set<string>();
    const claim = (x: number, z: number, cell = 1.7) => {
      const k = `${Math.round(x / cell)}:${Math.round(z / cell)}`;
      if (taken.has(k)) return false;
      taken.add(k);
      return true;
    };
    const dashes: { x: number; z: number; yaw: number }[] = [];
    const edges: { x: number; z: number; yaw: number }[] = [];
    const zebras: { x: number; z: number; yaw: number; nx: number; nz: number; side: number; span: number }[] = [];

    for (const r of this.roads) {
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len = Math.hypot(dx, dz) || 1;
      const yaw = Math.atan2(dx, dz);
      const nx = -dz / len;
      const nz = dx / len;
      const wide = r.width >= 15;
      const laneOff = wide ? r.width * 0.16 : 0;
      for (let s = 4; s < len - 4; s += wide ? 8 : 7.2) {
        const t = s / len;
        const cx = r.ax + dx * t;
        const cz = r.az + dz * t;
        if (this.blockedByOther(cx, cz, r)) continue;
        const lanes = wide ? [-laneOff, laneOff] : [0];
        for (const off of lanes) {
          const x = cx + nx * off;
          const z = cz + nz * off;
          if (!claim(x, z, 1.8)) continue;
          dashes.push({ x, z, yaw });
        }
      }
      for (let s = 2.2; s < len - 2.2; s += 2.5) {
        const t = s / len;
        const cx = r.ax + dx * t;
        const cz = r.az + dz * t;
        if (this.blockedByOther(cx, cz, r)) continue;
        const off = r.width * 0.47;
        for (const side of [-1, 1] as const) {
          const x = cx + nx * off * side;
          const z = cz + nz * off * side;
          if (this.crossesRoad(x, z, yaw)) continue;
          if (!claim(x, z, 1.5)) continue;
          edges.push({ x, z, yaw });
        }
      }
      if (len > 26 && Math.hypot((r.ax + r.bx) * 0.5, (r.az + r.bz) * 0.5) < 132) {
        const x = (r.ax + r.bx) * 0.5;
        const z = (r.az + r.bz) * 0.5;
        if (this.blockedByOther(x, z, r) || zebras.some((q) => Math.hypot(q.x - x, q.z - z) < 46)) continue;
          zebras.push({
            x,
            z,
            yaw,
            nx,
            nz,
            side: r.width * 0.5 + 1.7,
            span: Math.min(r.width * 0.4, 6.2),
          });
        }
      }
    }
    this.crosswalks = zebras.slice(0, 12);
    const dashKeep = dashes.filter((d) => {
      for (const c of this.crosswalks) {
        const along = (d.x - c.x) * Math.sin(c.yaw) + (d.z - c.z) * Math.cos(c.yaw);
        const lateral = (d.x - c.x) * c.nx + (d.z - c.z) * c.nz;
        if (Math.abs(along) < 1.7 && Math.abs(lateral) < c.span + 0.3) return false;
      }
      return true;
    });

    const paint = (
      list: { x: number; z: number; yaw: number }[],
      geo: THREE.BufferGeometry,
      color: number,
      yLift: number,
    ) => {
      if (!list.length) return;
      const mesh = new THREE.InstancedMesh(geo, new THREE.MeshBasicMaterial({ color }), list.length);
      for (let i = 0; i < list.length; i++) {
        const m = list[i]!;
        dummy.position.set(m.x, this.heightAt(m.x, m.z) + yLift, m.z);
        dummy.rotation.set(0, m.yaw, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(mesh);
    };
    paint(dashKeep, new THREE.BoxGeometry(0.18, 0.03, 2.15), 0xe4e7ec, 0.045);
    paint(edges, new THREE.BoxGeometry(0.12, 0.025, 2.35), 0xf4f5f7, 0.04);

    if (this.crosswalks.length) {
      const stripes: { x: number; z: number; yaw: number }[] = [];
      for (const c of this.crosswalks) {
        for (let o = -c.span; o <= c.span; o += 0.92) {
          stripes.push({ x: c.x + c.nx * o, z: c.z + c.nz * o, yaw: c.yaw });
        }
      }
      paint(stripes, new THREE.BoxGeometry(0.46, 0.03, 2.5), 0xf7f8f8, 0.05);
    }
  }

  private skipNear(x: number, z: number, r = 18) {
    for (const p of POIS) {
      if (Math.hypot(p.x - x, p.z - z) < r) return true;
    }
    if (Math.hypot(x, z) < 22) return true;
    if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < 22) return true;
    if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 55) return true;
    if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 80) return true;
    return false;
  }

  private isLandmarkCell(gx: number, gz: number) {
    return (
      (gx === -3 && gz === -1) ||
      (gx === 2 && gz === -1) ||
      (gx === 2 && gz === 1) ||
      (gx === 0 && gz === -3)
    );
  }

  private findLot(gx: number, gz: number) {
    const cx = gx * 28 + 14;
    const cz = gz * 28 + 14;
    const shifts: [number, number][] = [
      [0, 0],
      [7, 0],
      [-7, 0],
      [0, 7],
      [0, -7],
      [8, 6],
      [-6, 8],
    ];
    for (const [ox, oz] of shifts) {
      const x = cx + ox;
      const z = cz + oz;
      if (!this.onRoad(x, z) && !this.skipNear(x, z, 11)) return { x, z };
    }
    return null;
  }

  private isParkCell(gx: number, gz: number) {
    return (gx === 1 && gz === -2) || (gx === -2 && gz === 1) || (gx + gz * 3) % 7 === 0;
  }

  private placeCity() {
    const facades = [facadeTexture(), brickFacadeTexture(), glassFacadeTexture(), shopFacadeTexture()];
    const bodyGeo = new THREE.BoxGeometry(1, 1, 1);
    bodyGeo.translate(0, 0.5, 0);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    type Inst = { x: number; z: number; w: number; d: number; h: number; col: number; kind: number; yaw: number };
    const buckets: Inst[][] = [[], [], [], []];

    for (let gx = -4; gx <= 3; gx++) {
      for (let gz = -4; gz <= 3; gz++) {
        if (this.isParkCell(gx, gz) || this.isLandmarkCell(gx, gz)) continue;
        const cx = gx * 28 + 14;
        const cz = gz * 28 + 14;
        if (this.skipNear(cx, cz, 16)) continue;
        if (Math.hypot(cx, cz) > 128) continue;
        const n = 1 + Math.floor(hash2(gx, gz) * 3);
        for (let k = 0; k < n; k++) {
          const ox = (hash3(gx, gz, k) - 0.5) * 8;
          const oz = (hash3(gx + 3, gz, k + 1) - 0.5) * 8;
          const kind = Math.floor(hash3(gx, k, gz + 4) * 4);
          const w = kind === 3 ? 9 + hash3(gx, k, gz) * 4 : 7 + hash3(gx, k, gz) * 6;
          const d = kind === 3 ? 8 + hash3(k, gx, gz) * 3 : 7 + hash3(k, gx, gz) * 6;
          const h =
            kind === 3
              ? 5.5 + hash2(gx, gz) * 3
              : kind === 2
                ? 18 + hash2(gx * 9 + k, gz * 7) * 28
                : 9 + hash2(gx * 9 + k, gz * 7) * 22;
          const x = cx + ox;
          const z = cz + oz;
          if (this.onRoad(x, z) || this.skipNear(x, z)) continue;
          const palettes = [
            [0xfff6ee, 0xf3efe6, 0xe7eef2, 0xf7f1e4],
            [0xfff3ea, 0xf6e4d8, 0xf3d7cc, 0xf8efe4],
            [0xf4f7fb, 0xe7eef6, 0xd5e2ee, 0xf7f9fb],
            [0xfff8f0, 0xf6efe4, 0xfde7d2, 0xf3f6ea],
          ];
          const district = gz <= -2 ? 2 : gz >= 2 ? 1 : gx <= -2 ? 0 : 3;
          const pal = palettes[district]!;
          const col = pal[Math.floor(hash2(x, z) * pal.length)]!;
          const yaw = Math.floor(hash3(gx, gz, k + 9) * 4) * (Math.PI / 2);
          buckets[kind]!.push({ x, z, w, d, h, col, kind, yaw });
          this.buildings.push({ x, z, w, d, h });
          if (kind === 2 && h > 24) {
            buckets[0]!.push({
              x,
              z,
              w: w + 3.2,
              d: d + 3.2,
              h: 6.2,
              col: 0x6c727a,
              kind: 0,
              yaw,
            });
            this.buildings.push({ x, z, w: w + 3.2, d: d + 3.2, h: 6.2 });
          }
        }
      }
    }

    for (let kind = 0; kind < 4; kind++) {
      const list = buckets[kind]!;
      if (!list.length) continue;
      const mat = new THREE.MeshStandardMaterial({
        map: facades[kind],
        roughness: kind === 2 ? 0.28 : 0.68,
        metalness: kind === 2 ? 0.45 : 0.1,
      });
      const mesh = new THREE.InstancedMesh(bodyGeo, mat, list.length);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      for (let i = 0; i < list.length; i++) {
        const b = list[i]!;
        dummy.position.set(b.x, this.heightAt(b.x, b.z), b.z);
        dummy.scale.set(b.w, b.h, b.d);
        dummy.rotation.set(0, b.yaw, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        color.setHex(b.col);
        mesh.setColorAt(i, color);
      }
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      this.group.add(mesh);
    }

    const face = (
      x: number,
      y: number,
      z: number,
      yaw: number,
      tz: number,
      sx: number,
      sy: number,
      sz: number,
    ) => {
      dummy.position.set(x, y, z);
      dummy.rotation.set(0, yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      dummy.translateZ(tz);
      dummy.scale.set(sx, sy, sz);
      dummy.updateMatrix();
    };

    const shops = buckets[3]!;
    if (shops.length) {
      const awnGeo = new THREE.BoxGeometry(1, 0.12, 1.15);
      const awnMat = new THREE.MeshStandardMaterial({ color: "#c45c3a", roughness: 0.7 });
      const awn = new THREE.InstancedMesh(awnGeo, awnMat, shops.length);
      const awnCols = [0xc45c3a, 0x3d5c7a, 0x5a6b3a, 0xe8b86d, 0x1e4d8c];
      for (let i = 0; i < shops.length; i++) {
        const b = shops[i]!;
        face(b.x, this.heightAt(b.x, b.z) + 3.15, b.z, b.yaw, b.d * 0.5 + 0.2, b.w * 0.92, 1, 1);
        awn.setMatrixAt(i, dummy.matrix);
        color.setHex(awnCols[i % awnCols.length]!);
        awn.setColorAt(i, color);
      }
      if (awn.instanceColor) awn.instanceColor.needsUpdate = true;
      this.group.add(awn);

      const winGeo = new THREE.PlaneGeometry(1, 1);
      const winMat = new THREE.MeshStandardMaterial({
        color: "#b7d4e4",
        emissive: "#d5eaf4",
        emissiveIntensity: 0.45,
        roughness: 0.08,
        metalness: 0.45,
        transparent: true,
        opacity: 0.86,
      });
      const wins = new THREE.InstancedMesh(winGeo, winMat, shops.length);
      for (let i = 0; i < shops.length; i++) {
        const b = shops[i]!;
        face(b.x, this.heightAt(b.x, b.z) + 1.65, b.z, b.yaw, b.d * 0.5 + 0.06, b.w * 0.7, 1.7, 1);
        wins.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(wins);

      const labels: [string, string][] = [
        ["PÉK", "#c45c3a"],
        ["TEJ", "#3d5c7a"],
        ["VIRÁG", "#5a6b3a"],
        ["JÁTÉK", "#e24a3b"],
        ["KÖNYV", "#1e4d8c"],
        ["FAGYI", "#c45c78"],
        ["POSTA", "#c4923a"],
        ["PIAC", "#8a1f1a"],
      ];
      for (let k = 0; k < labels.length; k++) {
        const list = shops.filter((_, i) => i % labels.length === k);
        if (!list.length) continue;
        const [label, bg] = labels[k]!;
        const mat = new THREE.MeshBasicMaterial({
          map: shopSignTexture(label, bg),
          side: THREE.DoubleSide,
        });
        const sign = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), mat, list.length);
        for (let i = 0; i < list.length; i++) {
          const b = list[i]!;
          face(b.x, this.heightAt(b.x, b.z) + 4.15, b.z, b.yaw, b.d * 0.5 + 0.18, 2.8, 0.78, 1);
          sign.setMatrixAt(i, dummy.matrix);
        }
        this.group.add(sign);
      }
    }

    const all = buckets.flat();
    const roofGeo = new THREE.BoxGeometry(1, 0.28, 1);
    const roofMat = new THREE.MeshStandardMaterial({ color: "#3a4048", roughness: 0.86 });
    const roofMesh = new THREE.InstancedMesh(roofGeo, roofMat, all.length);
    const roofCols = [0x6a4038, 0x3a4048, 0x5a3028, 0x2a3340];
    for (let i = 0; i < all.length; i++) {
      const b = all[i]!;
      dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h + 0.08, b.z);
      dummy.scale.set(b.w + 0.35, 1, b.d + 0.35);
      dummy.rotation.set(0, b.yaw, 0);
      dummy.updateMatrix();
      roofMesh.setMatrixAt(i, dummy.matrix);
      color.setHex(roofCols[b.kind]!);
      roofMesh.setColorAt(i, color);
    }
    if (roofMesh.instanceColor) roofMesh.instanceColor.needsUpdate = true;
    this.group.add(roofMesh);

    const pitched = all.filter((b) => b.h < 12 && b.kind !== 2);
    if (pitched.length) {
      const cone = new THREE.ConeGeometry(0.72, 1, 4);
      cone.rotateY(Math.PI / 4);
      cone.translate(0, 0.5, 0);
      const pitchMat = new THREE.MeshStandardMaterial({ color: "#8a4034", roughness: 0.9 });
      const pitch = new THREE.InstancedMesh(cone, pitchMat, pitched.length);
      pitch.castShadow = true;
      const pitchCols = [0x8a4034, 0x5a3028, 0x3a4854, 0x6a5340];
      for (let i = 0; i < pitched.length; i++) {
        const b = pitched[i]!;
        dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h, b.z);
        dummy.scale.set(b.w * 0.78, 2.4 + hash2(b.x, b.z) * 1.3, b.d * 0.78);
        dummy.rotation.set(0, b.yaw, 0);
        dummy.updateMatrix();
        pitch.setMatrixAt(i, dummy.matrix);
        color.setHex(pitchCols[i % pitchCols.length]!);
        pitch.setColorAt(i, color);
      }
      if (pitch.instanceColor) pitch.instanceColor.needsUpdate = true;
      this.group.add(pitch);
    }

    const caps = all.filter((b) => b.kind === 2 && b.h > 20);
    if (caps.length) {
      const capGeo = new THREE.BoxGeometry(1, 1, 1);
      capGeo.translate(0, 0.5, 0);
      const capMat = new THREE.MeshStandardMaterial({
        map: facades[2],
        roughness: 0.22,
        metalness: 0.55,
        color: "#e7eef6",
      });
      const capMesh = new THREE.InstancedMesh(capGeo, capMat, caps.length);
      capMesh.castShadow = true;
      for (let i = 0; i < caps.length; i++) {
        const b = caps[i]!;
        const extra = 6 + hash2(b.x, b.h) * 8;
        dummy.position.set(b.x, this.heightAt(b.x, b.z) + b.h, b.z);
        dummy.scale.set(b.w * 0.62, extra, b.d * 0.62);
        dummy.rotation.set(0, b.yaw, 0);
        dummy.updateMatrix();
        capMesh.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(capMesh);
    }

    const bals = all.filter((b) => b.h > 14).slice(0, 70);
    if (bals.length) {
      const balGeo = new THREE.BoxGeometry(1, 0.1, 0.55);
      const balMat = new THREE.MeshStandardMaterial({ color: "#d8dce2", roughness: 0.6 });
      const bal = new THREE.InstancedMesh(balGeo, balMat, bals.length);
      const railGeo = new THREE.BoxGeometry(1, 0.35, 0.05);
      const rail = new THREE.InstancedMesh(railGeo, balMat, bals.length);
      for (let i = 0; i < bals.length; i++) {
        const b = bals[i]!;
        const y = this.heightAt(b.x, b.z) + b.h * 0.48;
        face(b.x, y, b.z, b.yaw, b.d * 0.5 + 0.12, b.w * 0.48, 1, 1);
        bal.setMatrixAt(i, dummy.matrix);
        face(b.x, y + 0.38, b.z, b.yaw, b.d * 0.5 + 0.34, b.w * 0.48, 1, 1);
        rail.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(bal, rail);
    }

    const acList = all.filter((b) => b.h > 12).slice(0, 80);
    if (acList.length) {
      const acGeo = new THREE.BoxGeometry(1.6, 0.7, 1.1);
      const acMat = new THREE.MeshStandardMaterial({ color: "#8a9098", roughness: 0.55, metalness: 0.35 });
      const ac = new THREE.InstancedMesh(acGeo, acMat, acList.length);
      for (let i = 0; i < acList.length; i++) {
        const b = acList[i]!;
        dummy.position.set(b.x + 1.2, this.heightAt(b.x, b.z) + b.h + 0.55, b.z - 0.8);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, b.yaw, 0);
        dummy.updateMatrix();
        ac.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(ac);
    }

    const lampGeo = new THREE.CylinderGeometry(0.08, 0.1, 5.2, 6);
    lampGeo.translate(0, 2.6, 0);
    const lampMat = new THREE.MeshStandardMaterial({ color: "#2a2c30" });
    const lamps: { x: number; z: number }[] = [];
    for (let i = -4; i <= 4; i++) {
      for (const s of [-1, 1]) {
        lamps.push({ x: i * 28 + 5, z: s * 118 });
        lamps.push({ x: s * 118, z: i * 28 + 5 });
      }
    }
    for (let i = -3; i <= 3; i++) {
      lamps.push({ x: i * 28 + 8, z: 8 });
      lamps.push({ x: 8, z: i * 28 + 8 });
    }
    const lampMesh = new THREE.InstancedMesh(lampGeo, lampMat, lamps.length);
    const bulbGeo = new THREE.SphereGeometry(0.22, 8, 8);
    const bulbMat = new THREE.MeshStandardMaterial({
      color: "#f0e6c0",
      emissive: "#e8d090",
      emissiveIntensity: 0.85,
    });
    const bulbs = new THREE.InstancedMesh(bulbGeo, bulbMat, lamps.length);
    for (let i = 0; i < lamps.length; i++) {
      const p = lamps[i]!;
      const y = this.heightAt(p.x, p.z);
      dummy.position.set(p.x, y, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      lampMesh.setMatrixAt(i, dummy.matrix);
      dummy.position.y = y + 5.15;
      dummy.updateMatrix();
      bulbs.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(lampMesh, bulbs);

    const statue = new THREE.Group();
    const plinth = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 1.3, 4.2),
      new THREE.MeshStandardMaterial({ color: "#8b9098", roughness: 0.55, metalness: 0.2 }),
    );
    plinth.position.y = 0.65;
    const fig = new THREE.Mesh(
      new THREE.ConeGeometry(1.15, 4.4, 7),
      new THREE.MeshStandardMaterial({ color: "#a8b0bc", metalness: 0.45, roughness: 0.32 }),
    );
    fig.position.y = 3.4;
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.55, 10, 8),
      new THREE.MeshStandardMaterial({ color: "#b4bcc4", metalness: 0.4, roughness: 0.35 }),
    );
    head.position.y = 5.7;
    statue.add(plinth, fig, head);
    statue.position.set(0, this.heightAt(0, 0), 0);
    this.group.add(statue);
    this.buildings.push({ x: 0, z: 0, w: 4.6, d: 4.6, h: 6 });
  }

  private placeSkyline() {
    const stone = new THREE.MeshStandardMaterial({ color: "#e7e2d8", roughness: 0.78 });
    const brick = new THREE.MeshStandardMaterial({ color: "#8a4a3c", roughness: 0.86 });
    const glass = new THREE.MeshStandardMaterial({
      color: "#c5d6e4",
      roughness: 0.22,
      metalness: 0.48,
    });
    const dark = new THREE.MeshStandardMaterial({ color: "#2a2c30", roughness: 0.7 });
    const gold = new THREE.MeshStandardMaterial({ color: "#e8b86d", roughness: 0.4, metalness: 0.45 });

    const churchAt = this.findLot(-3, -1);
    if (churchAt) {
      const { x, z } = churchAt;
      const y = this.heightAt(x, z);
      const g = new THREE.Group();
      const nave = new THREE.Mesh(new THREE.BoxGeometry(16, 8, 10), stone);
      nave.position.y = 4;
      nave.castShadow = true;
      const tower = new THREE.Mesh(new THREE.BoxGeometry(4.2, 16, 4.2), stone);
      tower.position.set(-5.2, 8, 0);
      tower.castShadow = true;
      const spire = new THREE.Mesh(new THREE.ConeGeometry(2.3, 7.5, 4), dark);
      spire.position.set(-5.2, 19.2, 0);
      spire.rotation.y = Math.PI / 4;
      const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.5, 0.18), gold);
      crossV.position.set(-5.2, 23.4, 0);
      const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.16, 0.16), gold);
      crossH.position.set(-5.2, 23.7, 0);
      const door = new THREE.Mesh(new THREE.BoxGeometry(2.2, 3.4, 0.2), dark);
      door.position.set(1.2, 1.7, 5.1);
      const windowM = new THREE.MeshStandardMaterial({
        color: "#7ec8c4",
        emissive: "#3a6a78",
        emissiveIntensity: 0.35,
        transparent: true,
        opacity: 0.85,
      });
      const rose = new THREE.Mesh(new THREE.CircleGeometry(1.15, 10), windowM);
      rose.position.set(1.2, 5.4, 5.12);
      g.add(nave, tower, spire, crossV, crossH, door, rose);
      g.position.set(x, y, z);
      this.group.add(g);
      this.buildings.push({ x, z, w: 16, d: 10, h: 22 });
    }

    const hotelAt = this.findLot(2, -1);
    if (hotelAt) {
      const { x, z } = hotelAt;
      const y = this.heightAt(x, z);
      const g = new THREE.Group();
      const tiers = [
        { w: 16, d: 14, h: 10, yy: 0 },
        { w: 12, d: 10, h: 12, yy: 10 },
        { w: 8, d: 7, h: 10, yy: 22 },
      ];
      for (const t of tiers) {
        const body = new THREE.Mesh(new THREE.BoxGeometry(t.w, t.h, t.d), glass);
        body.position.y = t.yy + t.h / 2;
        body.castShadow = true;
        const band = new THREE.Mesh(new THREE.BoxGeometry(t.w + 0.3, 0.35, t.d + 0.3), gold);
        band.position.y = t.yy + t.h;
        g.add(body, band);
      }
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 6, 6), dark);
      mast.position.y = 35;
      g.add(mast);
      g.position.set(x, y, z);
      this.group.add(g);
      this.buildings.push({ x, z, w: 16, d: 14, h: 32 });
    }

    const clockAt = this.findLot(2, 1);
    if (clockAt) {
      const { x, z } = clockAt;
      const y = this.heightAt(x, z);
      const g = new THREE.Group();
      const shaft = new THREE.Mesh(new THREE.BoxGeometry(5.2, 22, 5.2), brick);
      shaft.position.y = 11;
      shaft.castShadow = true;
      const cap = new THREE.Mesh(new THREE.ConeGeometry(3.6, 5.2, 4), dark);
      cap.position.y = 24.4;
      cap.rotation.y = Math.PI / 4;
      const faceMat = new THREE.MeshStandardMaterial({
        color: "#f7f1d4",
        emissive: "#f2e4a8",
        emissiveIntensity: 0.35,
      });
      for (const [fx, fz] of [
        [0, 2.65],
        [0, -2.65],
        [2.65, 0],
        [-2.65, 0],
      ] as const) {
        const face = new THREE.Mesh(new THREE.CircleGeometry(1.05, 12), faceMat);
        face.position.set(fx, 16.5, fz);
        if (Math.abs(fx) > 1) face.rotation.y = Math.PI / 2;
        g.add(face);
      }
      g.add(shaft, cap);
      g.position.set(x, y, z);
      this.group.add(g);
      this.buildings.push({ x, z, w: 5.4, d: 5.4, h: 26 });
    }

    const arcadeAt = this.findLot(0, -3);
    if (arcadeAt) {
      const colors = ["#c45c3a", "#e8b86d", "#3d5c7a", "#5a6b3a", "#1e4d8c", "#8a1f1a"];
      for (let i = 0; i < 6; i++) {
        const x = arcadeAt.x - 7.5 + i * 3.1;
        const z = arcadeAt.z;
        if (this.onRoad(x, z)) continue;
        const y = this.heightAt(x, z);
        const stall = new THREE.Mesh(
          new THREE.BoxGeometry(2.4, 2.2, 2.2),
          new THREE.MeshStandardMaterial({ color: "#f4efe6", roughness: 0.8 }),
        );
        stall.position.set(x, y + 1.1, z);
        stall.castShadow = true;
        const awn = new THREE.Mesh(
          new THREE.BoxGeometry(2.7, 0.12, 1.5),
          new THREE.MeshStandardMaterial({ color: colors[i]! }),
        );
        awn.position.set(x, y + 2.35, z + 1.1);
        const fruit = new THREE.Mesh(
          new THREE.SphereGeometry(0.28, 8, 6),
          new THREE.MeshStandardMaterial({ color: i % 2 ? "#c45c3a" : "#e8b86d" }),
        );
        fruit.position.set(x, y + 2.7, z + 0.2);
        this.group.add(stall, awn, fruit);
        this.buildings.push({ x, z, w: 2.5, d: 2.3, h: 2.4 });
      }
    }
  }

  private placeCityDetails() {
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const walk: { x: number; z: number; yaw: number }[] = [];
    const used = new Set<string>();
    for (const r of this.roads) {
      if (Math.hypot(r.ax, r.az) > 145 && Math.hypot(r.bx, r.bz) > 145) continue;
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len = Math.hypot(dx, dz) || 1;
      const nx = -dz / len;
      const nz = dx / len;
      const yaw = Math.atan2(dx, dz);
      const off = r.width * 0.5 + 1.75;
      for (const side of [-1, 1] as const) {
        for (let s = 1.2; s < len - 1.2; s += 1.85) {
          if (walk.length > 1100) break;
          const t = s / len;
          const x = r.ax + dx * t + nx * off * side;
          const z = r.az + dz * t + nz * off * side;
          if (Math.hypot(x, z) > 138) continue;
          const fx = Math.sin(yaw);
          const fz = Math.cos(yaw);
          const rx = Math.cos(yaw);
          const rz = -Math.sin(yaw);
          let buried = false;
          for (const [ox, oz] of [
            [0, 0],
            [0.55, 0.7],
            [-0.55, 0.7],
            [0.55, -0.7],
            [-0.55, -0.7],
          ] as const) {
            if (this.onAsphalt(x + rx * ox + fx * oz, z + rz * ox + fz * oz)) {
              buried = true;
              break;
            }
          }
          if (buried || this.blockedByOther(x, z, r)) continue;
          const key = `${Math.round(x / 2.6)}:${Math.round(z / 2.6)}`;
          if (used.has(key)) continue;
          used.add(key);
          walk.push({ x, z, yaw });
        }
      }
    }
    this.sidewalks = walk.filter((_, i) => i % 3 === 0 && !this.onRoad(walk[i]!.x, walk[i]!.z));
    if (walk.length) {
      const geo = new THREE.BoxGeometry(1.15, 0.08, 1.65);
      const mat = new THREE.MeshStandardMaterial({ color: "#e7e2d6", roughness: 0.92 });
      const mesh = new THREE.InstancedMesh(geo, mat, walk.length);
      mesh.receiveShadow = true;
      for (let i = 0; i < walk.length; i++) {
        const p = walk[i]!;
        dummy.position.set(p.x, this.heightAt(p.x, p.z) + 0.03, p.z);
        dummy.rotation.set(0, p.yaw, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(mesh);
    }

    const planters: { x: number; z: number }[] = [];
    for (let i = 0; i < walk.length; i += 18) {
      const p = walk[i]!;
      if (this.onRoad(p.x, p.z)) continue;
      planters.push(p);
    }
    if (planters.length) {
      const pot = new THREE.CylinderGeometry(0.38, 0.42, 0.5, 8);
      pot.translate(0, 0.25, 0);
      const bush = new THREE.SphereGeometry(0.42, 8, 6);
      const potM = new THREE.MeshStandardMaterial({ color: "#6a4038", roughness: 0.88 });
      const bushM = new THREE.MeshStandardMaterial({ color: "#2f5a34", roughness: 0.85 });
      const pots = new THREE.InstancedMesh(pot, potM, planters.length);
      const bushes = new THREE.InstancedMesh(bush, bushM, planters.length);
      for (let i = 0; i < planters.length; i++) {
        const p = planters[i]!;
        const y = this.heightAt(p.x, p.z);
        dummy.position.set(p.x, y, p.z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        pots.setMatrixAt(i, dummy.matrix);
        dummy.position.y = y + 0.7;
        dummy.updateMatrix();
        bushes.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(pots, bushes);
    }

    const saplings: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < walk.length; i += 26) {
      const p = walk[i]!;
      if (this.onRoad(p.x, p.z) || this.skipNear(p.x, p.z, 8)) continue;
      saplings.push({ x: p.x, z: p.z, s: 0.55 + hash2(p.x, p.z) * 0.35 });
      this.trees.push({ x: p.x, z: p.z, r: 0.35 });
    }
    if (saplings.length) {
      const trunkGeo = new THREE.CylinderGeometry(0.1, 0.14, 1.5, 5);
      trunkGeo.translate(0, 0.75, 0);
      const leafGeo = new THREE.SphereGeometry(0.7, 7, 5);
      const trunkM = new THREE.MeshStandardMaterial({ color: "#4a3424", roughness: 0.95 });
      const leafM = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.85 });
      const trunks = new THREE.InstancedMesh(trunkGeo, trunkM, saplings.length);
      const leaves = new THREE.InstancedMesh(leafGeo, leafM, saplings.length);
      const leafCols = [0x2f6a38, 0x3d7a42, 0x6a8a32, 0x1f5a40];
      for (let i = 0; i < saplings.length; i++) {
        const p = saplings[i]!;
        const y = this.heightAt(p.x, p.z);
        dummy.position.set(p.x, y, p.z);
        dummy.scale.setScalar(p.s);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);
        dummy.position.y = y + 1.7 * p.s;
        dummy.scale.setScalar(p.s * 1.15);
        dummy.updateMatrix();
        leaves.setMatrixAt(i, dummy.matrix);
        color.setHex(leafCols[i % leafCols.length]!);
        leaves.setColorAt(i, color);
      }
      if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
      this.group.add(trunks, leaves);
    }
  }

  private placeParks() {
    const dummy = new THREE.Object3D();
    const grass = new THREE.MeshStandardMaterial({ color: "#3d6a38", roughness: 0.95 });
    const padGeo = new THREE.BoxGeometry(22, 0.12, 22);
    const parks: { x: number; z: number }[] = [{ x: PLAZA.x, z: PLAZA.z }];
    for (let gx = -4; gx <= 3; gx++) {
      for (let gz = -4; gz <= 3; gz++) {
        if (!this.isParkCell(gx, gz)) continue;
        const x = gx * 28 + 14;
        const z = gz * 28 + 14;
        if (Math.hypot(x, z) > 120) continue;
        parks.push({ x, z });
      }
    }
    const pads = new THREE.InstancedMesh(padGeo, grass, parks.length);
    for (let i = 0; i < parks.length; i++) {
      const p = parks[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z) + 0.08, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      pads.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(pads);

    const benchSeat = new THREE.BoxGeometry(1.6, 0.12, 0.42);
    const benchMat = new THREE.MeshStandardMaterial({ color: "#6a5340", roughness: 0.85 });
    const benches: { x: number; z: number; yaw: number }[] = [];
    for (const p of parks) {
      benches.push({ x: p.x - 6, z: p.z - 4, yaw: 0.2 });
      benches.push({ x: p.x + 5, z: p.z + 3, yaw: 1.2 });
      benches.push({ x: p.x - 2, z: p.z + 6, yaw: -0.4 });
    }
    const benchMesh = new THREE.InstancedMesh(benchSeat, benchMat, benches.length);
    for (let i = 0; i < benches.length; i++) {
      const b = benches[i]!;
      dummy.position.set(b.x, this.heightAt(b.x, b.z) + 0.45, b.z);
      dummy.rotation.set(0, b.yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      benchMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(benchMesh);

    const pathMat = new THREE.MeshStandardMaterial({ color: "#cfc6b4", roughness: 0.95 });
    const pathA = new THREE.BoxGeometry(1.6, 0.06, 16);
    const pathB = new THREE.BoxGeometry(16, 0.06, 1.6);
    const pathsA = new THREE.InstancedMesh(pathA, pathMat, parks.length);
    const pathsB = new THREE.InstancedMesh(pathB, pathMat, parks.length);
    for (let i = 0; i < parks.length; i++) {
      const p = parks[i]!;
      const y = this.heightAt(p.x, p.z) + 0.12;
      dummy.position.set(p.x, y, p.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      pathsA.setMatrixAt(i, dummy.matrix);
      pathsB.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(pathsA, pathsB);

    const treeSpots: { x: number; z: number }[] = [];
    for (const p of parks) {
      for (const [ox, oz] of [
        [-7, -7],
        [7, -6],
        [-6, 7],
        [7, 7],
      ] as const) {
        const x = p.x + ox;
        const z = p.z + oz;
        if (this.onRoad(x, z)) continue;
        treeSpots.push({ x, z });
        this.trees.push({ x, z, r: 0.55 });
      }
    }
    if (treeSpots.length) {
      const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 1.8, 5);
      trunkGeo.translate(0, 0.9, 0);
      const leafGeo = new THREE.SphereGeometry(1.15, 7, 5);
      const trunks = new THREE.InstancedMesh(
        trunkGeo,
        new THREE.MeshStandardMaterial({ color: "#4a3424", roughness: 0.95 }),
        treeSpots.length,
      );
      const leaves = new THREE.InstancedMesh(
        leafGeo,
        new THREE.MeshStandardMaterial({ color: "#3d7a42", roughness: 0.82 }),
        treeSpots.length,
      );
      for (let i = 0; i < treeSpots.length; i++) {
        const p = treeSpots[i]!;
        const y = this.heightAt(p.x, p.z);
        dummy.position.set(p.x, y, p.z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);
        dummy.position.y = y + 2.3;
        dummy.updateMatrix();
        leaves.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(trunks, leaves);
    }

    const fountain = new THREE.Group();
    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(3.2, 3.4, 0.55, 16),
      new THREE.MeshStandardMaterial({ color: "#8b9098", roughness: 0.5, metalness: 0.25 }),
    );
    rim.position.y = 0.3;
    const pool = new THREE.Mesh(
      new THREE.CircleGeometry(2.8, 16),
      new THREE.MeshStandardMaterial({
        color: "#2a6a80",
        roughness: 0.12,
        metalness: 0.35,
        transparent: true,
        opacity: 0.85,
      }),
    );
    pool.rotation.x = -Math.PI / 2;
    pool.position.y = 0.48;
    const jet = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.18, 2.2, 8),
      new THREE.MeshStandardMaterial({ color: "#dce0e6", roughness: 0.2, metalness: 0.5 }),
    );
    jet.position.y = 1.4;
    fountain.add(rim, pool, jet);
    fountain.position.set(PLAZA.x, this.heightAt(PLAZA.x, PLAZA.z), PLAZA.z);
    this.group.add(fountain);
    this.buildings.push({ x: PLAZA.x, z: PLAZA.z, w: 6.4, d: 6.4, h: 1.2 });
  }

  private placeStreetFurniture() {
    const dummy = new THREE.Object3D();
    const poleGeo = new THREE.CylinderGeometry(0.07, 0.09, 3.4, 6);
    poleGeo.translate(0, 1.7, 0);
    const poleMat = new THREE.MeshStandardMaterial({ color: "#2a2c30" });
    const kinds: Array<"stop" | "yield" | "speed" | "cross" | "noentry"> = [
      "stop",
      "yield",
      "speed",
      "cross",
      "noentry",
    ];
    const signs: { x: number; z: number; yaw: number; kind: number }[] = [];
    const spots = [
      [28, 28],
      [-28, 28],
      [28, -28],
      [-28, -28],
      [56, 0],
      [-56, 0],
      [0, 56],
      [0, -56],
      [84, 28],
      [-84, -28],
      [42, -42],
      [-42, 42],
      [FACTORY.x + 40, FACTORY.z],
      [AIRPORT.x - 18, AIRPORT.z + 70],
    ];
    for (let i = 0; i < spots.length; i++) {
      const [sx, sz] = spots[i]!;
      const p = this.pushOffRoad(sx + 6, sz + 6, 1.5);
      signs.push({ x: p.x, z: p.z, yaw: hash2(i, 2) * 0.6, kind: i % kinds.length });
    }
    const poles = new THREE.InstancedMesh(poleGeo, poleMat, signs.length);
    for (let i = 0; i < signs.length; i++) {
      const s = signs[i]!;
      dummy.position.set(s.x, this.heightAt(s.x, s.z), s.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      poles.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(poles);

    const boardGeo = new THREE.PlaneGeometry(1.15, 1.15);
    for (let k = 0; k < kinds.length; k++) {
      const list = signs.filter((s) => s.kind === k);
      if (!list.length) continue;
      const mat = new THREE.MeshBasicMaterial({
        map: signTexture(kinds[k]!),
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.InstancedMesh(boardGeo, mat, list.length);
      for (let i = 0; i < list.length; i++) {
        const s = list[i]!;
        dummy.position.set(s.x, this.heightAt(s.x, s.z) + 3.35, s.z);
        dummy.rotation.set(0, s.yaw, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(mesh);
    }

    const lightPole = new THREE.CylinderGeometry(0.1, 0.12, 4.6, 6);
    lightPole.translate(0, 2.3, 0);
    const crossings = this.crosswalks;
    if (crossings.length) {
      const lp = new THREE.InstancedMesh(
        lightPole,
        new THREE.MeshStandardMaterial({ color: "#1c1f26" }),
        crossings.length,
      );
      const bulbGeo = new THREE.BoxGeometry(0.26, 0.2, 0.2);
      const redM = new THREE.MeshStandardMaterial({ color: "#e24a3b", emissive: "#e24a3b", emissiveIntensity: 0.15 });
      const ambM = new THREE.MeshStandardMaterial({ color: "#e8b86d", emissive: "#e8b86d", emissiveIntensity: 0.12 });
      const grnM = new THREE.MeshStandardMaterial({ color: "#5ecf9a", emissive: "#5ecf9a", emissiveIntensity: 0.85 });
      this.signalRed = redM;
      this.signalGreen = grnM;
      const reds = new THREE.InstancedMesh(bulbGeo, redM, crossings.length);
      const ambs = new THREE.InstancedMesh(bulbGeo, ambM, crossings.length);
      const grns = new THREE.InstancedMesh(bulbGeo, grnM, crossings.length);
      for (let i = 0; i < crossings.length; i++) {
        const c = crossings[i]!;
        const x = c.x + c.nx * c.side;
        const z = c.z + c.nz * c.side;
        const y = this.heightAt(x, z);
        dummy.position.set(x, y, z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        lp.setMatrixAt(i, dummy.matrix);
        dummy.position.set(x, y + 4.85, z);
        dummy.updateMatrix();
        reds.setMatrixAt(i, dummy.matrix);
        dummy.position.y = y + 4.55;
        dummy.updateMatrix();
        ambs.setMatrixAt(i, dummy.matrix);
        dummy.position.y = y + 4.25;
        dummy.updateMatrix();
        grns.setMatrixAt(i, dummy.matrix);
      }
      this.group.add(lp, reds, ambs, grns);
    }
  }

  private placeFactory() {
    const cx = FACTORY.x;
    const cz = FACTORY.z;
    const rust = new THREE.MeshStandardMaterial({ color: "#6a5340", roughness: 0.92, metalness: 0.18 });
    const dark = new THREE.MeshStandardMaterial({ color: "#2a2c30", roughness: 0.88 });
    const halls = [
      { x: cx - 22, z: cz - 8, w: 28, d: 14, h: 11 },
      { x: cx + 24, z: cz + 10, w: 22, d: 12, h: 9 },
      { x: cx + 8, z: cz - 22, w: 16, d: 10, h: 7 },
    ];
    for (const h of halls) {
      const body = new THREE.Mesh(new THREE.BoxGeometry(h.w, h.h, h.d), rust);
      body.position.set(h.x, this.heightAt(h.x, h.z) + h.h / 2, h.z);
      body.castShadow = true;
      const roof = new THREE.Mesh(new THREE.BoxGeometry(h.w + 1.2, 0.4, h.d + 1.2), dark);
      roof.position.set(h.x, this.heightAt(h.x, h.z) + h.h + 0.15, h.z);
      const chimney = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.4, 8, 8), dark);
      chimney.position.set(h.x + h.w * 0.3, this.heightAt(h.x, h.z) + h.h + 4, h.z);
      this.group.add(body, roof, chimney);
      this.buildings.push({ x: h.x, z: h.z, w: h.w, d: h.d, h: h.h });
    }
    const tank = new THREE.Mesh(
      new THREE.CylinderGeometry(4.2, 4.2, 7.5, 12),
      new THREE.MeshStandardMaterial({ color: "#4a5560", roughness: 0.55, metalness: 0.4 }),
    );
    tank.position.set(cx - 8, this.heightAt(cx, cz) + 3.8, cz + 22);
    this.group.add(tank);
    this.buildings.push({ x: cx - 8, z: cz + 22, w: 8.4, d: 8.4, h: 7.5 });

    const dummy = new THREE.Object3D();
    const barrelGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.9, 8);
    const barrelMat = new THREE.MeshStandardMaterial({ color: "#4a5560", roughness: 0.55, metalness: 0.3 });
    const barrels: { x: number; z: number }[] = [];
    for (let i = 0; i < 16; i++) {
      barrels.push({
        x: cx - 36 + (i % 8) * 1.1,
        z: cz + 18 + Math.floor(i / 8) * 1.2,
      });
    }
    const barrelMesh = new THREE.InstancedMesh(barrelGeo, barrelMat, barrels.length);
    for (let i = 0; i < barrels.length; i++) {
      const p = barrels[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z) + 0.45, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      barrelMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(barrelMesh);

    const crateGeo = new THREE.BoxGeometry(1.4, 1.1, 1.4);
    const crateMat = new THREE.MeshStandardMaterial({ color: "#6a5340", roughness: 0.9 });
    const crates = new THREE.InstancedMesh(crateGeo, crateMat, 8);
    for (let i = 0; i < 8; i++) {
      dummy.position.set(cx + 32 + (i % 4) * 1.8, this.heightAt(cx, cz) + 0.55, cz - 6 + Math.floor(i / 4) * 1.8);
      dummy.rotation.set(0, i * 0.2, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      crates.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(crates);

    const coneGeo = new THREE.ConeGeometry(0.28, 0.8, 6);
    const coneMat = new THREE.MeshStandardMaterial({ color: "#e24a3b" });
    const cones: { x: number; z: number }[] = [];
    for (let i = 0; i < 22; i++) {
      const t = (i / 22) * Math.PI * 2;
      cones.push({ x: cx + Math.cos(t) * 40, z: cz + Math.sin(t) * 28 });
    }
    const coneMesh = new THREE.InstancedMesh(coneGeo, coneMat, cones.length);
    for (let i = 0; i < cones.length; i++) {
      const p = cones[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z) + 0.4, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      coneMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(coneMesh);

    const stack = new THREE.Mesh(
      new THREE.CylinderGeometry(1.5, 2.1, 18, 8),
      new THREE.MeshStandardMaterial({ color: "#3a4048", roughness: 0.8, metalness: 0.25 }),
    );
    stack.position.set(cx - 28, this.heightAt(cx - 28, cz - 6) + 9, cz - 6);
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(1.7, 1.7, 0.45, 8),
      new THREE.MeshStandardMaterial({ color: "#c45c3a" }),
    );
    band.position.set(cx - 28, this.heightAt(cx - 28, cz - 6) + 14, cz - 6);
    this.group.add(stack, band);
    this.buildings.push({ x: cx - 28, z: cz - 6, w: 4.2, d: 4.2, h: 18 });

    const tireGeo = new THREE.TorusGeometry(0.55, 0.18, 6, 10);
    const tireMat = new THREE.MeshStandardMaterial({ color: "#1c1f26", roughness: 0.9 });
    const tires = new THREE.InstancedMesh(tireGeo, tireMat, 14);
    for (let i = 0; i < 14; i++) {
      const col = i % 7;
      const row = Math.floor(i / 7);
      dummy.position.set(cx + 16 + col * 1.3, this.heightAt(cx, cz) + 0.55 + row * 0.35, cz + 16);
      dummy.rotation.set(Math.PI / 2, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      tires.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(tires);

    const label = document.createElement("canvas");
    label.width = 512;
    label.height = 128;
    const lctx = label.getContext("2d")!;
    lctx.clearRect(0, 0, 512, 128);
    lctx.fillStyle = "#e24a3b";
    lctx.font = "900 96px sans-serif";
    lctx.textAlign = "center";
    lctx.textBaseline = "middle";
    lctx.fillText("DRIFT", 256, 68);
    const ltex = new THREE.CanvasTexture(label);
    ltex.colorSpace = THREE.SRGBColorSpace;
    const decal = new THREE.Mesh(
      new THREE.PlaneGeometry(26, 6.5),
      new THREE.MeshBasicMaterial({ map: ltex, transparent: true, depthWrite: false }),
    );
    decal.rotation.x = -Math.PI / 2;
    decal.position.set(cx, this.heightAt(cx, cz) + 0.18, cz);
    this.group.add(decal);

    this.addSign(cx, cz, "GYÁR", "#67e8f9");
  }

  private placeAirport() {
    const cx = AIRPORT.x;
    const cz = AIRPORT.z;
    const tarmac = new THREE.Mesh(
      new THREE.BoxGeometry(28, 0.08, 160),
      new THREE.MeshStandardMaterial({ color: "#2a2c30", roughness: 0.92 }),
    );
    tarmac.position.set(cx, this.heightAt(cx, cz) + 0.05, cz);
    this.group.add(tarmac);
    const line = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.04, 150),
      new THREE.MeshBasicMaterial({ color: 0xf1f2f4 }),
    );
    line.position.set(cx, this.heightAt(cx, cz) + 0.12, cz);
    this.group.add(line);
    const start = new THREE.Mesh(
      new THREE.BoxGeometry(22, 0.08, 1.4),
      new THREE.MeshStandardMaterial({ color: "#e24a3b" }),
    );
    start.position.set(cx, this.heightAt(cx, cz) + 0.14, cz + 62);
    this.group.add(start);

    const num = document.createElement("canvas");
    num.width = 256;
    num.height = 256;
    const nctx = num.getContext("2d")!;
    nctx.clearRect(0, 0, 256, 256);
    nctx.fillStyle = "#f4f6f8";
    nctx.font = "900 150px sans-serif";
    nctx.textAlign = "center";
    nctx.textBaseline = "middle";
    nctx.fillText("09", 128, 132);
    const ntex = new THREE.CanvasTexture(num);
    ntex.colorSpace = THREE.SRGBColorSpace;
    const number = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshBasicMaterial({ map: ntex, transparent: true, depthWrite: false }),
    );
    number.rotation.x = -Math.PI / 2;
    number.position.set(cx, this.heightAt(cx, cz) + 0.16, cz + 48);
    this.group.add(number);

    const chevGeo = new THREE.BoxGeometry(6.5, 0.05, 0.7);
    const chevMat = new THREE.MeshBasicMaterial({ color: 0xf1f2f4 });
    const chevs = new THREE.InstancedMesh(chevGeo, chevMat, 8);
    const chevDummy = new THREE.Object3D();
    for (let i = 0; i < 8; i++) {
      chevDummy.position.set(cx, this.heightAt(cx, cz) + 0.15, cz + 58 - i * 4.2);
      chevDummy.rotation.set(0, i % 2 === 0 ? 0.55 : -0.55, 0);
      chevDummy.scale.set(1, 1, 1);
      chevDummy.updateMatrix();
      chevs.setMatrixAt(i, chevDummy.matrix);
    }
    this.group.add(chevs);

    const hangarMat = new THREE.MeshStandardMaterial({ color: "#8a9098", roughness: 0.7, metalness: 0.2 });
    for (const ox of [-38, 38]) {
      const hall = new THREE.Mesh(new THREE.BoxGeometry(22, 8, 28), hangarMat);
      hall.position.set(cx + ox, this.heightAt(cx + ox, cz + 10) + 4, cz + 10);
      hall.castShadow = true;
      this.group.add(hall);
      this.buildings.push({ x: cx + ox, z: cz + 10, w: 22, d: 28, h: 8 });
    }
    const tower = new THREE.Mesh(
      new THREE.CylinderGeometry(2.2, 2.8, 14, 8),
      new THREE.MeshStandardMaterial({ color: "#d8dce2", roughness: 0.55 }),
    );
    tower.position.set(cx + 48, this.heightAt(cx + 48, cz - 20) + 7, cz - 20);
    const cap = new THREE.Mesh(
      new THREE.CylinderGeometry(3.4, 2.4, 2.2, 8),
      new THREE.MeshStandardMaterial({
        color: "#3d5c7a",
        roughness: 0.3,
        metalness: 0.4,
        transparent: true,
        opacity: 0.85,
      }),
    );
    cap.position.set(cx + 48, this.heightAt(cx + 48, cz - 20) + 15.2, cz - 20);
    this.group.add(tower, cap);
    this.buildings.push({ x: cx + 48, z: cz - 20, w: 6, d: 6, h: 16 });

    const plane = new THREE.Group();
    const alum = new THREE.MeshStandardMaterial({ color: "#d8dce2", roughness: 0.35, metalness: 0.55 });
    const fuse = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.55, 9.2, 10), alum);
    fuse.rotation.x = Math.PI / 2;
    fuse.position.y = 1.4;
    const wing = new THREE.Mesh(new THREE.BoxGeometry(14, 0.14, 2.2), alum);
    wing.position.set(0, 1.35, 0.2);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.14, 2.1, 1.6), alum);
    tail.position.set(0, 2.35, 4.2);
    const stab = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.1, 1.1), alum);
    stab.position.set(0, 2.7, 4.1);
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.62, 10, 8), alum);
    nose.scale.set(1, 1, 1.3);
    nose.position.set(0, 1.4, -4.7);
    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.28, 8.4),
      new THREE.MeshStandardMaterial({ color: "#1e4d8c" }),
    );
    stripe.position.set(0.72, 1.55, 0);
    const eng = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 1.5, 8), alum);
    eng.rotation.x = Math.PI / 2;
    eng.position.set(-2.4, 1.05, 0.3);
    const eng2 = eng.clone();
    eng2.position.x = 2.4;
    plane.add(fuse, wing, tail, stab, nose, stripe, eng, eng2);
    plane.position.set(cx + 38, this.heightAt(cx + 38, cz - 40), cz - 40);
    plane.rotation.y = 0.4;
    this.group.add(plane);
    this.buildings.push({ x: cx + 38, z: cz - 40, w: 11, d: 10, h: 3 });

    const sock = new THREE.Mesh(
      new THREE.ConeGeometry(0.35, 1.8, 6),
      new THREE.MeshStandardMaterial({ color: "#e24a3b", roughness: 0.7 }),
    );
    sock.rotation.z = Math.PI / 2;
    sock.position.set(cx - 22, this.heightAt(cx - 22, cz + 50) + 4.2, cz + 50);
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.1, 4.4, 6),
      new THREE.MeshStandardMaterial({ color: "#dce0e6" }),
    );
    pole.position.set(cx - 22, this.heightAt(cx - 22, cz + 50) + 2.2, cz + 50);
    this.group.add(sock, pole);

    this.addSign(cx, cz + 50, "REPÜLŐ", "#e24a3b");
  }

  private placeSuburb() {
    const dummy = new THREE.Object3D();
    const bodyGeo = new THREE.BoxGeometry(1, 1, 1);
    bodyGeo.translate(0, 0.5, 0);
    const wall = new THREE.MeshStandardMaterial({ map: houseFacadeTexture(), roughness: 0.85 });
    const houses: { x: number; z: number; s: number; yaw: number; col: number }[] = [];
    for (let i = 0; i < 90; i++) {
      const a = hash2(i, 2) * Math.PI * 2;
      const r = 142 + hash2(i, 5) * 40;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (this.onRoad(x, z) || this.skipNear(x, z, 14)) continue;
      const b = biomeAt(x, z);
      if (b !== "suburb" && b !== "hills") continue;
      houses.push({
        x,
        z,
        s: 6.5 + hash2(i, 8) * 2.2,
        yaw: Math.floor(hash2(i, 9) * 4) * (Math.PI / 2),
        col: [0xc8b49a, 0xb8c4b0, 0xd0c8bc, 0xa8b0a4][i % 4]!,
      });
      this.buildings.push({ x, z, w: 8, d: 8, h: 4.2 });
    }
    const mesh = new THREE.InstancedMesh(bodyGeo, wall, houses.length);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    const color = new THREE.Color();
    for (let i = 0; i < houses.length; i++) {
      const h = houses[i]!;
      dummy.position.set(h.x, this.heightAt(h.x, h.z), h.z);
      dummy.scale.set(h.s, 3.6, h.s * 0.85);
      dummy.rotation.set(0, h.yaw, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      color.setHex(h.col);
      mesh.setColorAt(i, color);
    }
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.group.add(mesh);

    const roofGeo = new THREE.ConeGeometry(0.85, 1.1, 4);
    roofGeo.rotateY(Math.PI / 4);
    const roofMat = new THREE.MeshStandardMaterial({ color: "#6a4038", roughness: 0.9 });
    const roofs = new THREE.InstancedMesh(roofGeo, roofMat, houses.length);
    for (let i = 0; i < houses.length; i++) {
      const h = houses[i]!;
      dummy.position.set(h.x, this.heightAt(h.x, h.z) + 4.15, h.z);
      dummy.scale.set(h.s * 0.85, 1.4, h.s * 0.75);
      dummy.rotation.set(0, h.yaw, 0);
      dummy.updateMatrix();
      roofs.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(roofs);
  }

  private placeNature() {
    const dummy = new THREE.Object3D();
    const trunkGeo = new THREE.CylinderGeometry(0.18, 0.28, 2.2, 5);
    trunkGeo.translate(0, 1.1, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: "#4a3424", roughness: 0.95 });
    const leafGeo = new THREE.ConeGeometry(1.4, 3.6, 6);
    leafGeo.translate(0, 3.4, 0);
    const leafMat = new THREE.MeshStandardMaterial({ color: "#2f5a34", roughness: 0.85 });
    const leaf2Geo = new THREE.ConeGeometry(1.05, 2.4, 6);
    leaf2Geo.translate(0, 4.6, 0);
    const treePos: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < 300; i++) {
      const x = (hash2(i, 11) - 0.5) * SIZE * 0.92;
      const z = (hash2(i, 29) - 0.5) * SIZE * 0.92;
      const b = biomeAt(x, z);
      if (b !== "forest" && b !== "hills" && b !== "suburb" && b !== "coast") continue;
      if (b === "suburb" && hash2(i, 3) > 0.28) continue;
      if (b === "coast" && hash2(i, 4) > 0.18) continue;
      if (this.onRoad(x, z)) continue;
      if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 6) continue;
      if (Math.hypot(x + 412, z - 118) < 10) continue;
      if (Math.hypot(x - FACTORY.x, z - FACTORY.z) < 58) continue;
      if (Math.hypot(x - AIRPORT.x, z - AIRPORT.z) < 90) continue;
      const s = 0.75 + hash2(i, 7) * 1.15;
      treePos.push({ x, z, s });
      this.trees.push({ x, z, r: 0.9 * s });
    }
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treePos.length);
    trunks.castShadow = true;
    const leaves = new THREE.InstancedMesh(leafGeo, leafMat, treePos.length);
    leaves.castShadow = true;
    const leaves2 = new THREE.InstancedMesh(leaf2Geo, leafMat, treePos.length);
    const leafCol = new THREE.Color();
    for (let i = 0; i < treePos.length; i++) {
      const t = treePos[i]!;
      dummy.position.set(t.x, this.heightAt(t.x, t.z), t.z);
      dummy.scale.setScalar(t.s);
      dummy.rotation.y = hash2(i, 1) * Math.PI * 2;
      dummy.updateMatrix();
      trunks.setMatrixAt(i, dummy.matrix);
      dummy.scale.set(t.s * (0.85 + hash2(i, 2) * 0.4), t.s, t.s * (0.85 + hash2(i, 5) * 0.4));
      dummy.updateMatrix();
      leaves.setMatrixAt(i, dummy.matrix);
      dummy.scale.set(t.s * 0.9, t.s * 0.95, t.s * 0.9);
      dummy.updateMatrix();
      leaves2.setMatrixAt(i, dummy.matrix);
      leafCol.setHSL(0.28 + hash2(i, 8) * 0.08, 0.44, 0.28 + hash2(i, 9) * 0.1);
      leaves.setColorAt(i, leafCol);
      leaves2.setColorAt(i, leafCol);
    }
    if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
    if (leaves2.instanceColor) leaves2.instanceColor.needsUpdate = true;
    this.group.add(trunks, leaves, leaves2);

    const rockGeo = new THREE.DodecahedronGeometry(1.1, 0);
    const rockMat = new THREE.MeshStandardMaterial({ color: "#8a8074", roughness: 0.95 });
    const rocks: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < 160; i++) {
      const x = (hash2(i, 41) - 0.5) * SIZE * 0.9;
      const z = (hash2(i, 43) - 0.5) * SIZE * 0.9;
      const b = biomeAt(x, z);
      if (b !== "desert" && b !== "hills" && b !== "coast") continue;
      if (this.onRoad(x, z)) continue;
      rocks.push({ x, z, s: 0.6 + hash2(i, 12) * 1.8 });
    }
    const rockMesh = new THREE.InstancedMesh(rockGeo, rockMat, rocks.length);
    for (let i = 0; i < rocks.length; i++) {
      const r = rocks[i]!;
      dummy.position.set(r.x, this.heightAt(r.x, r.z) + 0.2, r.z);
      dummy.scale.setScalar(r.s);
      dummy.rotation.set(hash2(i, 1), hash2(i, 2), hash2(i, 3));
      dummy.updateMatrix();
      rockMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(rockMesh);

    const cactGeo = new THREE.CylinderGeometry(0.18, 0.22, 2.4, 6);
    cactGeo.translate(0, 1.2, 0);
    const cactMat = new THREE.MeshStandardMaterial({ color: "#3d6a3a" });
    const cacti: { x: number; z: number }[] = [];
    for (let i = 0; i < 110; i++) {
      const x = (hash2(i, 61) - 0.5) * 520;
      const z = -240 - hash2(i, 62) * 220;
      if (biomeAt(x, z) !== "desert" || this.onRoad(x, z)) continue;
      cacti.push({ x, z });
    }
    const cactMesh = new THREE.InstancedMesh(cactGeo, cactMat, cacti.length);
    for (let i = 0; i < cacti.length; i++) {
      const p = cacti[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z), p.z);
      dummy.scale.set(1, 0.8 + hash2(i, 3) * 1.4, 1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      cactMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(cactMesh);

    const hayGeo = new THREE.CylinderGeometry(0.85, 0.85, 1.3, 8);
    hayGeo.rotateZ(Math.PI / 2);
    const hayMat = new THREE.MeshStandardMaterial({ color: "#c8a84a", roughness: 0.92 });
    const hays: { x: number; z: number }[] = [];
    for (let i = 0; i < 70; i++) {
      const x = 240 + hash2(i, 71) * 200;
      const z = (hash2(i, 72) - 0.5) * 220;
      if (biomeAt(x, z) !== "country" || this.onRoad(x, z)) continue;
      hays.push({ x, z });
    }
    const hayMesh = new THREE.InstancedMesh(hayGeo, hayMat, hays.length);
    for (let i = 0; i < hays.length; i++) {
      const p = hays[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z) + 0.7, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, hash2(i, 3) * Math.PI, 0.1);
      dummy.updateMatrix();
      hayMesh.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(hayMesh);

    const palmTrunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 5.2, 6);
    palmTrunkGeo.translate(0, 2.6, 0);
    const palmTrunkMat = new THREE.MeshStandardMaterial({ color: "#6a5340", roughness: 0.92 });
    const palmLeafGeo = new THREE.SphereGeometry(1.6, 6, 5);
    palmLeafGeo.scale(1, 0.28, 1);
    const palmLeafMat = new THREE.MeshStandardMaterial({ color: "#2f6a38", roughness: 0.82 });
    const palms: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < 70; i++) {
      const x = (hash2(i, 81) - 0.5) * 280;
      const z = 280 + hash2(i, 82) * 180;
      if (biomeAt(x, z) !== "coast") continue;
      if (this.onRoad(x, z)) continue;
      if (Math.hypot(x - this.lake.x, z - this.lake.z) < this.lake.r + 8) continue;
      palms.push({ x, z, s: 0.85 + hash2(i, 83) * 0.7 });
      this.trees.push({ x, z, r: 0.55 });
    }
    const palmTrunks = new THREE.InstancedMesh(palmTrunkGeo, palmTrunkMat, palms.length);
    palmTrunks.castShadow = true;
    const palmLeaves = new THREE.InstancedMesh(palmLeafGeo, palmLeafMat, palms.length);
    palmLeaves.castShadow = true;
    for (let i = 0; i < palms.length; i++) {
      const p = palms[i]!;
      dummy.position.set(p.x, this.heightAt(p.x, p.z), p.z);
      dummy.scale.setScalar(p.s);
      dummy.rotation.set(0, hash2(i, 4) * Math.PI, 0);
      dummy.updateMatrix();
      palmTrunks.setMatrixAt(i, dummy.matrix);
      dummy.position.y += 5.1 * p.s;
      dummy.scale.set(p.s * 1.4, p.s, p.s * 1.4);
      dummy.updateMatrix();
      palmLeaves.setMatrixAt(i, dummy.matrix);
    }
    this.group.add(palmTrunks, palmLeaves);
  }

  private placeLandmarks() {
    const garage = this.makeShed(18, 7, 14, "#6a7380", "#3a4048");
    garage.position.set(52, this.heightAt(52, 28), 28);
    this.group.add(garage);
    this.buildings.push({ x: 52, z: 28, w: 18, d: 14, h: 7 });
    this.addSign(52, 28, "MŰHELY", "#8aa4b8");

    const dealer = this.makeShed(20, 6, 16, "#d8dce2", "#2a3038");
    dealer.position.set(-56, this.heightAt(-56, 28), 28);
    this.group.add(dealer);
    this.buildings.push({ x: -56, z: 28, w: 20, d: 16, h: 6 });
    this.addSign(-56, 28, "AUTÓ", "#dce0e6");

    const taxi = this.makeShed(10, 3.4, 8, "#e8b86d", "#2a2c30");
    taxi.position.set(8, this.heightAt(8, 88), 88);
    this.group.add(taxi);
    this.buildings.push({ x: 8, z: 88, w: 10, d: 8, h: 3.4 });
    this.addSign(8, 88, "TAXI", "#e8b86d");

    const courier = this.makeShed(14, 6.2, 12, "#3d6a58", "#1c2a24");
    courier.position.set(-88, this.heightAt(-88, -44), -44);
    this.group.add(courier);
    this.buildings.push({ x: -88, z: -44, w: 14, d: 12, h: 6.2 });
    this.addSign(-88, -44, "FUTÁR", "#5ecf9a");

    const market = this.makeShed(12, 4.5, 10, "#c45c3a", "#5a3028");
    market.position.set(92, this.heightAt(92, -36), -36);
    this.group.add(market);
    this.buildings.push({ x: 92, z: -36, w: 12, d: 10, h: 4.5 });
    this.addSign(92, -36, "PIAC", "#c45c3a");

    const house = this.makeShed(8, 4.2, 8, "#e8c4a8", "#6a4038");
    house.position.set(318, this.heightAt(318, 42), 42);
    this.group.add(house);
    this.buildings.push({ x: 318, z: 42, w: 8, d: 8, h: 4.2 });

    const dock = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 0.28, 18),
      new THREE.MeshStandardMaterial({ color: "#6a5340" }),
    );
    dock.position.set(-36, this.waterY + 0.2, 392);
    this.group.add(dock);

    const secret = new THREE.Mesh(
      new THREE.BoxGeometry(3.4, 1.15, 4.4),
      new THREE.MeshStandardMaterial({
        color: "#c8d4dc",
        emissive: "#3a6a78",
        emissiveIntensity: 0.3,
        metalness: 0.6,
        roughness: 0.25,
      }),
    );
    secret.position.set(-412, this.heightAt(-412, 118) + 0.7, 118);
    secret.name = "hiddenCar";
    this.hiddenMesh = secret;
    this.group.add(secret);

    const van = this.makeIceCreamVan();
    van.position.set(48, this.heightAt(48, 348), 348);
    this.group.add(van);
    this.buildings.push({ x: 48, z: 348, w: 5, d: 7, h: 3.2 });

    const umbrellaGeo = new THREE.ConeGeometry(1.8, 0.45, 8);
    const umbrellaMat = new THREE.MeshStandardMaterial({ color: "#e8b86d" });
    for (let i = 0; i < 6; i++) {
      const x = 30 + i * 8;
      const z = 370 + (i % 2) * 8;
      const u = new THREE.Mesh(umbrellaGeo, umbrellaMat);
      u.position.set(x, this.heightAt(x, z) + 2.2, z);
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5),
        new THREE.MeshStandardMaterial({ color: "#dce0e6" }),
      );
      pole.position.set(x, this.heightAt(x, z) + 1.1, z);
      this.group.add(u, pole);
    }

    this.addWindmill(372, 88);
    this.addDog(312, 46);
    this.addParkedCars();
  }

  private addSign(x: number, z: number, _label: string, color: string) {
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.1, 3.6, 6),
      new THREE.MeshStandardMaterial({ color: "#2a2c30" }),
    );
    pole.position.set(x - 8, this.heightAt(x, z) + 1.8, z + 8);
    const board = new THREE.Mesh(
      new THREE.BoxGeometry(2.4, 0.9, 0.12),
      new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.2 }),
    );
    board.position.set(x - 8, this.heightAt(x, z) + 3.4, z + 8);
    this.group.add(pole, board);
  }

  private makeIceCreamVan() {
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 1.6, 4.2),
      new THREE.MeshStandardMaterial({ color: "#f2efe8" }),
    );
    body.position.y = 1.15;
    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(2.24, 0.28, 4.24),
      new THREE.MeshStandardMaterial({ color: "#5ecf9a" }),
    );
    stripe.position.y = 1.35;
    const roof = new THREE.Mesh(
      new THREE.BoxGeometry(2.0, 0.35, 2.2),
      new THREE.MeshStandardMaterial({ color: "#e24a3b" }),
    );
    roof.position.set(0, 2.1, 0.2);
    const scoop = new THREE.Mesh(
      new THREE.SphereGeometry(0.45, 10, 8),
      new THREE.MeshStandardMaterial({ color: "#f2d2c4" }),
    );
    scoop.position.set(0, 2.55, 0.2);
    g.add(body, stripe, roof, scoop);
    return g;
  }

  private makeShed(w: number, h: number, d: number, wall: string, roof: string) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(w, h, d),
      new THREE.MeshStandardMaterial({ color: wall, roughness: 0.8 }),
    );
    body.position.y = h / 2;
    const rf = new THREE.Mesh(
      new THREE.BoxGeometry(w + 0.8, 0.35, d + 0.8),
      new THREE.MeshStandardMaterial({ color: roof }),
    );
    rf.position.y = h + 0.1;
    const door = new THREE.Mesh(
      new THREE.BoxGeometry(w * 0.35, h * 0.55, 0.12),
      new THREE.MeshStandardMaterial({ color: "#1c1f26" }),
    );
    door.position.set(0, h * 0.32, d / 2 + 0.02);
    g.add(body, rf, door);
    return g;
  }

  private addWindmill(x: number, z: number) {
    const y = this.heightAt(x, z);
    const tower = new THREE.Mesh(
      new THREE.CylinderGeometry(1.1, 1.6, 11, 8),
      new THREE.MeshStandardMaterial({ color: "#d8d4c8", roughness: 0.86 }),
    );
    tower.position.set(x, y + 5.5, z);
    tower.castShadow = true;
    const cap = new THREE.Mesh(
      new THREE.ConeGeometry(1.6, 1.8, 8),
      new THREE.MeshStandardMaterial({ color: "#6a4038" }),
    );
    cap.position.set(x, y + 12.1, z);
    const blades = new THREE.Group();
    const bladeMat = new THREE.MeshStandardMaterial({ color: "#ece8e0", roughness: 0.7 });
    for (let i = 0; i < 4; i++) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.28, 7.2, 0.7), bladeMat);
      b.position.y = 3.2;
      const arm = new THREE.Group();
      arm.rotation.z = (i * Math.PI) / 2;
      arm.add(b);
      blades.add(arm);
    }
    blades.position.set(x, y + 11.2, z + 1.2);
    this.windmillBlades = blades;
    this.group.add(tower, cap, blades);
    this.buildings.push({ x, z, w: 3.4, d: 3.4, h: 12 });
  }

  private addDog(x: number, z: number) {
    const g = new THREE.Group();
    const fur = new THREE.MeshStandardMaterial({ color: "#6a5340", roughness: 0.9 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.45, 3, 6), fur);
    body.rotation.z = Math.PI / 2;
    body.position.y = 0.32;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), fur);
    head.position.set(0.38, 0.42, 0);
    const ear = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.16, 5), fur);
    ear.position.set(0.32, 0.58, 0.1);
    const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.03, 0.35, 5), fur);
    tail.position.set(-0.38, 0.42, 0);
    tail.rotation.z = 0.7;
    g.add(body, head, ear, tail);
    g.position.set(x, this.heightAt(x, z), z);
    g.name = "bodri";
    this.group.add(g);
  }

  private addParkedCars() {
    const dummy = new THREE.Object3D();
    const bodyGeo = new THREE.BoxGeometry(1.7, 0.55, 3.6);
    bodyGeo.translate(0, 0.55, 0);
    const bodyMat = new THREE.MeshStandardMaterial({ roughness: 0.38, metalness: 0.42 });
    const spots: { x: number; z: number; yaw: number; col: number }[] = [];
    const cols = [0x3d5c7a, 0x8a9098, 0xc45c3a, 0x1e4d8c, 0x2a2c30, 0xd8d4c8];
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2;
      const r = 148 + (i % 3) * 4;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (this.onRoad(x, z) || this.skipNear(x, z, 12)) continue;
      spots.push({ x, z, yaw: a + Math.PI / 2, col: cols[i % cols.length]! });
      this.buildings.push({ x, z, w: 2.2, d: 4.2, h: 1.4 });
    }
    const mesh = new THREE.InstancedMesh(bodyGeo, bodyMat, spots.length);
    mesh.castShadow = true;
    const color = new THREE.Color();
    for (let i = 0; i < spots.length; i++) {
      const s = spots[i]!;
      dummy.position.set(s.x, this.heightAt(s.x, s.z), s.z);
      dummy.rotation.set(0, s.yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      color.setHex(s.col);
      mesh.setColorAt(i, color);
    }
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.group.add(mesh);
  }

  private placePois() {
    for (const p of POIS) {
      if (p.id === "statue" || p.id === "hidden") continue;
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(2.4, 0.09, 6, 22),
        new THREE.MeshStandardMaterial({
          color: p.color,
          emissive: p.color,
          emissiveIntensity: 0.4,
        }),
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(p.x, this.heightAt(p.x, p.z) + 0.22, p.z);
      ring.userData.poi = p.id;
      this.group.add(ring);
      const sprite = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: poiLabelTexture(p.name, p.color),
          transparent: true,
          depthWrite: false,
        }),
      );
      sprite.position.set(p.x, this.heightAt(p.x, p.z) + 4.6, p.z);
      sprite.scale.set(10.5, 2, 1);
      this.group.add(sprite);
    }
  }

  private placeClouds() {
    const g = new THREE.Group();
    const geo = new THREE.SphereGeometry(1, 8, 6);
    const mat = new THREE.MeshBasicMaterial({ color: 0xf4f6f8, transparent: true, opacity: 0.55 });
    const dummy = new THREE.Object3D();
    const n = 36;
    const mesh = new THREE.InstancedMesh(geo, mat, n);
    for (let i = 0; i < n; i++) {
      dummy.position.set((hash2(i, 1) - 0.5) * 900, 70 + hash2(i, 2) * 50, (hash2(i, 3) - 0.5) * 900);
      dummy.scale.set(18 + hash2(i, 4) * 22, 6 + hash2(i, 5) * 6, 12 + hash2(i, 6) * 16);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    g.add(mesh);
    this.clouds = g;
    this.group.add(g);
  }

  collide(x: number, z: number, radius: number): { nx: number; nz: number; depth: number } | null {
    let best: { nx: number; nz: number; depth: number } | null = null;
    let bestD = 0;
    for (const b of this.buildings) {
      const px = clamp(x, b.x - b.w / 2, b.x + b.w / 2);
      const pz = clamp(z, b.z - b.d / 2, b.z + b.d / 2);
      const dx = x - px;
      const dz = z - pz;
      const d2 = dx * dx + dz * dz;
      if (d2 < radius * radius) {
        const d = Math.sqrt(d2) || 0.0001;
        const depth = radius - d;
        if (depth > bestD) {
          bestD = depth;
          best = { nx: dx / d, nz: dz / d, depth };
        }
      }
    }
    for (const t of this.trees) {
      const dx = x - t.x;
      const dz = z - t.z;
      const d = Math.hypot(dx, dz) || 0.0001;
      const min = radius + t.r;
      if (d < min) {
        const depth = min - d;
        if (depth > bestD) {
          bestD = depth;
          best = { nx: dx / d, nz: dz / d, depth };
        }
      }
    }
    const lim = WORLD_HALF - 4;
    if (Math.abs(x) > lim) {
      const depth = Math.abs(x) - lim;
      if (depth > bestD) best = { nx: -Math.sign(x), nz: 0, depth };
    }
    if (Math.abs(z) > lim) {
      const depth = Math.abs(z) - lim;
      if (depth > bestD) best = { nx: 0, nz: -Math.sign(z), depth };
    }
    return best;
  }
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}
function clamp01(v: number) {
  return clamp(v, 0, 1);
}
