import * as THREE from "three";

export class SkidTrail {
  mesh: THREE.InstancedMesh;
  private next = 0;
  private readonly n = 220;
  private dummy = new THREE.Object3D();
  private cooldown = 0;

  constructor(scene: THREE.Scene) {
    const geo = new THREE.PlaneGeometry(0.26, 1.05);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x16171a,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    });
    this.mesh = new THREE.InstancedMesh(geo, mat, this.n);
    this.mesh.frustumCulled = false;
    this.dummy.position.set(0, -40, 0);
    this.dummy.scale.setScalar(0);
    this.dummy.updateMatrix();
    for (let i = 0; i < this.n; i++) this.mesh.setMatrixAt(i, this.dummy.matrix);
    scene.add(this.mesh);
  }

  emit(
    x: number,
    y: number,
    z: number,
    yaw: number,
    dt: number,
    drifting: boolean,
    speed: number,
  ) {
    this.cooldown -= dt;
    if (!drifting || Math.abs(speed) < 8 || this.cooldown > 0) return;
    this.cooldown = 0.032;
    const i = this.next++ % this.n;
    this.dummy.position.set(x, y + 0.035, z);
    this.dummy.rotation.set(0, yaw, 0);
    this.dummy.scale.set(1, 1, 1);
    this.dummy.updateMatrix();
    this.mesh.setMatrixAt(i, this.dummy.matrix);
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}
