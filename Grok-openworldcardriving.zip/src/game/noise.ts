export function hash2(x: number, z: number): number {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return n - Math.floor(n);
}

export function hash3(x: number, z: number, s: number): number {
  const n = Math.sin(x * 269.5 + z * 183.3 + s * 91.7) * 23421.631;
  return n - Math.floor(n);
}

function fade(t: number) {
  return t * t * (3 - 2 * t);
}

export function valueNoise(x: number, z: number): number {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = fade(x - x0);
  const fz = fade(z - z0);
  const a = hash2(x0, z0);
  const b = hash2(x0 + 1, z0);
  const c = hash2(x0, z0 + 1);
  const d = hash2(x0 + 1, z0 + 1);
  return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
}

export function fbm(x: number, z: number, oct = 4): number {
  let v = 0;
  let a = 0.5;
  let f = 1;
  let s = 0;
  for (let i = 0; i < oct; i++) {
    v += valueNoise(x * f, z * f) * a;
    s += a;
    a *= 0.5;
    f *= 2.03;
  }
  return v / s;
}
