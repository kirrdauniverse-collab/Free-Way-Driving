const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "KeyE",
  "KeyH",
  "KeyM",
  "KeyV",
  "KeyP",
  "Space",
  "Escape",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "ShiftLeft",
  "ShiftRight",
]);

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function radialDeadzone(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class InputManager {
  keys = new Set<string>();
  qaKeys: string[] | null = null;
  qaSteer: number | null = null;
  blocked = false;

  steerTouch = 0;
  throttleTouch = 0;
  brakeTouch = 0;
  handbrakeTouch = false;
  interactTouch = false;
  hornTouch = false;
  pauseTouch = false;
  mapTouch = false;

  steer = 0;
  throttle = 0;
  brake = 0;
  handbrake = false;
  interact = false;
  interactPressed = false;
  horn = false;
  hornPressed = false;
  pausePressed = false;
  mapPressed = false;
  cameraPressed = false;

  private prevInteract = false;
  private prevHorn = false;
  private prevPause = false;
  private prevMap = false;
  private prevCam = false;
  private attached = false;

  private onDown = (e: KeyboardEvent) => {
    if (e.repeat) {
      if (GAME_CODES.has(e.code)) e.preventDefault();
      return;
    }
    this.keys.add(e.code);
    if (GAME_CODES.has(e.code)) e.preventDefault();
  };
  private onUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };
  private onBlur = () => {
    this.keys.clear();
  };

  attach() {
    if (this.attached) return;
    this.attached = true;
    window.addEventListener("keydown", this.onDown);
    window.addEventListener("keyup", this.onUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
  }

  detach() {
    if (!this.attached) return;
    this.attached = false;
    window.removeEventListener("keydown", this.onDown);
    window.removeEventListener("keyup", this.onUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.keys.clear();
  }

  setKeys(codes: string[]) {
    this.qaKeys = codes.length ? codes : null;
    if (!codes.length) this.qaSteer = null;
  }

  poll() {
    if (this.blocked) {
      this.steer = 0;
      this.throttle = 0;
      this.brake = 0;
      this.handbrake = false;
      this.interact = false;
      this.interactPressed = false;
      this.horn = false;
      this.hornPressed = false;
      this.pausePressed = false;
      this.mapPressed = false;
      this.cameraPressed = false;
      this.prevInteract = false;
      this.prevHorn = false;
      this.prevPause = false;
      this.prevMap = false;
      this.prevCam = false;
      return;
    }

    const k = this.qaKeys ? new Set(this.qaKeys) : this.keys;
    let steer = 0;
    if (k.has("KeyA") || k.has("ArrowLeft")) steer += 1;
    if (k.has("KeyD") || k.has("ArrowRight")) steer -= 1;
    steer += this.steerTouch;

    let throttle = k.has("KeyW") || k.has("ArrowUp") ? 1 : 0;
    let brake = k.has("KeyS") || k.has("ArrowDown") ? 1 : 0;
    throttle = Math.max(throttle, this.throttleTouch);
    brake = Math.max(brake, this.brakeTouch);

    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : [];
    if (pads) {
      for (const p of pads) {
        if (!p || p.mapping !== "standard") continue;
        const st = radialDeadzone(p.axes[0] ?? 0, p.axes[1] ?? 0);
        steer += -st.x;
        const trigR = p.buttons[7]?.value ?? 0;
        const trigL = p.buttons[6]?.value ?? 0;
        if (trigR > 0.05) throttle = Math.max(throttle, trigR);
        if (trigL > 0.05) brake = Math.max(brake, trigL);
        if (st.y < -0.3) throttle = Math.max(throttle, -st.y);
        if (st.y > 0.3) brake = Math.max(brake, st.y);
        if (p.buttons[0]?.pressed) this.handbrakeTouch = true;
        if (p.buttons[2]?.pressed) this.interactTouch = true;
        if (p.buttons[1]?.pressed) this.hornTouch = true;
        if (p.buttons[9]?.pressed) this.pauseTouch = true;
      }
    }

    this.steer = this.qaSteer ?? clamp(steer, -1, 1);
    this.throttle = clamp(throttle, 0, 1);
    this.brake = clamp(brake, 0, 1);
    this.handbrake = k.has("Space") || k.has("ShiftLeft") || this.handbrakeTouch;

    const inter = k.has("KeyE") || this.interactTouch;
    this.interactPressed = inter && !this.prevInteract;
    this.interact = inter;
    this.prevInteract = inter;

    const horn = k.has("KeyH") || this.hornTouch;
    this.hornPressed = horn && !this.prevHorn;
    this.horn = horn;
    this.prevHorn = horn;

    const pause = k.has("Escape") || k.has("KeyP") || this.pauseTouch;
    this.pausePressed = pause && !this.prevPause;
    this.prevPause = pause;
    this.pauseTouch = false;

    const map = k.has("KeyM") || this.mapTouch;
    this.mapPressed = map && !this.prevMap;
    this.prevMap = map;
    this.mapTouch = false;

    const cam = k.has("KeyV");
    this.cameraPressed = cam && !this.prevCam;
    this.prevCam = cam;

    this.interactTouch = false;
    this.hornTouch = false;
  }
}

export const input = new InputManager();
