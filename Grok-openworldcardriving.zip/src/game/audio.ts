function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  engineGain: GainNode | null = null;
  osc: OscillatorNode | null = null;
  osc2: OscillatorNode | null = null;
  osc3: OscillatorNode | null = null;
  filter: BiquadFilterNode | null = null;
  noise: AudioBufferSourceNode | null = null;
  noiseGain: GainNode | null = null;
  wind: GainNode | null = null;
  screech: GainNode | null = null;
  muted = false;
  private started = false;
  private lastPop = 0;
  private prevThrottle = 0;

  unlock() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    this.ctx = new AC({ latencyHint: "interactive" });
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.92;
    this.master.connect(this.ctx.destination);
    this.sfx = this.ctx.createGain();
    this.sfx.gain.value = 0.95;
    this.sfx.connect(this.master);
    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0;
    this.engineGain.connect(this.master);
    this.startEngineGraph();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") void this.ctx?.resume();
    });
  }

  private startEngineGraph() {
    if (!this.ctx || !this.engineGain) return;
    const ctx = this.ctx;
    this.osc = ctx.createOscillator();
    this.osc.type = "sawtooth";
    this.osc.frequency.value = 46;
    this.osc2 = ctx.createOscillator();
    this.osc2.type = "square";
    this.osc2.frequency.value = 23;
    this.osc3 = ctx.createOscillator();
    this.osc3.type = "triangle";
    this.osc3.frequency.value = 58;
    const g2 = ctx.createGain();
    g2.gain.value = 0.28;
    const g3 = ctx.createGain();
    g3.gain.value = 0.16;
    this.filter = ctx.createBiquadFilter();
    this.filter.type = "lowpass";
    this.filter.frequency.value = 380;
    this.filter.Q.value = 1.35;
    this.osc.connect(this.filter);
    this.osc2.connect(g2);
    g2.connect(this.filter);
    this.osc3.connect(g3);
    g3.connect(this.filter);
    this.filter.connect(this.engineGain);

    const nbuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const data = nbuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this.noise = ctx.createBufferSource();
    this.noise.buffer = nbuf;
    this.noise.loop = true;
    this.noiseGain = ctx.createGain();
    this.noiseGain.gain.value = 0.05;
    const nfilt = ctx.createBiquadFilter();
    nfilt.type = "bandpass";
    nfilt.frequency.value = 180;
    nfilt.Q.value = 0.55;
    this.noise.connect(nfilt);
    nfilt.connect(this.noiseGain);
    this.noiseGain.connect(this.engineGain);

    this.wind = ctx.createGain();
    this.wind.gain.value = 0;
    const wfilt = ctx.createBiquadFilter();
    wfilt.type = "highpass";
    wfilt.frequency.value = 720;
    this.noise.connect(wfilt);
    wfilt.connect(this.wind);
    this.wind.connect(this.master!);

    this.screech = ctx.createGain();
    this.screech.gain.value = 0;
    const sfilt = ctx.createBiquadFilter();
    sfilt.type = "bandpass";
    sfilt.frequency.value = 1280;
    sfilt.Q.value = 3.4;
    this.noise.connect(sfilt);
    sfilt.connect(this.screech);
    this.screech.connect(this.sfx!);

    this.osc.start();
    this.osc2.start();
    this.osc3.start();
    this.noise.start();
    this.started = true;
  }

  setMuted(v: boolean) {
    this.muted = v;
    if (this.master) this.master.gain.setTargetAtTime(v ? 0 : 0.92, this.now(), 0.04);
  }

  private now() {
    return this.ctx?.currentTime ?? 0;
  }

  update(opts: {
    rpm: number;
    throttle: number;
    speed: number;
    drifting: boolean;
    roar: number;
    ev: boolean;
    paused: boolean;
  }) {
    if (!this.ctx || !this.started || !this.engineGain || !this.filter) return;
    const t = this.now();
    if (opts.paused) {
      this.engineGain.gain.setTargetAtTime(0, t, 0.08);
      this.screech?.gain.setTargetAtTime(0, t, 0.05);
      this.wind?.gain.setTargetAtTime(0, t, 0.08);
      return;
    }
    const rpm = opts.rpm;
    const base = opts.ev ? 26 : 38;
    const f = base + rpm * (opts.ev ? 0.011 : 0.042) * opts.roar;
    this.osc?.frequency.setTargetAtTime(f, t, 0.035);
    this.osc2?.frequency.setTargetAtTime(f * 0.48 + 6, t, 0.045);
    this.osc3?.frequency.setTargetAtTime(f * 1.48, t, 0.05);
    this.filter.frequency.setTargetAtTime(
      (opts.ev ? 540 : 240) + opts.throttle * 1900 + rpm * 0.4,
      t,
      0.045,
    );
    const vol =
      (opts.ev ? 0.04 : 0.16) +
      opts.throttle * (opts.ev ? 0.09 : 0.48) * opts.roar +
      Math.min(0.16, Math.abs(opts.speed) * 0.0024);
    this.engineGain.gain.setTargetAtTime(vol, t, 0.05);
    this.noiseGain?.gain.setTargetAtTime(0.07 + opts.throttle * 0.18 * opts.roar, t, 0.07);
    this.wind?.gain.setTargetAtTime(Math.min(0.16, Math.abs(opts.speed) * 0.0024), t, 0.1);
    this.screech?.gain.setTargetAtTime(opts.drifting ? 0.16 + opts.throttle * 0.08 : 0, t, 0.05);

    if (
      !opts.ev &&
      this.prevThrottle > 0.7 &&
      opts.throttle < 0.2 &&
      rpm > 3400 &&
      t - this.lastPop > 0.22
    ) {
      this.lastPop = t;
      this.pop();
      if (opts.roar > 1.2) window.setTimeout(() => this.pop(), 40);
    }
    this.prevThrottle = opts.throttle;
  }

  pop() {
    if (!this.ctx || !this.sfx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = "square";
    o.frequency.value = 70 + Math.random() * 55;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.26, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + 0.15);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }

  horn() {
    if (!this.ctx || !this.sfx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    for (const f of [348, 438]) {
      const o = ctx.createOscillator();
      o.type = "square";
      o.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.11, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
      o.connect(g);
      g.connect(this.sfx);
      o.start(t);
      o.stop(t + 0.44);
    }
  }

  impact(strength: number) {
    if (!this.ctx || !this.sfx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(110, t);
    o.frequency.exponentialRampToValueAtTime(36, t + 0.2);
    const g = ctx.createGain();
    const v = clamp(0.05 + strength * 0.05, 0.05, 0.2);
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + 0.24);
  }

  blip(freq = 880, dur = 0.12) {
    if (!this.ctx || !this.sfx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = "triangle";
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.08, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  cash() {
    this.blip(720, 0.08);
    window.setTimeout(() => this.blip(980, 0.1), 80);
  }

  splash() {
    this.blip(220, 0.18);
  }

  chime() {
    this.blip(880, 0.1);
    window.setTimeout(() => this.blip(1320, 0.14), 90);
  }

  bark() {
    this.blip(180, 0.08);
    window.setTimeout(() => this.blip(140, 0.12), 70);
  }

  cheer() {
    this.blip(640, 0.07);
    window.setTimeout(() => this.blip(860, 0.09), 60);
    window.setTimeout(() => this.blip(1100, 0.1), 130);
  }
}
