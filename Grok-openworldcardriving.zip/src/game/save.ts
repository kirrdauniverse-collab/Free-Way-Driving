import { SAVE_KEY, SAVE_VERSION } from "./data";
import type { SaveData } from "./types";

export const defaultSave = (): SaveData => ({
  version: SAVE_VERSION,
  money: 1800,
  owned: ["csibe"],
  currentCar: "csibe",
  upgrades: { csibe: { engine: 0, tires: 0, brakes: 0, turbo: 0 } },
  stars: {},
  foundSecret: false,
  statueHonks: 0,
  fishCaught: 0,
  jobsDone: 0,
  iceCreams: 0,
  viewsFound: [],
  champion: false,
});

function migrate(raw: SaveData): SaveData {
  const base = defaultSave();
  return {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    owned: raw.owned?.length ? raw.owned : base.owned,
    upgrades: { ...base.upgrades, ...raw.upgrades },
    stars: { ...raw.stars },
    viewsFound: Array.isArray(raw.viewsFound) ? raw.viewsFound : [],
    iceCreams: raw.iceCreams ?? 0,
    champion: Boolean(raw.champion),
  };
}

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(SAVE_KEY) ?? localStorage.getItem("horizont-save-v1");
    if (!raw) return defaultSave();
    const parsed = JSON.parse(raw) as SaveData;
    if (!parsed || typeof parsed !== "object") return defaultSave();
    return migrate(parsed);
  } catch {
    return defaultSave();
  }
}

export function writeSave(data: SaveData) {
  try {
    const payload = JSON.stringify({ ...data, version: SAVE_VERSION });
    localStorage.setItem(SAVE_KEY, payload);
    localStorage.setItem(SAVE_KEY + ":bak", payload);
  } catch {
    /* private mode / quota */
  }
}

export function hasSave(): boolean {
  try {
    return Boolean(localStorage.getItem(SAVE_KEY) || localStorage.getItem("horizont-save-v1"));
  } catch {
    return false;
  }
}

export function resetSave(): SaveData {
  const fresh = defaultSave();
  writeSave(fresh);
  return fresh;
}
