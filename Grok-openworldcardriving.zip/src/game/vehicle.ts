import * as THREE from "three";
import type { CarBody, CarDef } from "./types";

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export type CarStats = CarDef & { turbo: number };

export type VehicleHit = {
  impact: number;
  landed: number;
  drifting: boolean;
  boostPop: boolean;
};

const _fwd = new THREE.Vector3();

export class Vehicle {
  x = 18;
  y = 0.5;
  z = 48;
  yaw = 0;
  vx = 0;
  vz = 0;
  vy = 0;
  speed = 0;
  steerAngle = 0;
  airborne = false;
  drifting = false;
  driftCharge = 0;
  boostT = 0;
  rpm = 900;
  gear = 1;
  wheelSpin = 0;
  airTime = 0;
  jumpPeak = 0;
  smoothnessAcc = 0;
  lastImpact = 0;
  braking = false;
  squash = 1;

  reset(x: number, z: number, yaw = 0) {
    this.x = x;
    this.z = z;
    this.y = 0.5;
    this.yaw = yaw;
    this.vx = this.vz = this.vy = 0;
    this.speed = 0;
    this.airborne = false;
    this.driftCharge = 0;
    this.boostT = 0;
    this.airTime = 0;
    this.squash = 1;
  }

  forward(out = _fwd) {
    out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    return out;
  }

  step(
    dt: number,
    steer: number,
    throttle: number,
    brake: number,
    handbrake: boolean,
    stats: CarStats,
    groundY: number,
    surfaceMul: number,
    offroad: boolean,
  ): VehicleHit {
    const hit: VehicleHit = {
      impact: 0,
      landed: 0,
      drifting: false,
      boostPop: false,
    };

    this.braking = brake > 0.15 && Math.abs(this.speed) > 1;
    const maxSpd =
      stats.maxSpeed *
      (this.boostT > 0 ? 1.12 + stats.turbo * 0.04 : 1) *
      surfaceMul;
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);

    if (!this.airborne) {
      this.vx += fx * stats.accel * throttle * dt * (offroad ? 0.72 : 1);
      this.vz += fz * stats.accel * throttle * dt * (offroad ? 0.72 : 1);
      if (brake > 0.05) {
        const sp = Math.hypot(this.vx, this.vz);
        if (sp > 1.2) {
          const k = stats.brake * brake * dt;
          this.vx -= (this.vx / sp) * k;
          this.vz -= (this.vz / sp) * k;
        } else {
          this.vx -= fx * stats.accel * 0.42 * brake * dt;
          this.vz -= fz * stats.accel * 0.42 * brake * dt;
        }
      }
    }

    let fwd = this.vx * fx + this.vz * fz;
    let lat = this.vx * rx + this.vz * rz;
    const absFwd = Math.abs(fwd);
    const speedFactor =
      clamp(absFwd / 7, 0, 1) * (1 - 0.42 * clamp(absFwd / Math.max(8, maxSpd), 0, 1));
    const reverse = fwd >= 0 ? 1 : -1;
    this.yaw += steer * stats.turn * speedFactor * reverse * dt;
    this.steerAngle += (steer * 0.42 - this.steerAngle) * (1 - Math.exp(-12 * dt));

    const wantDrift =
      (handbrake && absFwd > 8 && Math.abs(steer) > 0.2) ||
      (Math.abs(lat) > 4.2 && absFwd > 12 && Math.abs(steer) > 0.35);
    const wasDrift = this.drifting;
    this.drifting = wantDrift && !this.airborne;
    hit.drifting = this.drifting;

    const gripK = this.drifting ? stats.grip * 0.38 : stats.grip * (offroad ? 0.55 : 1);
    lat *= Math.exp(-gripK * dt);
    if (this.drifting) {
      lat += -steer * fwd * 0.55 * dt;
      this.driftCharge = clamp(this.driftCharge + dt * (0.55 + Math.abs(steer) * 0.5), 0, 1);
    } else if (wasDrift && this.driftCharge > 0.35) {
      this.boostT = 0.9 + this.driftCharge * 0.5;
      this.driftCharge = 0;
      hit.boostPop = true;
    } else {
      this.driftCharge = Math.max(0, this.driftCharge - dt * 0.8);
    }

    const drag = (offroad ? 1.15 : 0.32) + (throttle < 0.05 ? 0.55 : 0) + (handbrake ? 1.1 : 0);
    fwd *= Math.exp(-drag * dt);
    if (this.boostT > 0) {
      fwd += stats.accel * 0.55 * dt;
      this.boostT = Math.max(0, this.boostT - dt);
    }
    fwd = clamp(fwd, -maxSpd * 0.32, maxSpd);

    this.vx = fx * fwd + rx * lat;
    this.vz = fz * fwd + rz * lat;
    this.speed = fwd;
    this.x += this.vx * dt;
    this.z += this.vz * dt;
    if (!Number.isFinite(this.x) || !Number.isFinite(this.z)) {
      this.reset(18, 52, 0);
      return hit;
    }

    const ride = 0.42;
    const g = groundY + ride;
    if (this.y > g + 0.28 || this.vy > 0.8) {
      this.airborne = true;
      this.vy -= 26 * dt;
      this.y += this.vy * dt;
      this.airTime += dt;
      this.jumpPeak = Math.max(this.jumpPeak, this.y - g);
      this.squash = clamp(1 + Math.abs(this.vy) * 0.012, 0.92, 1.12);
      if (this.y <= g) {
        hit.landed = Math.max(0, -this.vy);
        this.y = g;
        this.vy = 0;
        this.airborne = false;
        this.squash = clamp(1 - hit.landed * 0.018, 0.78, 1);
        if (hit.landed > 8) {
          this.vx *= 0.82;
          this.vz *= 0.82;
        }
      }
    } else {
      this.airborne = false;
      this.vy = 0;
      this.y += (g - this.y) * (1 - Math.exp(-18 * dt));
      this.airTime = 0;
      this.jumpPeak = 0;
      this.squash += (1 - this.squash) * (1 - Math.exp(-10 * dt));
    }

    const kmh = Math.abs(this.speed) * 3.6;
    const gearTop = [0, 18, 32, 48, 70, 100, 160, 260];
    let gIdx = 1;
    while (gIdx < 6 && kmh > gearTop[gIdx + 1]!) gIdx++;
    this.gear = gIdx;
    const g0 = gearTop[gIdx]!;
    const g1 = gearTop[gIdx + 1]!;
    const t = clamp((kmh - g0) / Math.max(1, g1 - g0), 0, 1);
    this.rpm = 900 + t * 5200 + throttle * 400;
    this.wheelSpin += (this.speed / 0.32) * dt;

    this.smoothnessAcc += (Math.abs(lat) * 0.04 + (handbrake ? 0.3 : 0)) * dt;
    return hit;
  }

  applyCollision(nx: number, nz: number, depth: number) {
    this.x += nx * depth;
    this.z += nz * depth;
    const vn = this.vx * nx + this.vz * nz;
    if (vn < 0) {
      this.vx -= vn * nx * 1.55;
      this.vz -= vn * nz * 1.55;
      this.lastImpact = -vn;
      return -vn;
    }
    this.lastImpact = 0;
    return 0;
  }
}

function mat(color: string, extra?: THREE.MeshStandardMaterialParameters) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.38,
    metalness: 0.42,
    ...extra,
  });
}

type CarUser = {
  wheels: THREE.Group[];
  tails: THREE.MeshStandardMaterial[];
  width: number;
  length: number;
};

export function buildCarMesh(def: CarDef, opts?: { lights?: boolean }): THREE.Group {
  const g = new THREE.Group();
  g.name = "car";
  const shiny = def.body === "super" || def.body === "coupe" || def.body === "ev" || def.body === "cabrio";
  const bodyMat = mat(def.color, {
    roughness: shiny ? 0.22 : def.body === "van" || def.body === "pickup" ? 0.55 : 0.34,
    metalness: shiny ? 0.62 : 0.38,
  });
  const accent = mat(def.accent, { roughness: 0.46, metalness: 0.35 });
  const glass = mat(def.glass, {
    roughness: 0.08,
    metalness: 0.55,
    transparent: true,
    opacity: 0.62,
  });
  const dark = mat("#141518", { roughness: 0.72, metalness: 0.15 });
  const chrome = mat("#c8ccd2", { roughness: 0.16, metalness: 0.88 });
  const lightMat = new THREE.MeshStandardMaterial({
    color: "#f7f1d4",
    emissive: "#f2e4a8",
    emissiveIntensity: 1.1,
    roughness: 0.28,
  });
  const tailMat = new THREE.MeshStandardMaterial({
    color: "#e24a3b",
    emissive: "#c02820",
    emissiveIntensity: 0.45,
    roughness: 0.38,
  });
  const tailMat2 = tailMat.clone();

  const style = def.body;
  let w = 1.72,
    h = 0.5,
    len = 4.1;
  if (style === "hatch") {
    w = 1.64;
    h = 0.48;
    len = 3.62;
  }
  if (style === "van") {
    w = 1.88;
    h = 0.88;
    len = 4.7;
  }
  if (style === "pickup") {
    w = 1.82;
    h = 0.52;
    len = 4.55;
  }
  if (style === "coupe" || style === "super") {
    w = 1.82;
    h = 0.38;
    len = 4.28;
  }
  if (style === "muscle") {
    w = 1.9;
    h = 0.46;
    len = 4.55;
  }
  if (style === "ev") {
    w = 1.84;
    h = 0.38;
    len = 4.22;
  }
  if (style === "estate") {
    w = 1.78;
    h = 0.52;
    len = 4.55;
  }
  if (style === "moto") {
    w = 0.72;
    h = 0.42;
    len = 2.15;
  }
  if (style === "bus") {
    w = 2.35;
    h = 1.35;
    len = 8.4;
  }
  if (style === "truck") {
    w = 2.2;
    h = 0.7;
    len = 8.8;
  }
  if (style === "suv") {
    w = 1.92;
    h = 0.72;
    len = 4.45;
  }
  if (style === "cabrio") {
    w = 1.78;
    h = 0.36;
    len = 4.15;
  }

  const add = (mesh: THREE.Mesh | THREE.Group) => {
    if (mesh instanceof THREE.Mesh) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
    g.add(mesh);
    return mesh;
  };

  const box = (
    bw: number,
    bh: number,
    bd: number,
    m: THREE.Material,
    x: number,
    y: number,
    z: number,
  ) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), m);
    mesh.position.set(x, y, z);
    add(mesh);
    return mesh;
  };

  const chassisY = 0.34;
  box(w * 0.92, 0.16, len * 0.92, dark, 0, chassisY, 0);

  if (style === "van") {
    box(w, h, len * 0.55, bodyMat, 0, chassisY + 0.18 + h / 2, 0.55);
    box(w * 0.96, 1.12, 2.55, accent, 0, 1.18, 0.62);
    const cab = box(w * 0.9, 0.72, 1.15, glass, 0, 1.08, -1.42);
    cab.rotation.x = -0.08;
    box(w * 0.98, 0.22, 0.9, bodyMat, 0, chassisY + 0.28, -1.85);
  } else if (style === "pickup") {
    box(w, h, len * 0.62, bodyMat, 0, chassisY + 0.12 + h / 2, -0.35);
    box(w * 0.9, 0.68, 1.28, glass, 0, 0.98, -0.52);
    box(w * 0.92, 0.22, 1.72, dark, 0, 0.58, 1.22);
    box(w * 0.08, 0.38, 1.7, accent, -w * 0.42, 0.72, 1.22);
    box(w * 0.08, 0.38, 1.7, accent, w * 0.42, 0.72, 1.22);
    box(w * 0.9, 0.08, 0.08, accent, 0, 0.9, 2.05);
  } else if (style === "moto") {
    box(0.22, 0.28, 1.55, dark, 0, 0.42, 0);
    box(0.38, 0.18, 0.55, bodyMat, 0, 0.62, -0.15);
    box(0.32, 0.12, 0.4, accent, 0, 0.55, 0.55);
    box(0.28, 0.2, 0.7, bodyMat, 0, 0.72, -0.05);
    box(0.42, 0.08, 0.28, dark, 0, 0.92, 0.12);
    const rider = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.16, 0.32, 3, 6),
      mat("#3d5c7a", { roughness: 0.75, metalness: 0.1 }),
    );
    rider.position.set(0, 1.05, 0.05);
    rider.rotation.x = 0.35;
    add(rider);
    const helm = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), accent);
    helm.position.set(0, 1.38, -0.12);
    add(helm);
  } else if (style === "bus") {
    box(w, 1.55, len * 0.96, bodyMat, 0, 1.15, 0);
    box(w * 0.92, 0.85, len * 0.72, glass, 0, 1.55, 0.15);
    box(w * 0.7, 0.7, 0.9, glass, 0, 1.45, -len * 0.42);
    box(w * 0.98, 0.18, len * 0.98, accent, 0, 0.52, 0);
    box(0.18, 0.9, 0.06, dark, w * 0.48, 1.05, -0.8);
    box(0.18, 0.9, 0.06, dark, w * 0.48, 1.05, 1.4);
  } else if (style === "truck") {
    box(w * 0.92, 0.85, 2.2, bodyMat, 0, 1.05, -2.8);
    box(w * 0.82, 0.7, 1.15, glass, 0, 1.55, -2.95);
    box(w * 0.96, 1.7, 5.4, accent, 0, 1.45, 1.15);
    box(w * 0.7, 0.22, 0.7, dark, 0, 0.48, -2.2);
  } else if (style === "suv") {
    box(w, h, len * 0.78, bodyMat, 0, chassisY + 0.12 + h / 2, 0.05);
    box(w * 0.86, 0.62, 1.55, glass, 0, chassisY + h + 0.42, -0.05);
    box(w * 0.9, 0.08, 1.7, dark, 0, chassisY + h + 0.78, -0.02);
    box(0.08, 0.12, len * 0.55, chrome, -w * 0.48, chassisY + h + 0.72, 0);
    box(0.08, 0.12, len * 0.55, chrome, w * 0.48, chassisY + h + 0.72, 0);
    box(w * 0.92, 0.18, 0.55, dark, 0, chassisY + 0.28, len * 0.32);
  } else if (style === "cabrio") {
    box(w, h, len * 0.76, bodyMat, 0, chassisY + 0.1 + h / 2, 0);
    const cabHood = box(w * 0.9, h * 0.7, 1.05, bodyMat, 0, chassisY + 0.08 + h * 0.38, -len * 0.28);
    cabHood.rotation.x = 0.06;
    box(w * 0.82, 0.28, 0.12, glass, 0, chassisY + h + 0.32, -0.55);
    box(0.28, 0.12, 0.38, dark, -0.32, chassisY + h + 0.18, 0.12);
    box(0.28, 0.12, 0.38, dark, 0.32, chassisY + h + 0.18, 0.12);
    const driver = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.16, 0.28, 3, 6),
      mat("#3d5c7a", { roughness: 0.75, metalness: 0.1 }),
    );
    driver.position.set(-0.28, 0.95, 0.05);
    add(driver);
  } else {
    const bodyH = h;
    const bodyZ = style === "hatch" ? 0.08 : 0;
    box(w, bodyH, len * 0.78, bodyMat, 0, chassisY + 0.1 + bodyH / 2, bodyZ);
    const hoodLen = style === "muscle" ? 1.35 : style === "super" ? 1.2 : 1.05;
    const hood = box(
      w * 0.92,
      bodyH * 0.72,
      hoodLen,
      bodyMat,
      0,
      chassisY + 0.08 + bodyH * 0.4,
      -len * 0.28,
    );
    hood.rotation.x = style === "super" || style === "coupe" ? 0.08 : 0.04;
    const cabinL = style === "hatch" ? 1.28 : style === "sedan" || style === "estate" ? 1.5 : 1.62;
    const cabin = box(
      w * 0.82,
      0.52,
      cabinL,
      glass,
      0,
      chassisY + bodyH + 0.38,
      style === "hatch" ? 0.12 : -0.08,
    );
    cabin.rotation.x = -0.12;
    box(w * 0.78, 0.06, cabinL * 0.92, dark, 0, chassisY + bodyH + 0.64, cabin.position.z);
    if (style === "sedan" || style === "hatch") {
      box(w * 0.94, bodyH * 0.62, 0.78, bodyMat, 0, chassisY + 0.08 + bodyH * 0.32, len * 0.32);
    }
    if (style === "estate") {
      box(w * 0.9, 0.62, 1.35, bodyMat, 0, chassisY + bodyH * 0.55, len * 0.28);
      box(w * 0.78, 0.45, 1.1, glass, 0, chassisY + bodyH + 0.28, len * 0.22);
    }
  }

  if (style === "super" || style === "coupe" || style === "ev") {
    const spoiler = box(w * 0.88, 0.05, 0.28, accent, 0, 0.92, len * 0.42);
    spoiler.rotation.x = 0.12;
    box(0.05, 0.2, 0.05, accent, -0.58, 0.84, len * 0.4);
    box(0.05, 0.2, 0.05, accent, 0.58, 0.84, len * 0.4);
    box(w * 0.96, 0.08, len * 0.7, dark, 0, chassisY + 0.02, 0.1);
  }
  if (style === "muscle") {
    box(0.55, 0.1, 0.72, dark, 0, chassisY + h + 0.18, -0.85);
    box(0.22, 0.08, 0.4, chrome, 0, chassisY + h + 0.26, -0.85);
  }

  box(w * 0.96, 0.2, 0.22, dark, 0, 0.28, -len / 2 + 0.04);
  box(w * 0.96, 0.2, 0.22, dark, 0, 0.28, len / 2 - 0.04);
  box(w * 0.42, 0.16, 0.06, chrome, 0, 0.38, -len / 2 - 0.02);
  box(0.32, 0.13, 0.08, lightMat, -w * 0.32, 0.44, -len / 2 - 0.03);
  box(0.32, 0.13, 0.08, lightMat, w * 0.32, 0.44, -len / 2 - 0.03);
  const tl = box(0.3, 0.1, 0.07, tailMat, -w * 0.32, 0.44, len / 2 + 0.03);
  const tr = box(0.3, 0.1, 0.07, tailMat2, w * 0.32, 0.44, len / 2 + 0.03);
  void tl;
  void tr;

  const coneGeo = new THREE.ConeGeometry(0.22, 1.6, 8);
  coneGeo.rotateX(-Math.PI / 2);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xf2e6b0,
    transparent: true,
    opacity: 0.14,
    depthWrite: false,
  });
  const coneL = new THREE.Mesh(coneGeo, coneMat);
  coneL.position.set(-w * 0.32, 0.44, -len / 2 - 0.85);
  const coneR = coneL.clone();
  coneR.position.x = w * 0.32;
  add(coneL);
  add(coneR);

  if (opts?.lights !== false) {
    const spotL = new THREE.SpotLight(0xfff1d0, 5.5, 34, 0.4, 0.55, 1.15);
    spotL.position.set(-w * 0.32, 0.5, -len / 2 - 0.1);
    spotL.target.position.set(-w * 0.28, 0.05, -len / 2 - 14);
    const spotR = new THREE.SpotLight(0xfff1d0, 5.5, 34, 0.4, 0.55, 1.15);
    spotR.position.set(w * 0.32, 0.5, -len / 2 - 0.1);
    spotR.target.position.set(w * 0.28, 0.05, -len / 2 - 14);
    g.add(spotL, spotL.target, spotR, spotR.target);
  }

  box(0.08, 0.08, 0.22, chrome, -w * 0.48, 0.82, -0.35);
  box(0.08, 0.08, 0.22, chrome, w * 0.48, 0.82, -0.35);
  box(0.28, 0.18, 0.04, chrome, 0, 0.78, -0.2);
  box(0.42, 0.12, 0.04, dark, 0, 0.32, len / 2 + 0.04);
  box(0.38, 0.1, 0.02, chrome, 0, 0.32, len / 2 + 0.055);

  if (style !== "ev") {
    box(0.1, 0.08, 0.28, chrome, -0.42, 0.22, len / 2 - 0.15);
    box(0.1, 0.08, 0.28, chrome, 0.42, 0.22, len / 2 - 0.15);
  }

  const wheelGeo = new THREE.CylinderGeometry(
    style === "moto" ? 0.36 : 0.33,
    style === "moto" ? 0.36 : 0.33,
    style === "moto" ? 0.16 : 0.24,
    14,
  );
  wheelGeo.rotateZ(Math.PI / 2);
  const tire = mat("#1a1a1a", { roughness: 0.92, metalness: 0.04 });
  const wheels: THREE.Group[] = [];
  const wx = w * 0.5 - 0.04;
  let positions: [number, number, number][] = [
    [-wx, 0.33, -len * 0.32],
    [wx, 0.33, -len * 0.32],
    [-wx, 0.33, len * 0.32],
    [wx, 0.33, len * 0.32],
  ];
  if (style === "moto") {
    positions = [
      [0, 0.36, -0.72],
      [0, 0.36, 0.78],
    ];
  } else if (style === "bus" || style === "truck") {
    positions = [
      [-wx, 0.38, -len * 0.38],
      [wx, 0.38, -len * 0.38],
      [-wx, 0.38, 0.15],
      [wx, 0.38, 0.15],
      [-wx, 0.38, len * 0.38],
      [wx, 0.38, len * 0.38],
    ];
  }
  for (const p of positions) {
    const wh = new THREE.Group();
    wh.add(new THREE.Mesh(wheelGeo, tire));
    const rimM = new THREE.Mesh(
      new THREE.CylinderGeometry(0.19, 0.19, 0.26, 12).rotateZ(Math.PI / 2),
      chrome,
    );
    wh.add(rimM);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.28, 8).rotateZ(Math.PI / 2), dark);
    wh.add(hub);
    wh.position.set(p[0], p[1], p[2]);
    g.add(wh);
    wheels.push(wh);
  }

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(1.45, 18),
    new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.3,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.03;
  g.add(shadow);

  (g as THREE.Group & { userData: CarUser }).userData = {
    wheels,
    tails: [tailMat, tailMat2],
    width: w,
    length: len,
  };
  return g;
}

export function setCarPose(mesh: THREE.Group, v: Vehicle, dt: number) {
  mesh.position.set(v.x, v.y, v.z);
  mesh.rotation.order = "YXZ";
  mesh.rotation.y = v.yaw;
  const bank = -v.steerAngle * 0.2;
  mesh.rotation.z += (bank - mesh.rotation.z) * (1 - Math.exp(-8 * dt));
  mesh.rotation.x = v.airborne ? clamp(v.vy * 0.02, -0.25, 0.2) : mesh.rotation.x * 0.9;
  const sy = v.squash;
  mesh.scale.set(2 - sy, sy, 2 - sy);
  const wheels = mesh.userData.wheels as THREE.Group[] | undefined;
  if (wheels) {
    for (let i = 0; i < wheels.length; i++) {
      const w = wheels[i]!;
      w.rotation.x = v.wheelSpin;
      if (i < 2) w.rotation.y = v.steerAngle;
      else w.rotation.y = 0;
    }
  }
  const tails = mesh.userData.tails as THREE.MeshStandardMaterial[] | undefined;
  if (tails) {
    const em = v.braking ? 1.6 : 0.4;
    for (const t of tails) t.emissiveIntensity = em;
  }
}

export type CarBodyKind = CarBody;
