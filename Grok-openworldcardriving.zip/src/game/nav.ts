export type RoadLike = { ax: number; az: number; bx: number; bz: number; width: number };

export type NavPt = { x: number; z: number };

const STEP = 38;
const LINK = 42;

export class NavGraph {
  pts: NavPt[] = [];
  adj: number[][] = [];

  constructor(roads: RoadLike[]) {
    const raw: NavPt[] = [];
    for (const r of roads) {
      const dx = r.bx - r.ax;
      const dz = r.bz - r.az;
      const len = Math.hypot(dx, dz) || 1;
      const n = Math.max(1, Math.round(len / STEP));
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        raw.push({ x: r.ax + dx * t, z: r.az + dz * t });
      }
    }
    const pts: NavPt[] = [];
    for (const p of raw) {
      if (pts.some((q) => Math.hypot(q.x - p.x, q.z - p.z) < 14)) continue;
      pts.push(p);
    }
    this.pts = pts;
    const n = pts.length;
    this.adj = Array.from({ length: n }, () => []);
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const d = Math.hypot(pts[i]!.x - pts[j]!.x, pts[i]!.z - pts[j]!.z);
        if (d < LINK) {
          this.adj[i]!.push(j);
          this.adj[j]!.push(i);
        }
      }
    }
  }

  nearest(x: number, z: number) {
    let best = 0;
    let bd = 1e9;
    for (let i = 0; i < this.pts.length; i++) {
      const d = Math.hypot(this.pts[i]!.x - x, this.pts[i]!.z - z);
      if (d < bd) {
        bd = d;
        best = i;
      }
    }
    return best;
  }

  path(ax: number, az: number, bx: number, bz: number): NavPt[] {
    const n = this.pts.length;
    if (!n) return [{ x: bx, z: bz }];
    const s = this.nearest(ax, az);
    const g = this.nearest(bx, bz);
    if (s === g) return [{ x: bx, z: bz }];
    const dist = new Float32Array(n).fill(1e9);
    const prev = new Int32Array(n).fill(-1);
    const used = new Uint8Array(n);
    dist[s] = 0;
    for (let k = 0; k < n; k++) {
      let u = -1;
      let best = 1e9;
      for (let i = 0; i < n; i++) {
        if (!used[i] && dist[i]! < best) {
          best = dist[i]!;
          u = i;
        }
      }
      if (u < 0 || u === g) break;
      used[u] = 1;
      for (const v of this.adj[u]!) {
        const d =
          dist[u]! +
          Math.hypot(this.pts[u]!.x - this.pts[v]!.x, this.pts[u]!.z - this.pts[v]!.z);
        if (d < dist[v]!) {
          dist[v] = d;
          prev[v] = u;
        }
      }
    }
    if (prev[g] < 0 && s !== g) {
      return [
        { x: ax, z: az },
        { x: bx, z: bz },
      ];
    }
    const chain: NavPt[] = [{ x: bx, z: bz }];
    let cur = g;
    const guard = n + 2;
    let hops = 0;
    while (cur !== s && hops++ < guard) {
      chain.push(this.pts[cur]!);
      cur = prev[cur]!;
      if (cur < 0) break;
    }
    chain.push({ x: ax, z: az });
    chain.reverse();
    return chain;
  }
}

export function densify(path: NavPt[], spacing = 9): NavPt[] {
  const out: NavPt[] = [];
  for (let i = 0; i < path.length - 1; i++) {
    const a = path[i]!;
    const b = path[i + 1]!;
    const len = Math.hypot(b.x - a.x, b.z - a.z) || 1;
    const n = Math.max(1, Math.round(len / spacing));
    for (let k = 0; k < n; k++) {
      const t = k / n;
      out.push({ x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t });
    }
  }
  if (path.length) out.push(path[path.length - 1]!);
  return out;
}
