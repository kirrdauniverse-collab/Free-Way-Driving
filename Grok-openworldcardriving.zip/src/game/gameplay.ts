import {
  AIRPORT,
  CAR_BY_ID,
  CHALLENGE_META,
  CIRCUIT_GATES,
  COURIER_STOPS,
  JOB_META,
  PARTY_GUESTS,
  PASSENGERS,
  POI_BY_ID,
  POIS,
  SECRET_CARGO,
  TAXI_STOPS,
  VIEWPOINTS,
} from "./data";
import { useGame } from "./store";
import type { ChallengeId, JobId, JobState } from "./types";
import type { Vehicle } from "./vehicle";

function dist(ax: number, az: number, bx: number, bz: number) {
  return Math.hypot(ax - bx, az - bz);
}

function pick<T>(arr: T[], except?: T): T {
  const pool = except === undefined ? arr : arr.filter((x) => x !== except);
  return pool[Math.floor(Math.random() * pool.length)] ?? arr[0]!;
}

export function nearestPoi(x: number, z: number, max = 11) {
  let best = null as (typeof POIS)[number] | null;
  let bestD = max;
  for (const p of POIS) {
    const d = dist(x, z, p.x, p.z);
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  return best;
}

export function startJob(id: JobId, v: Vehicle) {
  const st = useGame.getState();
  if (st.job) {
    st.toastMsg("Előbb fejezd be a mostani fuvart.");
    return;
  }
  const meta = JOB_META[id];
  if (id === "taxi") {
    const dest = pick(TAXI_STOPS);
    const pax = pick(PASSENGERS);
    st.setJob({
      id,
      step: 0,
      title: meta.name,
      detail: `${pax.name} → ${dest.name}`,
      pay: 340 + Math.round(dist(v.x, v.z, dest.x, dest.z) * 0.95),
      targetX: dest.x,
      targetZ: dest.z,
      smoothness: 0,
      samples: 0,
      hits: 0,
      passenger: pax.name,
      passengerKind: pax.kind,
      jumpCheers: 0,
    });
    st.setWaypoint({ x: dest.x, z: dest.z, label: dest.name });
    st.toastMsg(`${pax.name} beszállt. ${pax.line}`);
  }
  if (id === "courier") {
    const dest = pick(COURIER_STOPS);
    st.setJob({
      id,
      step: 0,
      title: meta.name,
      detail: `Csomag célja: ${dest.name}`,
      pay: 400 + Math.round(dist(v.x, v.z, dest.x, dest.z) * 1.08),
      targetX: dest.x,
      targetZ: dest.z,
      smoothness: 0,
      samples: 0,
      hits: 0,
    });
    st.setWaypoint({ x: dest.x, z: dest.z, label: dest.name });
    st.toastMsg("Csomag a raktérben. Hajrá!");
  }
  if (id === "grandma") {
    const market = POI_BY_ID.market!;
    st.setJob({
      id,
      step: 0,
      title: meta.name,
      detail: "Szedd össze a bevásárlást a piacon.",
      pay: 520,
      targetX: market.x,
      targetZ: market.z,
      smoothness: 0,
      samples: 0,
      hits: 0,
    });
    st.setWaypoint({ x: market.x, z: market.z, label: "Piac" });
    st.toastMsg("Ilonka néni várja a szatyrokat — és a kutyája is.");
  }
  if (id === "secret") {
    const dest = pick(COURIER_STOPS);
    const cargo = pick(SECRET_CARGO);
    st.setJob({
      id,
      step: 0,
      title: meta.name,
      detail: `Cél: ${dest.name}. Ne ütközz!`,
      pay: 1200 + Math.round(Math.random() * 600),
      targetX: dest.x,
      targetZ: dest.z,
      smoothness: 0,
      samples: 0,
      hits: 0,
    });
    st.setWaypoint({ x: dest.x, z: dest.z, label: dest.name });
    st.toastMsg(cargo);
  }
  if (id === "party") {
    const market = POI_BY_ID.market!;
    st.setJob({
      id,
      step: 0,
      title: meta.name,
      detail: "Szedd a díszeket a piacon.",
      pay: 780,
      targetX: market.x,
      targetZ: market.z,
      smoothness: 0,
      samples: 0,
      hits: 0,
    });
    st.setWaypoint({ x: market.x, z: market.z, label: "Piac — díszek" });
    st.toastMsg("Buli lesz a főtéren. Először a díszek!");
  }
}

export function tickJob(v: Vehicle, impact: number, dt: number) {
  const st = useGame.getState();
  const job = st.job;
  if (!job) return;
  job.samples += dt;
  job.smoothness += (Math.abs(v.speed) > 1 ? Math.abs(v.vx) * 0.02 + Math.abs(impact) : 0) * dt;
  if (impact > 4) job.hits += 1;
  if (job.passengerKind === "kid" && v.airborne && v.airTime > 0.35) {
    job.jumpCheers = (job.jumpCheers ?? 0) + dt;
  }
  const d = dist(v.x, v.z, job.targetX, job.targetZ);
  if (d < 10 && Math.abs(v.speed) < 4) {
    if (job.id === "grandma" && job.step === 0) {
      const home = POI_BY_ID.grandma!;
      st.setJob({
        ...job,
        step: 1,
        detail: "Vidd haza a szatyrokat Ilonka néninek.",
        targetX: home.x,
        targetZ: home.z,
      });
      st.setWaypoint({ x: home.x, z: home.z, label: "Ilonka néni" });
      st.toastMsg("Bevásárlás kész. Irány a néni!");
      return;
    }
    if (job.id === "party" && job.step === 0) {
      const taxi = POI_BY_ID.taxi!;
      st.setJob({
        ...job,
        step: 1,
        detail: "A vendégek a taxiállomáson várnak.",
        targetX: taxi.x,
        targetZ: taxi.z,
      });
      st.setWaypoint({ x: taxi.x, z: taxi.z, label: "Vendégek" });
      st.toastMsg("Díszek a csomagtartóban. Most a vendégek!");
      return;
    }
    if (job.id === "party" && job.step === 1) {
      const plaza = POI_BY_ID.party!;
      const guest = pick(PARTY_GUESTS);
      st.setJob({
        ...job,
        step: 2,
        detail: `${guest.name} a főtérre. ${guest.line}`,
        targetX: plaza.x,
        targetZ: plaza.z,
        passenger: guest.name,
        passengerKind: "kind" in guest ? guest.kind : "adult",
      });
      st.setWaypoint({ x: plaza.x, z: plaza.z, label: "Főtér" });
      st.toastMsg(`${guest.name} beszállt. ${guest.line}`);
      return;
    }
    finishJob(v);
  }
}

function finishJob(v: Vehicle) {
  const st = useGame.getState();
  const job = st.job;
  if (!job) return;
  const car = CAR_BY_ID[st.currentCar];
  let pay = job.pay;
  if (job.id === "courier" && (car.body === "van" || car.body === "truck")) pay = Math.round(pay * 1.2);
  if (job.id === "taxi") {
    const rough = job.smoothness / Math.max(1, job.samples);
    if (rough < 1.8 && job.hits === 0) {
      const tip = Math.round(pay * 0.5);
      pay += tip;
      const who = job.passenger ?? "Az utas";
      st.toastMsg(`„Micsoda vezetés!” ${who} +${tip} Ft borravalót ad.`);
    } else if (job.hits === 0) {
      st.toastMsg("Szép út, kellemes utas.");
    } else {
      pay = Math.round(pay * 0.75);
      st.toastMsg("Kicsit rázós volt… kevesebb a borravaló.");
    }
    if ((job.jumpCheers ?? 0) > 0.4 && job.passengerKind === "kid") {
      pay += 180;
      st.toastMsg("„Még egyet a dombon!” A gyerek ujjong. +180 Ft");
    }
    if (car.id === "taxika" || car.body === "bus") pay = Math.round(pay * 1.15);
  }
  if (job.id === "secret") {
    if (job.hits === 0) {
      pay = Math.round(pay * 1.18);
      st.toastMsg("A csomag épségben. A megbízó elégedett.");
    } else {
      pay = Math.round(pay * 0.6);
      st.toastMsg("Túl rázós volt a szállítmány. Kevesebb a díj.");
    }
  }
  if (job.id === "grandma") {
    st.toastMsg("Ilonka néni süteménnyel fizetett. Na jó, és készpénzzel is.");
  }
  if (job.id === "party") {
    st.toastMsg("A tér megtelt. A zene szól, a fagyi is megérkezett.");
  }
  st.addMoney(pay);
  st.bumpStat("jobsDone");
  st.setJob(null);
  st.setWaypoint(null);
  st.toastMsg(`+${pay.toLocaleString("hu-HU")} Ft`);
  void v;
}

export function startChallenge(id: ChallengeId, v: Vehicle) {
  const st = useGame.getState();
  if (st.challenge?.active) {
    st.toastMsg("Előbb fejezd be a kihívást — vagy menj tovább, lejár magától.");
    return;
  }
  if (st.job) {
    st.toastMsg("Fuvar közben a kihívás várhat.");
    return;
  }
  const meta = CHALLENGE_META[id];
  const base = {
    id,
    title: meta.name,
    active: true,
    done: false,
    t: 0,
    value: 0,
    detail: meta.desc,
  };
  if (id === "drift") {
    st.setChallenge({ ...base, t: 35, detail: "Driftelj 35 mp-ig a gyárban!" });
  }
  if (id === "accel") {
    v.vx = v.vz = v.speed = 0;
    v.x = AIRPORT.x;
    v.z = AIRPORT.z + 62;
    v.yaw = 0;
    st.setChallenge({
      ...base,
      detail: "Állj a piros vonalra… Gázt! Cél: 100 km/h",
    });
  }
  if (id === "topspeed") {
    st.setChallenge({
      ...base,
      t: 25,
      detail: "25 mp a kifutón — maxold a tempót!",
    });
  }
  if (id === "jump") {
    st.setChallenge({
      ...base,
      t: 40,
      detail: "40 mp, gyűjts levegőben töltött időt!",
    });
  }
  if (id === "circuit") {
    st.setChallenge({
      ...base,
      value: 0,
      detail: `Kapu 1/${CIRCUIT_GATES.length}`,
    });
    const g = CIRCUIT_GATES[0]!;
    st.setWaypoint({ x: g.x, z: g.z, label: "Kapu 1" });
  }
  st.toastMsg(meta.name + " indul!");
}

export function tickChallenge(v: Vehicle, drifting: boolean, dt: number) {
  const st = useGame.getState();
  const c = st.challenge;
  if (!c || !c.active) return;
  c.t += dt;
  if (c.id === "drift") {
    if (drifting) c.value += (8 + Math.abs(v.speed) * 0.4) * dt;
    const left = 35 - c.t;
    c.detail = `Drift: ${Math.round(c.value)} · ${Math.max(0, left).toFixed(1)} mp`;
    if (left <= 0) completeChallenge(c.id, c.value, [80, 160, 260]);
  }
  if (c.id === "accel") {
    const kmh = Math.abs(v.speed) * 3.6;
    c.detail = `${kmh.toFixed(0)} km/h · ${c.t.toFixed(2)} mp`;
    if (kmh >= 100) completeChallenge(c.id, c.t, [4.8, 3.6, 2.7], true);
    if (c.t > 12) completeChallenge(c.id, 12, [4.8, 3.6, 2.7], true);
  }
  if (c.id === "topspeed") {
    const kmh = Math.abs(v.speed) * 3.6;
    c.value = Math.max(c.value, kmh);
    c.detail = `Csúcs: ${c.value.toFixed(0)} km/h · ${Math.max(0, 25 - c.t).toFixed(0)} mp`;
    if (c.t >= 25) completeChallenge(c.id, c.value, [140, 180, 230]);
  }
  if (c.id === "jump") {
    if (v.airborne) c.value += dt;
    c.detail = `Levegő: ${c.value.toFixed(1)} mp · ${Math.max(0, 40 - c.t).toFixed(0)} mp`;
    if (c.t >= 40) completeChallenge(c.id, c.value, [1.2, 2.4, 3.6]);
  }
  if (c.id === "circuit") {
    const i = Math.floor(c.value);
    const g = CIRCUIT_GATES[i];
    if (g && dist(v.x, v.z, g.x, g.z) < 12) {
      c.value += 1;
      const n = CIRCUIT_GATES[Math.floor(c.value)];
      if (n) {
        st.setWaypoint({ x: n.x, z: n.z, label: `Kapu ${Math.floor(c.value) + 1}` });
        c.detail = `Kapu ${Math.floor(c.value) + 1}/${CIRCUIT_GATES.length} · ${c.t.toFixed(1)} mp`;
      } else completeChallenge(c.id, c.t, [95, 70, 50], true);
    } else c.detail = `Kapu ${i + 1}/${CIRCUIT_GATES.length} · ${c.t.toFixed(1)} mp`;
  }
  st.setChallenge({ ...c });
}

function completeChallenge(id: ChallengeId, value: number, thresholds: number[], lowerIsBetter = false) {
  let stars = 0;
  if (lowerIsBetter) {
    if (value <= thresholds[0]!) stars = 1;
    if (value <= thresholds[1]!) stars = 2;
    if (value <= thresholds[2]!) stars = 3;
  } else {
    if (value >= thresholds[0]!) stars = 1;
    if (value >= thresholds[1]!) stars = 2;
    if (value >= thresholds[2]!) stars = 3;
  }
  const pay = [0, 420, 780, 1400][stars] ?? 0;
  const st = useGame.getState();
  st.setStars(id, stars);
  if (pay) st.addMoney(pay);
  st.setChallenge(null);
  st.setWaypoint(null);
  const starTxt = stars ? `${stars} csillag` : "Ezúttal nem jött össze";
  st.toastMsg(`${CHALLENGE_META[id].name}: ${starTxt}${pay ? ` · +${pay} Ft` : ""}`);
  if (Object.keys(CHALLENGE_META).every((k) => (st.stars[k as ChallengeId] ?? 0) >= 3) && !st.champion) {
    st.setChampion();
    st.toastMsg("Bajnok! Minden kihívás 3 csillag. +8000 Ft a kasszába.");
  }
}

export function tryInteract(v: Vehicle, poi: (typeof POIS)[number] | null, fishingOk: boolean) {
  const st = useGame.getState();
  if (st.job && dist(v.x, v.z, st.job.targetX, st.job.targetZ) < 10) return null;
  if (st.job) return null;
  if (fishingOk && Math.abs(v.speed) < 1.2) return "fishing";
  if (!poi) return null;
  if (poi.id === "garage") return "garage";
  if (poi.id === "dealer") return "dealer";
  if (poi.id === "fagyi") return "fagyi";
  if (poi.id === "hidden" && !st.foundSecret && Math.abs(v.speed) < 4) return "hidden";
  if (poi.id === "taxi") startJob("taxi", v);
  if (poi.id === "courier") startJob("courier", v);
  if (poi.id === "market") startJob("grandma", v);
  if (poi.id === "secret") startJob("secret", v);
  if (poi.id === "party") startJob("party", v);
  if (poi.id === "drift") startChallenge("drift", v);
  if (poi.id === "accel") startChallenge("accel", v);
  if (poi.id === "topspeed") startChallenge("topspeed", v);
  if (poi.id === "jump") startChallenge("jump", v);
  if (poi.id === "circuit") startChallenge("circuit", v);
  return null;
}

export function promptFor(
  poi: (typeof POIS)[number] | null,
  fishingOk: boolean,
  parked: boolean,
  _job: JobState,
) {
  if (fishingOk && parked) return "Pecázás  ·  E";
  if (!poi) return null;
  switch (poi.id) {
    case "garage":
      return "Műhely  ·  E";
    case "dealer":
      return "Kereskedés  ·  E";
    case "taxi":
      return "Taxi fuvar  ·  E";
    case "courier":
      return "Futárkodás  ·  E";
    case "market":
      return "Bevásárlás néninek  ·  E";
    case "secret":
      return "Titkos futár  ·  E";
    case "party":
      return "Buli szervezés  ·  E";
    case "drift":
      return "Gyári drift  ·  E";
    case "accel":
      return "Reptéri gyorsulás  ·  E";
    case "topspeed":
      return "Végsebesség  ·  E";
    case "jump":
      return "Ugrató kihívás  ·  E";
    case "circuit":
      return "Városi időfutam  ·  E";
    case "hidden":
      return useGame.getState().foundSecret ? null : "Valami csillog  ·  E";
    case "statue":
      return "Dudálj háromszor";
    case "fishing":
      return parked ? "Pecázás  ·  E" : "Állj meg a stégen";
    case "fagyi":
      return parked ? "Fagyi  ·  E" : "Állj meg a fagyisnál";
    default:
      return poi.hint;
  }
}

export function tryViewpoint(x: number, z: number, parked: boolean) {
  if (!parked) return null;
  for (const v of VIEWPOINTS) if (dist(x, z, v.x, v.z) < 16) return v.id;
  return null;
}

export function viewName(id: string) {
  return VIEWPOINTS.find((v) => v.id === id)?.name ?? id;
}
