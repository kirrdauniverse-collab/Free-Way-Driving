import { create } from "zustand";
import { CAR_BY_ID } from "./data";
import { loadSave, resetSave, writeSave } from "./save";
import type {
  CarId,
  ChallengeId,
  ChallengeState,
  JobState,
  SaveData,
  Screen,
  UpgradeKind,
  Waypoint,
} from "./types";

export type Toast = { id: number; text: string } | null;

export type GameStore = SaveData & {
  screen: Screen;
  ready: boolean;
  loadProgress: number;
  speedKmh: number;
  rpm: number;
  gear: number;
  biomeLabel: string;
  prompt: string | null;
  toast: Toast;
  job: JobState;
  challenge: ChallengeState;
  waypoint: Waypoint | null;
  hoodCam: boolean;
  minimap: string | null;
  fishResult: string | null;
  posX: number;
  posZ: number;
  heading: number;
  wayRel: number | null;
  wayDist: number | null;
  drifting: boolean;
  setScreen: (s: Screen) => void;
  setReady: (v: boolean) => void;
  setProgress: (v: number) => void;
  setTelemetry: (t: {
    speedKmh: number;
    rpm: number;
    gear: number;
    biomeLabel: string;
    prompt: string | null;
    minimap?: string | null;
    posX?: number;
    posZ?: number;
    heading?: number;
    wayRel?: number | null;
    wayDist?: number | null;
    drifting?: boolean;
  }) => void;
  setJob: (j: JobState) => void;
  setChallenge: (c: ChallengeState) => void;
  setWaypoint: (w: Waypoint | null) => void;
  setHood: (v: boolean) => void;
  addMoney: (n: number) => void;
  setStars: (id: ChallengeId, n: number) => void;
  ownCar: (id: CarId) => void;
  selectCar: (id: CarId) => void;
  bumpUpgrade: (car: CarId, kind: UpgradeKind) => boolean;
  sellCar: (id: CarId) => boolean;
  toastMsg: (text: string) => void;
  persist: () => void;
  applySave: (s: SaveData) => void;
  newGame: () => void;
  bumpStat: (k: "statueHonks" | "fishCaught" | "jobsDone" | "iceCreams", n?: number) => void;
  setFishResult: (s: string | null) => void;
  markView: (id: string) => boolean;
  markSecret: () => void;
  setChampion: () => void;
};

let toastSeq = 1;

function snapshot(s: GameStore): SaveData {
  return {
    version: 2,
    money: s.money,
    owned: s.owned,
    currentCar: s.currentCar,
    upgrades: s.upgrades,
    stars: s.stars,
    foundSecret: s.foundSecret,
    statueHonks: s.statueHonks,
    fishCaught: s.fishCaught,
    jobsDone: s.jobsDone,
    iceCreams: s.iceCreams,
    viewsFound: s.viewsFound,
    champion: s.champion,
  };
}

export const useGame = create<GameStore>((set, get) => ({
  ...loadSave(),
  screen: "loading",
  ready: false,
  loadProgress: 0,
  speedKmh: 0,
  rpm: 800,
  gear: 1,
  biomeLabel: "Város",
  prompt: null,
  toast: null,
  job: null,
  challenge: null,
  waypoint: null,
  hoodCam: false,
  minimap: null,
  fishResult: null,
  posX: 18,
  posZ: 52,
  heading: 0,
  wayRel: null,
  wayDist: null,
  drifting: false,

  setScreen: (screen) => set({ screen }),
  setReady: (ready) => set({ ready }),
  setProgress: (loadProgress) => set({ loadProgress }),
  setTelemetry: (t) =>
    set({
      speedKmh: t.speedKmh,
      rpm: t.rpm,
      gear: t.gear,
      biomeLabel: t.biomeLabel,
      prompt: t.prompt,
      minimap: t.minimap === undefined ? get().minimap : t.minimap,
      posX: t.posX ?? get().posX,
      posZ: t.posZ ?? get().posZ,
      heading: t.heading ?? get().heading,
      wayRel: t.wayRel === undefined ? get().wayRel : t.wayRel,
      wayDist: t.wayDist === undefined ? get().wayDist : t.wayDist,
      drifting: t.drifting ?? get().drifting,
    }),
  setJob: (job) => set({ job }),
  setChallenge: (challenge) => set({ challenge }),
  setWaypoint: (waypoint) => set({ waypoint }),
  setHood: (hoodCam) => set({ hoodCam }),
  addMoney: (n) => {
    set({ money: Math.max(0, Math.round(get().money + n)) });
    get().persist();
  },
  setStars: (id, n) => {
    const cur = get().stars[id] ?? 0;
    if (n <= cur) return;
    set({ stars: { ...get().stars, [id]: n } });
    get().persist();
  },
  ownCar: (id) => {
    if (get().owned.includes(id)) return;
    const car = CAR_BY_ID[id];
    set({
      owned: [...get().owned, id],
      upgrades: {
        ...get().upgrades,
        [id]: get().upgrades[id] ?? {
          engine: 0,
          tires: 0,
          brakes: 0,
          turbo: 0,
        },
      },
      currentCar: id,
      money: get().money - (car.secret ? 0 : car.price),
    });
    get().persist();
  },
  selectCar: (id) => {
    if (!get().owned.includes(id)) return;
    set({ currentCar: id });
    get().persist();
  },
  bumpUpgrade: (car, kind) => {
    const u = get().upgrades[car] ?? {
      engine: 0,
      tires: 0,
      brakes: 0,
      turbo: 0,
    };
    const lvl = u[kind] ?? 0;
    if (lvl >= 3) return false;
    const cost = [900, 2100, 4800][lvl] ?? 99999;
    if (get().money < cost) return false;
    set({
      money: get().money - cost,
      upgrades: {
        ...get().upgrades,
        [car]: { ...u, [kind]: lvl + 1 },
      },
    });
    get().persist();
    return true;
  },
  sellCar: (id) => {
    const s = get();
    if (!s.owned.includes(id) || s.owned.length < 2) return false;
    const car = CAR_BY_ID[id];
    const refund = Math.round((car.price || 1800) * 0.7);
    const owned = s.owned.filter((c) => c !== id);
    set({
      owned,
      currentCar: s.currentCar === id ? owned[0]! : s.currentCar,
      money: s.money + refund,
    });
    get().persist();
    get().toastMsg(`${car.name} eladva · +${refund.toLocaleString("hu-HU")} Ft`);
    return true;
  },
  toastMsg: (text) => {
    const id = toastSeq++;
    set({ toast: { id, text } });
    window.setTimeout(() => {
      if (get().toast?.id === id) set({ toast: null });
    }, 3000);
  },
  persist: () => {
    writeSave(snapshot(get()));
  },
  applySave: (save) => set({ ...save }),
  newGame: () => {
    const fresh = resetSave();
    set({
      ...fresh,
      job: null,
      challenge: null,
      waypoint: null,
      fishResult: null,
    });
  },
  bumpStat: (k, n = 1) => {
    set({ [k]: get()[k] + n } as Partial<GameStore>);
    get().persist();
  },
  setFishResult: (fishResult) => set({ fishResult }),
  markView: (id) => {
    const found = get().viewsFound;
    if (found.includes(id)) return false;
    const next = [...found, id];
    set({ viewsFound: next });
    get().persist();
    return true;
  },
  markSecret: () => {
    if (get().foundSecret) return;
    set({ foundSecret: true });
    get().persist();
  },
  setChampion: () => {
    if (get().champion) return;
    set({ champion: true, money: get().money + 8000 });
    get().persist();
  },
}));

export function effectiveStats(carId: CarId) {
  const def = CAR_BY_ID[carId];
  const u = useGame.getState().upgrades[carId] ?? {};
  const e = u.engine ?? 0;
  const t = u.tires ?? 0;
  const b = u.brakes ?? 0;
  const tu = u.turbo ?? 0;
  return {
    ...def,
    maxSpeed: def.maxSpeed * (1 + 0.1 * e + 0.04 * tu),
    accel: def.accel * (1 + 0.12 * e + 0.1 * tu),
    brake: def.brake * (1 + 0.14 * b + 0.05 * t),
    grip: def.grip * (1 + 0.1 * t),
    turn: def.turn * (1 + 0.06 * t),
    turbo: tu,
  };
}

