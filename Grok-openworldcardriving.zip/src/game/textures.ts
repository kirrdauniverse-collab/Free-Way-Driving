import * as THREE from "three";

function makeCanvas(size: number) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  return { c, ctx };
}

function noiseFill(
  ctx: CanvasRenderingContext2D,
  size: number,
  base: [number, number, number],
  amp: number,
) {
  const img = ctx.createImageData(size, size);
  const d = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n =
        (((x * 13 + y * 31) % 17) / 17) * 0.35 +
        (((x * 7 + y * 17) % 11) / 11) * 0.25 +
        Math.random() * 0.4;
      const i = (y * size + x) * 4;
      d[i] = base[0] + (n - 0.5) * amp;
      d[i + 1] = base[1] + (n - 0.5) * amp;
      d[i + 2] = base[2] + (n - 0.5) * amp;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}

export function asphaltTexture() {
  const { c, ctx } = makeCanvas(256);
  noiseFill(ctx, 256, [38, 40, 44], 16);
  ctx.strokeStyle = "rgba(220,220,210,0.28)";
  ctx.lineWidth = 4;
  ctx.setLineDash([22, 18]);
  ctx.beginPath();
  ctx.moveTo(128, 0);
  ctx.lineTo(128, 256);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.strokeStyle = "rgba(200,160,60,0.45)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(18, 0);
  ctx.lineTo(18, 256);
  ctx.moveTo(238, 0);
  ctx.lineTo(238, 256);
  ctx.stroke();
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function groundNoiseTexture() {
  const { c, ctx } = makeCanvas(128);
  noiseFill(ctx, 128, [236, 234, 228], 18);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function facadeTexture() {
  const { c, ctx } = makeCanvas(256);
  ctx.fillStyle = "#f4f1ea";
  ctx.fillRect(0, 0, 256, 256);
  ctx.fillStyle = "#d9d3c8";
  ctx.fillRect(0, 168, 256, 88);
  for (let y = 12; y < 160; y += 32) {
    for (let x = 14; x < 246; x += 28) {
      const lit = ((x * 3 + y * 5) % 17) > 7;
      ctx.fillStyle = "#8a8176";
      ctx.fillRect(x - 2, y - 2, 18, 22);
      ctx.fillStyle = lit ? "#f3e2b0" : "#2a3340";
      ctx.fillRect(x, y, 14, 18);
    }
  }
  for (let x = 18; x < 240; x += 36) {
    ctx.fillStyle = "#6a8ea3";
    ctx.fillRect(x, 186, 22, 36);
    ctx.fillStyle = "#3a4048";
    ctx.fillRect(x + 6, 222, 10, 28);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.repeat.set(1, 2);
  return tex;
}

export function waterTexture() {
  const { c, ctx } = makeCanvas(256);
  const g = ctx.createLinearGradient(0, 0, 256, 256);
  g.addColorStop(0, "#1e5870");
  g.addColorStop(1, "#2a6d82");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = "rgba(190,230,235,0.22)";
  ctx.lineWidth = 2;
  for (let i = 0; i < 20; i++) {
    ctx.beginPath();
    const y = 8 + i * 13;
    ctx.moveTo(0, y);
    for (let x = 0; x <= 256; x += 12) {
      ctx.lineTo(x, y + Math.sin(x * 0.05 + i * 0.7) * 5);
    }
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function houseFacadeTexture() {
  const { c, ctx } = makeCanvas(128);
  ctx.fillStyle = "#c8b49a";
  ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = "#6a8aa0";
  ctx.fillRect(18, 28, 28, 32);
  ctx.fillRect(82, 28, 28, 32);
  ctx.fillStyle = "#5a3a30";
  ctx.fillRect(52, 58, 24, 50);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function poiLabelTexture(text: string, color: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.clearRect(0, 0, 256, 64);
  ctx.fillStyle = "rgba(9,10,12,0.82)";
  roundRect(ctx, 4, 8, 248, 48, 12);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  roundRect(ctx, 4, 8, 248, 48, 12);
  ctx.stroke();
  ctx.fillStyle = "#f1f2f4";
  ctx.font = "600 22px Barlow, Segoe UI, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 128, 34);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function shopFacadeTexture() {
  const { c, ctx } = makeCanvas(256);
  ctx.fillStyle = "#f7f3ea";
  ctx.fillRect(0, 0, 256, 256);
  ctx.fillStyle = "#efe6d4";
  ctx.fillRect(0, 0, 256, 70);
  const awnings = ["#c45c3a", "#3d5c7a", "#5a6b3a", "#e8b86d"];
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = awnings[i % awnings.length]!;
    ctx.fillRect(8 + i * 62, 62, 54, 18);
    ctx.fillStyle = "#b9d4e2";
    ctx.fillRect(12 + i * 62, 88, 46, 58);
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.fillRect(16 + i * 62, 92, 10, 48);
    ctx.fillStyle = "#2a2c30";
    ctx.fillRect(22 + i * 62, 156, 26, 78);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

export function brickFacadeTexture() {
  const { c, ctx } = makeCanvas(256);
  ctx.fillStyle = "#f3e4d8";
  ctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 16) {
    const off = (y / 16) % 2 === 0 ? 0 : 16;
    for (let x = -16; x < 256; x += 32) {
      ctx.fillStyle = ((x + y) * 13) % 17 > 8 ? "#fff6ee" : "#e7cbb8";
      ctx.fillRect(x + off + 1, y + 1, 28, 13);
    }
  }
  for (let y = 28; y < 230; y += 40) {
    for (let x = 18; x < 240; x += 44) {
      ctx.fillStyle = "#c8b49a";
      ctx.fillRect(x - 3, y - 3, 24, 30);
      ctx.fillStyle = ((x * 3 + y) % 11) > 5 ? "#f6e7b8" : "#314050";
      ctx.fillRect(x, y, 18, 24);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

export function glassFacadeTexture() {
  const { c, ctx } = makeCanvas(256);
  ctx.fillStyle = "#e7eef4";
  ctx.fillRect(0, 0, 256, 256);
  for (let y = 6; y < 250; y += 20) {
    ctx.fillStyle = "#c5d0da";
    ctx.fillRect(0, y, 256, 3);
    for (let x = 6; x < 250; x += 18) {
      const lit = ((x * 7 + y * 13) % 11) > 6;
      ctx.fillStyle = "#b7c6d2";
      ctx.fillRect(x, y + 3, 2, 16);
      ctx.fillStyle = lit ? "#f7f1dc" : "#8eafc4";
      ctx.fillRect(x + 2, y + 4, 12, 14);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

export function shopSignTexture(label: string, bg: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 96;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 256, 96);
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  ctx.fillRect(0, 0, 256, 10);
  ctx.fillStyle = "#f7f4ee";
  ctx.font = "700 52px Barlow, Segoe UI, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, 128, 52);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function signTexture(kind: "stop" | "yield" | "speed" | "cross" | "noentry") {
  const { c, ctx } = makeCanvas(128);
  ctx.clearRect(0, 0, 128, 128);
  if (kind === "stop") {
    ctx.fillStyle = "#c02820";
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const a = Math.PI / 8 + (i * Math.PI) / 4;
      const x = 64 + Math.cos(a) * 54;
      const y = 64 + Math.sin(a) * 54;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#f1f2f4";
    ctx.font = "bold 28px Barlow, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("STOP", 64, 66);
  } else if (kind === "yield") {
    ctx.fillStyle = "#c02820";
    ctx.beginPath();
    ctx.moveTo(64, 118);
    ctx.lineTo(12, 18);
    ctx.lineTo(116, 18);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#f1f2f4";
    ctx.beginPath();
    ctx.moveTo(64, 100);
    ctx.lineTo(28, 30);
    ctx.lineTo(100, 30);
    ctx.closePath();
    ctx.fill();
  } else if (kind === "speed") {
    ctx.fillStyle = "#f1f2f4";
    roundRect(ctx, 22, 8, 84, 112, 12);
    ctx.fill();
    ctx.strokeStyle = "#c02820";
    ctx.lineWidth = 8;
    roundRect(ctx, 22, 8, 84, 112, 12);
    ctx.stroke();
    ctx.fillStyle = "#1a1c20";
    ctx.font = "bold 42px Barlow, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("50", 64, 64);
  } else if (kind === "cross") {
    ctx.fillStyle = "#1e4d8c";
    ctx.beginPath();
    ctx.arc(64, 64, 54, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f1f2f4";
    ctx.fillRect(56, 22, 16, 44);
    ctx.beginPath();
    ctx.arc(64, 22, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(44, 44, 40, 10);
    ctx.fillRect(50, 54, 10, 40);
    ctx.fillRect(68, 54, 10, 40);
  } else {
    ctx.fillStyle = "#c02820";
    ctx.beginPath();
    ctx.arc(64, 64, 54, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f1f2f4";
    ctx.fillRect(22, 56, 84, 16);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
