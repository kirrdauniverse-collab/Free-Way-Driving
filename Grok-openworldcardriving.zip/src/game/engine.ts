import * as THREE from "three";
import { GameAudio } from "./audio";
import { AIRPORT, CAR_BY_ID, FACTORY, PLAZA, POI_BY_ID, POIS, WORLD_HALF } from "./data";
import {
  nearestPoi,
  promptFor,
  tickChallenge,
  tickJob,
  tryInteract,
  tryViewpoint,
  viewName,
} from "./gameplay";
import { input } from "./input";
import { densify } from "./nav";
import { SkidTrail } from "./skid";
import { effectiveStats, useGame } from "./store";
import { biomeAt, biomeLabel, World } from "./world";
import { Vehicle, buildCarMesh, setCarPose } from "./vehicle";
import type { CarId } from "./types";

const FIXED = 1 / 60;

type Npc = {
  x: number;
  z: number;
  yaw: number;
  speed: number;
  path: { x: number; z: number }[];
  i: number;
  mesh: THREE.Group;
};

function lerpExp(cur: number, target: number, k: number, dt: number) {
  return cur + (target - cur) * (1 - Math.exp(-k * dt));
}

export class GameEngine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.1, 1400);
  world: World;
  vehicle = new Vehicle();
  carMesh: THREE.Group;
  audio = new GameAudio();
  npcs: Npc[] = [];
  private camPos = new THREE.Vector3(0, 18, 40);
  private camLook = new THREE.Vector3();
  private titleT = 0;
  private playing = false;
  private frozen = false;
  private disposed = false;
  private acc = 0;
  private hudT = 0;
  private statueHonk = 0;
  private statueWindow = 0;
  private trauma = 0;
  private minimap: HTMLCanvasElement;
  private dust: THREE.Points;
  private dustAges: Float32Array;
  private dustGeo: THREE.BufferGeometry;
  private beacon: THREE.Mesh;
  private lastCar: CarId;
  private hood = false;
  private lastTime = 0;
  private sun: THREE.DirectionalLight;
  private skid: SkidTrail;
  private passenger: THREE.Group;
  private cargo: THREE.Mesh;
  private dogHonk = 0;
  private wasWater = false;
  private walkers: {
    x: number;
    z: number;
    yaw: number;
    t: number;
    speed: number;
    path: { x: number; z: number }[];
    pi: number;
    mesh: THREE.Group;
    lArm: THREE.Object3D;
    rArm: THREE.Object3D;
    lLeg: THREE.Object3D;
    rLeg: THREE.Object3D;
  }[] = [];
  private gpsMarks: THREE.InstancedMesh;
  private gpsDummy = new THREE.Object3D();
  private lastWpKey = "";
  private gpsOriginX = 1e9;
  private gpsOriginZ = 1e9;
  private gpsPts: { x: number; z: number }[] = [];
  private baseMap: ImageData | null = null;
  private tmpA = new THREE.Vector3();
  private tmpB = new THREE.Vector3();

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    this.renderer.setClearColor(0xb8c4d4, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.scene.fog = new THREE.FogExp2(0xb8c4d4, 0.00145);

    const hemi = new THREE.HemisphereLight(0x9ec4ec, 0x3d4a38, 0.78);
    this.sun = new THREE.DirectionalLight(0xfff2d8, 1.62);
    this.sun.position.set(90, 140, 50);
    this.sun.target.position.set(0, 0, 0);
    this.scene.add(hemi, this.sun, this.sun.target, new THREE.AmbientLight(0xffffff, 0.12));
    if (typeof window !== "undefined" && window.innerWidth >= 720) {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFShadowMap;
      this.sun.castShadow = true;
      this.sun.shadow.mapSize.set(1024, 1024);
      this.sun.shadow.camera.near = 8;
      this.sun.shadow.camera.far = 200;
      this.sun.shadow.camera.left = -46;
      this.sun.shadow.camera.right = 46;
      this.sun.shadow.camera.top = 46;
      this.sun.shadow.camera.bottom = -46;
      this.sun.shadow.bias = -0.0007;
    }

    useGame.getState().setProgress(0.2);
    this.world = new World();
    this.scene.add(this.world.group);
    useGame.getState().setProgress(0.7);

    this.lastCar = useGame.getState().currentCar;
    this.carMesh = buildCarMesh(CAR_BY_ID[this.lastCar], { lights: this.useCarLights() });
    this.scene.add(this.carMesh);
    this.vehicle.reset(18, 52, 0);
    this.passenger = makePassenger();
    this.carMesh.add(this.passenger);
    this.cargo = makeCargo();
    this.carMesh.add(this.cargo);
    this.skid = new SkidTrail(this.scene);
    this.spawnWalkers();

    this.beacon = new THREE.Mesh(
      new THREE.ConeGeometry(1.1, 3.2, 5),
      new THREE.MeshStandardMaterial({
        color: "#e8eaee",
        emissive: "#dce0e6",
        emissiveIntensity: 0.6,
      }),
    );
    this.beacon.rotation.x = Math.PI;
    this.scene.add(this.beacon);

    const chevron = new THREE.ConeGeometry(0.45, 1.6, 4);
    chevron.rotateX(Math.PI / 2);
    this.gpsMarks = new THREE.InstancedMesh(
      chevron,
      new THREE.MeshBasicMaterial({ color: 0xe8eaee, transparent: true, opacity: 0.85 }),
      96,
    );
    this.gpsMarks.count = 0;
    this.gpsMarks.frustumCulled = false;
    this.scene.add(this.gpsMarks);

    this.minimap = document.createElement("canvas");
    this.minimap.width = 256;
    this.minimap.height = 256;
    this.bakeMinimapBase();
    this.spawnNpcs();
    this.dust = this.makeDust();
    this.dustGeo = this.dust.geometry as THREE.BufferGeometry;
    this.dustAges = new Float32Array(80);

    this.onResize();
    window.addEventListener("resize", this.onResize);
    input.attach();
    this.wireControlsTest();
    useGame.getState().setProgress(1);
    useGame.getState().setReady(true);
    if (useGame.getState().screen === "loading") useGame.getState().setScreen("title");
  }

  private makeDust() {
    const geo = new THREE.BufferGeometry();
    const n = 80;
    const pos = new Float32Array(n * 3);
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xc8c0b0,
      size: 0.55,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    const p = new THREE.Points(geo, mat);
    this.scene.add(p);
    return p;
  }

  private spawnNpcs() {
    const ring: { x: number; z: number }[] = [];
    for (let i = 0; i < 24; i++) {
      const t = (i / 24) * Math.PI * 2;
      ring.push({ x: Math.cos(t) * 168, z: Math.sin(t) * 182 });
    }
    const factory: { x: number; z: number }[] = [];
    for (let i = 0; i < 16; i++) {
      const t = (i / 16) * Math.PI * 2;
      factory.push({ x: FACTORY.x + Math.cos(t) * 38, z: FACTORY.z + Math.sin(t) * 26 });
    }
    const air: { x: number; z: number }[] = [
      { x: 8, z: -220 },
      { x: AIRPORT.x, z: AIRPORT.z + 70 },
      { x: AIRPORT.x, z: AIRPORT.z - 60 },
    ];
    const plaza: { x: number; z: number }[] = [];
    for (let i = 0; i < 12; i++) {
      const t = (i / 12) * Math.PI * 2;
      plaza.push({ x: Math.cos(t) * 28, z: Math.sin(t) * 28 });
    }
    const paths = [ring, ring.slice().reverse(), factory, air, plaza];
    const ids: CarId[] = ["utca", "taxika", "furgon", "busz", "kamion", "motor", "kombi", "hegy", "csibe", "pampa"];
    const paints = ["#c45c3a", "#1e4d8c", "#f2efe8", "#3a4a3c", "#8a1f1a", "#5a6b7a", "#e8b86d", "#2a2c30"];
    for (let i = 0; i < 10; i++) {
      const path = paths[i % paths.length]!;
      const def = CAR_BY_ID[ids[i % ids.length]!];
      const keep = def.body === "bus" || def.body === "truck" || def.id === "taxika";
      const mesh = buildCarMesh({ ...def, color: keep ? def.color : paints[i % paints.length]! }, { lights: false });
      mesh.scale.setScalar(def.body === "bus" || def.body === "truck" ? 0.92 : 0.95);
      this.scene.add(mesh);
      const start = path[i % path.length]!;
      this.npcs.push({
        x: start.x,
        z: start.z,
        yaw: 0,
        speed: def.body === "bus" || def.body === "truck" ? 10 : 12 + (i % 4) * 2,
        path,
        i: i % path.length,
        mesh,
      });
    }
  }

  private bakeMinimapBase() {
    const ctx = this.minimap.getContext("2d")!;
    const w = 256;
    const img = ctx.createImageData(w, w);
    for (let y = 0; y < w; y++) {
      for (let x = 0; x < w; x++) {
        const wx = (x / w) * WORLD_HALF * 2 - WORLD_HALF;
        const wz = (y / w) * WORLD_HALF * 2 - WORLD_HALF;
        const b = biomeAt(wx, wz);
        let r = 60,
          g = 70,
          bl = 60;
        if (b === "city") {
          r = 70;
          g = 74;
          bl = 80;
        }
        if (b === "forest") {
          r = 32;
          g = 68;
          bl = 40;
        }
        if (b === "desert") {
          r = 180;
          g = 148;
          bl = 88;
        }
        if (b === "country") {
          r = 92;
          g = 130;
          bl = 52;
        }
        if (b === "coast") {
          r = 170;
          g = 156;
          bl = 100;
        }
        if (this.world.onRoad(wx, wz)) {
          r = 48;
          g = 50;
          bl = 54;
        }
        if (Math.hypot(wx - this.world.lake.x, wz - this.world.lake.z) < this.world.lake.r) {
          r = 48;
          g = 110;
          bl = 140;
        }
        const i = (y * w + x) * 4;
        img.data[i] = r;
        img.data[i + 1] = g;
        img.data[i + 2] = bl;
        img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    this.baseMap = ctx.getImageData(0, 0, w, w);
  }

  private drawMinimap() {
    const ctx = this.minimap.getContext("2d")!;
    const size = 256;
    if (this.baseMap) ctx.putImageData(this.baseMap, 0, 0);
    const to = (x: number, z: number) => ({
      x: ((x + WORLD_HALF) / (WORLD_HALF * 2)) * size,
      y: ((z + WORLD_HALF) / (WORLD_HALF * 2)) * size,
    });
    if (this.gpsPts.length > 1) {
      ctx.strokeStyle = "rgba(241,242,244,0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      const a = to(this.gpsPts[0]!.x, this.gpsPts[0]!.z);
      ctx.moveTo(a.x, a.y);
      for (let i = 1; i < this.gpsPts.length; i++) {
        const p = to(this.gpsPts[i]!.x, this.gpsPts[i]!.z);
        ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
    }
    const hidden = useGame.getState().foundSecret;
    for (const p of POIS) {
      if (p.id === "hidden" && !hidden) continue;
      const pt = to(p.x, p.z);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 3.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(9,10,12,0.7)";
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    const wp = useGame.getState().waypoint;
    if (wp) {
      const p = to(wp.x, wp.z);
      ctx.fillStyle = "#f1f2f4";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 6, 0, Math.PI * 2);
      ctx.fill();
    }
    const me = to(this.vehicle.x, this.vehicle.z);
    ctx.save();
    ctx.translate(me.x, me.y);
    ctx.rotate(-this.vehicle.yaw);
    ctx.fillStyle = "#e24a3b";
    ctx.beginPath();
    ctx.moveTo(0, -8);
    ctx.lineTo(5.5, 7);
    ctx.lineTo(-5.5, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    useGame.getState().setTelemetry({
      speedKmh: Math.abs(this.vehicle.speed) * 3.6,
      rpm: this.vehicle.rpm,
      gear: this.vehicle.gear,
      biomeLabel: biomeLabel(biomeAt(this.vehicle.x, this.vehicle.z)),
      prompt: useGame.getState().prompt,
      minimap: this.minimap.toDataURL("image/png"),
    });
  }

  private rebuildGps() {
    const wp = useGame.getState().waypoint;
    const key = wp ? `${wp.x.toFixed(0)},${wp.z.toFixed(0)}` : "";
    const moved = Math.hypot(this.vehicle.x - this.gpsOriginX, this.vehicle.z - this.gpsOriginZ);
    if (key === this.lastWpKey && moved < 34) return;
    this.lastWpKey = key;
    this.gpsOriginX = this.vehicle.x;
    this.gpsOriginZ = this.vehicle.z;
    if (!wp) {
      this.gpsMarks.count = 0;
      this.gpsPts = [];
      return;
    }
    const raw = this.world.nav.path(this.vehicle.x, this.vehicle.z, wp.x, wp.z);
    this.gpsPts = densify(raw, 14);
    const n = Math.min(96, this.gpsPts.length);
    this.gpsMarks.count = n;
    for (let i = 0; i < n; i++) {
      const p = this.gpsPts[i]!;
      const nxt = this.gpsPts[Math.min(this.gpsPts.length - 1, i + 1)]!;
      const yaw = Math.atan2(nxt.x - p.x, nxt.z - p.z);
      this.gpsDummy.position.set(p.x, this.world.heightAt(p.x, p.z) + 0.35, p.z);
      this.gpsDummy.rotation.set(0, yaw, 0);
      this.gpsDummy.scale.set(1, 1, 1);
      this.gpsDummy.updateMatrix();
      this.gpsMarks.setMatrixAt(i, this.gpsDummy.matrix);
    }
    this.gpsMarks.instanceMatrix.needsUpdate = true;
  }

  private onResize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  };

  start() {
    this.lastTime = performance.now();
    this.renderer.setAnimationLoop(this.loop);
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    window.removeEventListener("resize", this.onResize);
    input.detach();
    this.renderer.dispose();
    this.scene.clear();
  }

  beginPlay() {
    this.audio.unlock();
    this.playing = true;
    this.frozen = false;
    input.blocked = false;
    this.vehicle.reset(18, 52, 0);
    this.swapCar(useGame.getState().currentCar, true);
    if (useGame.getState().foundSecret && this.world.hiddenMesh) {
      this.world.hiddenMesh.visible = false;
    }
    this.camPos.set(this.vehicle.x, this.vehicle.y + 8, this.vehicle.z + 16);
    this.camLook.set(this.vehicle.x, this.vehicle.y, this.vehicle.z);
    useGame.getState().setScreen("play");
  }

  setFrozen(v: boolean) {
    this.frozen = v;
    input.blocked = v;
  }

  swapCar(id: CarId, snap = false) {
    this.carMesh.remove(this.passenger);
    this.carMesh.remove(this.cargo);
    this.scene.remove(this.carMesh);
    this.carMesh.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        const m = o.material;
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else m.dispose();
      }
    });
    this.carMesh = buildCarMesh(CAR_BY_ID[id], { lights: this.useCarLights() });
    this.scene.add(this.carMesh);
    this.carMesh.add(this.passenger);
    this.carMesh.add(this.cargo);
    this.lastCar = id;
    if (snap) setCarPose(this.carMesh, this.vehicle, 0.016);
  }

  private useCarLights() {
    return typeof window !== "undefined" && window.innerWidth >= 900;
  }

  private loop = (time: number) => {
    if (this.disposed) return;
    let dt = (time - this.lastTime) / 1000;
    this.lastTime = time;
    if (!Number.isFinite(dt) || dt <= 0) dt = 0.016;
    dt = Math.min(dt, 0.1);
    this.acc += dt;
    let steps = 0;
    while (this.acc >= FIXED && steps < 5) {
      this.fixed(FIXED);
      this.acc -= FIXED;
      steps++;
    }
    this.visual(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private fixed(dt: number) {
    const st = useGame.getState();
    if (st.screen === "title") {
      this.titleT += dt;
      return;
    }
    input.poll();
    if (input.pausePressed && st.screen === "play") {
      st.setScreen("pause");
      this.setFrozen(true);
      return;
    }
    if (input.pausePressed && (st.screen === "pause" || st.screen === "map" || st.screen === "help")) {
      st.setScreen("play");
      this.setFrozen(false);
    }
    if (input.mapPressed && st.screen === "play") {
      st.setScreen("map");
      this.setFrozen(true);
    }
    if (input.cameraPressed) {
      this.hood = !this.hood;
      st.setHood(this.hood);
    }
    if (this.frozen || st.screen !== "play") return;

    if (st.currentCar !== this.lastCar) this.swapCar(st.currentCar);

    const stats = effectiveStats(st.currentCar);
    const onRoad = this.world.onRoad(this.vehicle.x, this.vehicle.z);
    const inWater = this.world.inWater(this.vehicle.x, this.vehicle.z);
    const offroad = !onRoad;
    let surface = 1;
    if (offroad) surface = stats.body === "pickup" || stats.body === "suv" ? 0.88 : 0.72;
    if (inWater) surface = 0.35;
    const ground = this.world.heightAt(this.vehicle.x, this.vehicle.z);
    const hit = this.vehicle.step(
      dt,
      input.steer,
      input.throttle,
      input.brake,
      input.handbrake,
      stats,
      ground,
      surface,
      offroad,
    );

    const col = this.world.collide(this.vehicle.x, this.vehicle.z, 1.15);
    let impact = hit.landed;
    if (col) {
      const imp = this.vehicle.applyCollision(col.nx, col.nz, col.depth);
      if (imp > 3) {
        impact = Math.max(impact, imp);
        this.audio.impact(imp / 12);
        this.trauma = Math.min(1, this.trauma + 0.25);
        if (st.job) st.job.hits += 1;
      }
    }
    this.npcStep(dt);

    if (hit.boostPop) this.audio.blip(520, 0.08);
    if (hit.landed > 6) {
      this.audio.impact(hit.landed / 14);
      this.trauma = Math.min(1, this.trauma + 0.2);
    }

    const poi = nearestPoi(this.vehicle.x, this.vehicle.z, 12);
    const fishingOk = this.world.nearShore(this.vehicle.x, this.vehicle.z);
    const parked = Math.abs(this.vehicle.speed) < 1.15;
    let prompt = promptFor(poi, fishingOk, parked, st.job);
    if (st.job) {
      const d = Math.hypot(this.vehicle.x - st.job.targetX, this.vehicle.z - st.job.targetZ);
      if (d < 12) prompt = "Leszállítás  ·  E";
    }
    let wayRel: number | null = null;
    let wayDist: number | null = null;
    if (st.waypoint) {
      const dx = st.waypoint.x - this.vehicle.x;
      const dz = st.waypoint.z - this.vehicle.z;
      wayDist = Math.hypot(dx, dz);
      const want = Math.atan2(-dx, -dz);
      let rel = want - this.vehicle.yaw;
      while (rel > Math.PI) rel -= Math.PI * 2;
      while (rel < -Math.PI) rel += Math.PI * 2;
      wayRel = rel;
    }
    st.setTelemetry({
      speedKmh: Math.abs(this.vehicle.speed) * 3.6,
      rpm: this.vehicle.rpm,
      gear: this.vehicle.gear,
      biomeLabel: biomeLabel(biomeAt(this.vehicle.x, this.vehicle.z)),
      prompt,
      posX: this.vehicle.x,
      posZ: this.vehicle.z,
      heading: this.vehicle.yaw,
      wayRel,
      wayDist,
      drifting: hit.drifting,
    });
    this.rebuildGps();

    if (inWater && !this.wasWater) this.audio.splash();
    this.wasWater = inWater;
    this.skid.emit(
      this.vehicle.x,
      this.vehicle.y,
      this.vehicle.z,
      this.vehicle.yaw,
      dt,
      hit.drifting,
      this.vehicle.speed,
    );

    if (parked) {
      const vid = tryViewpoint(this.vehicle.x, this.vehicle.z, true);
      if (vid && st.markView(vid)) {
        st.addMoney(140);
        st.toastMsg(`Kilátó: ${viewName(vid)}. +140 Ft`);
        this.audio.chime();
      }
    }

    this.passenger.visible = Boolean(st.job?.passenger);
    this.cargo.visible = st.job?.id === "courier" || st.job?.id === "secret" || st.job?.id === "grandma";
    if (st.foundSecret && this.world.hiddenMesh) this.world.hiddenMesh.visible = false;

    if (input.interactPressed) {
      if (st.job && Math.hypot(this.vehicle.x - st.job.targetX, this.vehicle.z - st.job.targetZ) < 12) {
        tickJob(this.vehicle, 0, 0);
      } else {
        const act = tryInteract(this.vehicle, poi, fishingOk && parked);
        if (act === "garage") {
          st.setScreen("garage");
          this.setFrozen(true);
        } else if (act === "dealer") {
          st.setScreen("dealer");
          this.setFrozen(true);
        } else if (act === "fishing") {
          st.setScreen("fishing");
          this.setFrozen(true);
        } else if (act === "fagyi") {
          if (st.money >= 60) {
            st.addMoney(-60);
            st.toastMsg("Eper-vanília. A napod jobb lett.");
          } else {
            st.toastMsg("A fagyis néni meghívott egy gombócra.");
          }
          st.bumpStat("iceCreams");
          this.audio.chime();
        } else if (act === "hidden") {
          st.ownCar("holdfeny");
          st.markSecret();
          if (this.world.hiddenMesh) this.world.hiddenMesh.visible = false;
          st.toastMsg("Megtaláltad a Holdfényt — a rejtett prototípust!");
          this.audio.cash();
        }
      }
    }

    tickJob(this.vehicle, impact, dt);
    tickChallenge(this.vehicle, hit.drifting, dt);

    if (input.hornPressed) {
      this.audio.horn();
      const statue = POI_BY_ID.statue!;
      if (Math.hypot(this.vehicle.x - statue.x, this.vehicle.z - statue.z) < 14) {
        if (this.statueWindow <= 0) this.statueHonk = 0;
        this.statueHonk += 1;
        this.statueWindow = 2.2;
        if (this.statueHonk >= 3) {
          this.statueHonk = 0;
          st.addMoney(250);
          st.bumpStat("statueHonks");
          st.toastMsg("A szobor bólogat. +250 Ft a kasszába.");
          this.audio.cash();
        }
      }
      if (Math.hypot(this.vehicle.x - 318, this.vehicle.z - 42) < 18 && this.dogHonk <= 0) {
        this.dogHonk = 8;
        this.audio.bark();
        st.toastMsg("Bodri ugat egyet, majd a labdáját hozza.");
      }
    }
    this.statueWindow = Math.max(0, this.statueWindow - dt);
    this.dogHonk = Math.max(0, this.dogHonk - dt);
    this.trauma = Math.max(0, this.trauma - dt * 1.6);

    this.audio.update({
      rpm: this.vehicle.rpm,
      throttle: input.throttle,
      speed: this.vehicle.speed,
      drifting: hit.drifting,
      roar: stats.roar,
      ev: stats.body === "ev",
      paused: false,
    });

    this.hudT += dt;
    if (this.hudT > 0.12) {
      this.hudT = 0;
      this.drawMinimap();
    }
  }

  private npcStep(dt: number) {
    for (const n of this.npcs) {
      const tgt = n.path[n.i]!;
      const dx = tgt.x - n.x;
      const dz = tgt.z - n.z;
      const d = Math.hypot(dx, dz) || 1;
      if (d < 6) n.i = (n.i + 1) % n.path.length;
      const want = Math.atan2(-dx, -dz);
      let dyaw = want - n.yaw;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      n.yaw += dyaw * Math.min(1, 3 * dt);
      n.x += -Math.sin(n.yaw) * n.speed * dt;
      n.z += -Math.cos(n.yaw) * n.speed * dt;
      const y = this.world.heightAt(n.x, n.z) + 0.42;
      n.mesh.position.set(n.x, y, n.z);
      n.mesh.rotation.y = n.yaw;
      const pdx = n.x - this.vehicle.x;
      const pdz = n.z - this.vehicle.z;
      const pd = Math.hypot(pdx, pdz);
      if (pd < 2.4) {
        const nx = pdx / (pd || 1);
        const nz = pdz / (pd || 1);
        this.vehicle.applyCollision(-nx, -nz, 2.4 - pd);
        n.x += nx * 0.8;
        n.z += nz * 0.8;
      }
    }
    this.walkerStep(dt);
  }

  private visual(dt: number) {
    const st = useGame.getState();
    setCarPose(this.carMesh, this.vehicle, dt);
    const wp = st.waypoint;
    if (wp) {
      this.beacon.visible = true;
      const y = this.world.heightAt(wp.x, wp.z) + 4 + Math.sin(performance.now() * 0.004) * 0.4;
      this.beacon.position.set(wp.x, y, wp.z);
    } else {
      this.beacon.visible = false;
    }

    const pos = this.dustGeo.getAttribute("position") as THREE.BufferAttribute;
    if (Math.abs(this.vehicle.speed) > 8 && Math.random() < 0.4) {
      for (let i = 0; i < this.dustAges.length; i++) {
        if (this.dustAges[i]! <= 0) {
          this.dustAges[i] = 0.6;
          const fx = Math.sin(this.vehicle.yaw);
          const fz = Math.cos(this.vehicle.yaw);
          pos.setXYZ(
            i,
            this.vehicle.x + fx * 1.2 + (Math.random() - 0.5),
            this.vehicle.y,
            this.vehicle.z + fz * 1.2 + (Math.random() - 0.5),
          );
          break;
        }
      }
    }
    for (let i = 0; i < this.dustAges.length; i++) {
      if (this.dustAges[i]! > 0) {
        this.dustAges[i]! -= dt;
        pos.setY(i, pos.getY(i) + dt * 0.4);
      } else {
        pos.setXYZ(i, 0, -20, 0);
      }
    }
    pos.needsUpdate = true;

    if (this.world.waterMesh) {
      const mat = this.world.waterMesh.material as THREE.MeshStandardMaterial;
      if (mat.map) {
        mat.map.offset.x += dt * 0.012;
        mat.map.offset.y += dt * 0.008;
      }
      this.world.waterMesh.position.y = this.world.waterY + Math.sin(performance.now() * 0.0012) * 0.1;
    }
    if (this.world.clouds) this.world.clouds.rotation.y += dt * 0.004;
    if (this.world.windmillBlades) this.world.windmillBlades.rotation.z += dt * 0.55;
    if (this.world.signalRed && this.world.signalGreen) {
      const go = Math.floor(performance.now() / 3200) % 2 === 0;
      this.world.signalRed.emissiveIntensity = go ? 0.08 : 1.15;
      this.world.signalGreen.emissiveIntensity = go ? 1.15 : 0.08;
    }
    this.sun.position.set(this.vehicle.x + 55, 110, this.vehicle.z + 32);
    this.sun.target.position.set(this.vehicle.x, this.vehicle.y, this.vehicle.z);
    this.sun.target.updateMatrixWorld();

    if (st.screen === "title") {
      const t = this.titleT;
      this.camera.position.set(Math.sin(t * 0.18) * 48, 22, Math.cos(t * 0.18) * 48);
      this.camera.lookAt(0, 4, 0);
      this.audio.update({
        rpm: 1200,
        throttle: 0.1,
        speed: 0,
        drifting: false,
        roar: 0.4,
        ev: false,
        paused: true,
      });
      return;
    }

    const fwd = this.vehicle.forward();
    const follow = this.hood ? 2.2 : 8.6;
    const height = this.hood ? 1.15 : 3.4;
    const lookAhead = this.hood ? 10 : 7;
    const desired = this.tmpA.set(
      this.vehicle.x + fwd.x * -follow,
      this.vehicle.y + height,
      this.vehicle.z + fwd.z * -follow,
    );
    this.camPos.x = lerpExp(this.camPos.x, desired.x, 4.2, dt);
    this.camPos.y = lerpExp(this.camPos.y, desired.y, 5.2, dt);
    this.camPos.z = lerpExp(this.camPos.z, desired.z, 4.2, dt);
    const shake = this.trauma * this.trauma;
    const look = this.tmpB.set(
      this.vehicle.x + fwd.x * lookAhead,
      this.vehicle.y + 0.8,
      this.vehicle.z + fwd.z * lookAhead,
    );
    this.camLook.x = lerpExp(this.camLook.x, look.x, 6, dt);
    this.camLook.y = lerpExp(this.camLook.y, look.y, 6, dt);
    this.camLook.z = lerpExp(this.camLook.z, look.z, 6, dt);
    this.camera.position.copy(this.camPos);
    if (shake > 0.01) {
      this.camera.position.x += (Math.random() - 0.5) * shake * 0.55;
      this.camera.position.y += (Math.random() - 0.5) * shake * 0.35;
    }
    this.camera.lookAt(this.camLook);
    const kmh = Math.abs(this.vehicle.speed) * 3.6;
    this.camera.fov = lerpExp(this.camera.fov, 62 + Math.min(14, kmh * 0.05), 3, dt);
    this.camera.updateProjectionMatrix();
  }

  private spawnWalkers() {
    const shirts = [0xc45c3a, 0x1e4d8c, 0xe8b86d, 0x5a6b3a, 0xf2efe8, 0x8a1f1a, 0x3d5c7a, 0xd07098];
    const variants = ["adult", "kid", "elder", "woman"] as const;
    const bands = [42, 68, 96];
    const paths: { x: number; z: number }[][] = [];
    for (const r of bands) {
      const near = this.world.sidewalks.filter((p) => Math.abs(Math.hypot(p.x, p.z) - r) < 16);
      near.sort((a, b) => Math.atan2(a.z, a.x) - Math.atan2(b.z, b.x));
      const loop: { x: number; z: number }[] = [];
      for (let i = 0; i < near.length; i += 2) loop.push(near[i]!);
      if (loop.length >= 4) paths.push(loop);
    }
    const plaza = [
      { x: PLAZA.x - 8, z: PLAZA.z - 8 },
      { x: PLAZA.x + 8, z: PLAZA.z - 8 },
      { x: PLAZA.x + 8, z: PLAZA.z + 8 },
      { x: PLAZA.x - 8, z: PLAZA.z + 8 },
    ].filter((p) => !this.world.onRoad(p.x, p.z));
    if (plaza.length >= 3) paths.push(plaza);
    if (!paths.length) {
      paths.push([
        { x: 36, z: 36 },
        { x: 36, z: -20 },
        { x: -20, z: -20 },
        { x: -20, z: 36 },
      ]);
    }
    for (let i = 0; i < 28; i++) {
      const variant = variants[i % variants.length]!;
      const made = makePerson(shirts[i % shirts.length]!, variant);
      this.scene.add(made.mesh);
      const path = paths[i % paths.length]!;
      const pi = i % path.length;
      const start = path[pi]!;
      this.walkers.push({
        x: start.x,
        z: start.z,
        yaw: 0,
        t: i * 0.45,
        speed: variant === "kid" ? 2.05 : variant === "elder" ? 0.78 : 1.32,
        path,
        pi,
        mesh: made.mesh,
        lArm: made.lArm,
        rArm: made.rArm,
        lLeg: made.lLeg,
        rLeg: made.rLeg,
      });
    }
  }

  private walkerStep(dt: number) {
    for (const w of this.walkers) {
      w.t += dt;
      const goal = w.path[w.pi]!;
      const dx = goal.x - w.x;
      const dz = goal.z - w.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 1.15) w.pi = (w.pi + 1) % w.path.length;
      else {
        w.yaw = Math.atan2(-dx, -dz);
        w.x += -Math.sin(w.yaw) * w.speed * dt;
        w.z += -Math.cos(w.yaw) * w.speed * dt;
      }
      const hit = this.world.collide(w.x, w.z, 0.35);
      if (hit) {
        w.x += hit.nx * (hit.depth + 0.02);
        w.z += hit.nz * (hit.depth + 0.02);
        w.pi = (w.pi + 1) % w.path.length;
      }
      if (this.world.onRoad(w.x, w.z)) {
        const len = Math.hypot(w.x, w.z) || 1;
        w.x += (w.x / len) * 1.6 * dt;
        w.z += (w.z / len) * 1.6 * dt;
      }
      const swing = Math.sin(w.t * (5.2 + w.speed * 2.4)) * 0.72;
      w.lArm.rotation.x = swing;
      w.rArm.rotation.x = -swing;
      w.lLeg.rotation.x = -swing * 0.95;
      w.rLeg.rotation.x = swing * 0.95;
      const bob = Math.abs(Math.sin(w.t * (5.2 + w.speed * 2.4))) * 0.045;
      w.mesh.position.set(w.x, this.world.heightAt(w.x, w.z) + bob, w.z);
      w.mesh.rotation.y = w.yaw;
    }
  }

  private wireControlsTest() {
    window.__controlsTest = {
      getYaw: () => this.vehicle.yaw,
      getSpeed: () => this.vehicle.speed,
      setSteer: (v: number) => {
        input.qaSteer = v;
      },
      setKeys: (codes: string[]) => input.setKeys(codes),
    };
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setSteer?: (v: number) => void;
      setKeys?: (codes: string[]) => void;
    };
    __horizont?: GameEngine;
  }
}

function makePassenger() {
  const g = new THREE.Group();
  g.name = "passenger";
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.2, 0.42, 3, 6),
    new THREE.MeshStandardMaterial({ color: "#3d5c7a", roughness: 0.7 }),
  );
  body.position.set(0.42, 0.92, 0.08);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.15, 8, 6),
    new THREE.MeshStandardMaterial({ color: "#e8c4a8", roughness: 0.7 }),
  );
  head.position.set(0.42, 1.32, 0.08);
  g.add(body, head);
  g.visible = false;
  return g;
}

function makeCargo() {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 0.45, 0.7),
    new THREE.MeshStandardMaterial({ color: "#c45c3a", roughness: 0.8 }),
  );
  mesh.position.set(-0.05, 0.95, 0.7);
  mesh.visible = false;
  return mesh;
}

function makePerson(shirt: number, variant: "adult" | "kid" | "elder" | "woman" = "adult") {
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xe8c4a8, roughness: 0.72 });
  const shirtM = new THREE.MeshStandardMaterial({ color: shirt, roughness: 0.78 });
  const pantsM = new THREE.MeshStandardMaterial({
    color: variant === "woman" ? 0x2a3340 : 0x2a2c30,
    roughness: 0.85,
  });
  const hairCol = variant === "elder" ? 0xc8ccd2 : variant === "kid" ? 0xc45c3a : 0x3a2a22;
  const hairM = new THREE.MeshStandardMaterial({ color: hairCol, roughness: 0.9 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.22), shirtM);
  torso.position.y = 1.08;
  const hips = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.22, 0.22), pantsM);
  hips.position.y = 0.74;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8), skin);
  head.position.y = 1.48;
  const eyeM = new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.4 });
  const eyeGeo = new THREE.SphereGeometry(0.028, 6, 5);
  const le = new THREE.Mesh(eyeGeo, eyeM);
  le.position.set(-0.055, 1.5, 0.145);
  const re = new THREE.Mesh(eyeGeo, eyeM);
  re.position.set(0.055, 1.5, 0.145);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(variant === "woman" ? 0.19 : 0.175, 10, 8), hairM);
  hair.position.y = variant === "woman" ? 1.52 : 1.56;
  hair.scale.set(1, variant === "woman" ? 0.85 : 0.5, variant === "woman" ? 1.15 : 1);
  if (variant === "woman") {
    const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.42, 8), shirtM);
    skirt.position.y = 0.78;
    g.add(skirt);
  }
  if (variant === "elder") {
    const hat = new THREE.Mesh(
      new THREE.CylinderGeometry(0.2, 0.2, 0.08, 8),
      new THREE.MeshStandardMaterial({ color: 0x3a4048, roughness: 0.8 }),
    );
    hat.position.y = 1.68;
    const brim = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.28, 0.03, 8),
      new THREE.MeshStandardMaterial({ color: 0x2a2c30 }),
    );
    brim.position.y = 1.64;
    g.add(hat, brim);
  }
  if (variant === "adult" || variant === "woman") {
    const bag = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.16, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x6a5340, roughness: 0.85 }),
    );
    bag.position.set(0.26, 0.95, 0.02);
    g.add(bag);
  }
  const lArm = new THREE.Group();
  const rArm = new THREE.Group();
  const armGeo = new THREE.CapsuleGeometry(0.055, 0.34, 3, 5);
  const la = new THREE.Mesh(armGeo, shirtM);
  la.position.y = -0.22;
  lArm.add(la);
  lArm.position.set(-0.26, 1.24, 0);
  const ra = new THREE.Mesh(armGeo, shirtM);
  ra.position.y = -0.22;
  rArm.add(ra);
  rArm.position.set(0.26, 1.24, 0);
  const lLeg = new THREE.Group();
  const rLeg = new THREE.Group();
  const legGeo = new THREE.CapsuleGeometry(0.07, 0.36, 3, 5);
  const ll = new THREE.Mesh(legGeo, pantsM);
  ll.position.y = -0.26;
  lLeg.add(ll);
  const shoeGeo = new THREE.BoxGeometry(0.11, 0.06, 0.18);
  const shoeM = new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.7 });
  const sl = new THREE.Mesh(shoeGeo, shoeM);
  sl.position.set(0, -0.48, 0.03);
  lLeg.add(sl);
  lLeg.position.set(-0.1, 0.64, 0);
  const rl = new THREE.Mesh(legGeo, pantsM);
  rl.position.y = -0.26;
  rLeg.add(rl);
  const sr = new THREE.Mesh(shoeGeo, shoeM);
  sr.position.set(0, -0.48, 0.03);
  rLeg.add(sr);
  rLeg.position.set(0.1, 0.64, 0);
  g.add(torso, hips, head, hair, le, re, lArm, rArm, lLeg, rLeg);
  if (variant === "kid") g.scale.setScalar(0.64);
  if (variant === "elder") g.scale.setScalar(0.92);
  return { mesh: g, lArm, rArm, lLeg, rLeg };
}
