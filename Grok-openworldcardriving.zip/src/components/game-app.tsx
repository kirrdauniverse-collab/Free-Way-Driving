import { useEffect, useRef, useState, type ReactNode } from "react";
import { Navigation, Pause, Volume2, X } from "lucide-react";
import {
  CARS,
  DESTINATIONS,
  UPGRADE_COST,
  UPGRADE_LABEL,
} from "@/game/data";
import { input } from "@/game/input";
import { hasSave } from "@/game/save";
import { useGame } from "@/game/store";
import type { DestKind, UpgradeKind } from "@/game/types";

function ft(n: number) {
  return `${Math.round(n).toLocaleString("hu-HU")} Ft`;
}

function resume() {
  useGame.getState().setScreen("play");
  window.__horizont?.setFrozen(false);
}

function openMap() {
  useGame.getState().setScreen("map");
  window.__horizont?.setFrozen(true);
}

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ready = useGame((s) => s.ready);
  const screen = useGame((s) => s.screen);
  const progress = useGame((s) => s.loadProgress);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let engine: { dispose: () => void } | null = null;
    void import("@/game/engine").then(({ GameEngine }) => {
      if (dead) return;
      const created = new GameEngine(canvas);
      window.__horizont = created;
      engine = created;
      created.start();
    });
    return () => {
      dead = true;
      engine?.dispose();
      window.__horizont = undefined;
    };
  }, []);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="game-canvas" />
      {!ready && <Loading progress={progress} />}
      {ready && screen === "title" && <Title />}
      {ready && screen === "play" && <PlayHud />}
      {ready && screen === "pause" && <PauseMenu />}
      {ready && screen === "help" && <Help />}
      {ready && screen === "map" && <MapOverlay />}
      {ready && screen === "garage" && <Garage />}
      {ready && screen === "dealer" && <Dealer />}
      {ready && screen === "fishing" && <Fishing />}
      {ready && (screen === "play" || screen === "pause") && <TouchControls />}
    </main>
  );
}

function Loading({ progress }: { progress: number }) {
  return (
    <div className="absolute inset-0 flex items-end bg-bg/40 p-6 sm:items-center sm:justify-center">
      <div className="hud-panel w-full max-w-sm rounded-xl p-6">
        <p className="font-display text-5xl tracking-wide">HORIZONT</p>
        <p className="mt-2 text-muted">A város ébred…</p>
        <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div className="load-bar h-full bg-accent" style={{ width: `${Math.round(progress * 100)}%` }} />
        </div>
      </div>
    </div>
  );
}

function Title() {
  const [help, setHelp] = useState(false);
  const saved = hasSave();
  const start = (fresh: boolean) => {
    if (fresh) useGame.getState().newGame();
    window.__horizont?.beginPlay();
  };
  return (
    <div className="pointer-events-none absolute inset-0 flex items-end p-4 sm:items-center sm:p-8">
      <div className="pointer-events-auto hud-panel w-full max-w-md rounded-xl p-6 sm:p-8">
        <p className="text-sm tracking-widest text-muted">NYÍLT VILÁG</p>
        <h1 className="font-display text-6xl leading-none tracking-wide">HORIZONT</h1>
        <p className="mt-3 max-w-sm text-base leading-relaxed text-muted">
          Vezess a városban, az erdőn és a sivatagban. Keress pénzt fuvarokkal, fejleszd a kocsit, és keresd a rejtett helyeket.
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <button
            className="min-h-12 rounded-lg bg-accent px-4 font-display text-xl tracking-wide text-accent-fg"
            onClick={() => start(true)}
          >
            Indítás
          </button>
          {saved && (
            <button
              className="min-h-12 rounded-lg border border-border bg-surface px-4 font-display text-xl text-fg"
              onClick={() => start(false)}
            >
              Folytatás
            </button>
          )}
          <button
            className="min-h-11 rounded-lg px-4 text-muted"
            onClick={() => setHelp((v) => !v)}
          >
            Segítség
          </button>
        </div>
        {help && <HelpBody />}
      </div>
    </div>
  );
}

function PlayHud() {
  const speed = useGame((s) => s.speedKmh);
  const gear = useGame((s) => s.gear);
  const rpm = useGame((s) => s.rpm);
  const biome = useGame((s) => s.biomeLabel);
  const money = useGame((s) => s.money);
  const prompt = useGame((s) => s.prompt);
  const toast = useGame((s) => s.toast);
  const job = useGame((s) => s.job);
  const challenge = useGame((s) => s.challenge);
  const minimap = useGame((s) => s.minimap);
  const wayRel = useGame((s) => s.wayRel);
  const wayDist = useGame((s) => s.wayDist);
  const waypoint = useGame((s) => s.waypoint);
  const drifting = useGame((s) => s.drifting);
  const rpmPct = Math.min(100, Math.max(8, ((rpm - 700) / 6500) * 100));

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 sm:p-4">
        <div className="hud-panel rounded-xl px-4 py-3">
          <div className="flex items-end gap-3">
            <p className="font-display text-5xl leading-none tabular-nums">{Math.round(speed)}</p>
            <p className="mb-1 text-sm text-muted">km/h</p>
          </div>
          <div className="mt-2 flex items-center gap-2 text-sm text-muted">
            <span>{gear}. fokozat</span>
            <span>·</span>
            <span>{biome}</span>
            {drifting && <span className="text-speed">drift</span>}
          </div>
          <div className="mt-2 h-1 w-28 overflow-hidden rounded-full bg-surface-2">
            <div className="rpm-fill h-full bg-speed" style={{ width: `${rpmPct}%` }} />
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="hud-panel rounded-xl px-4 py-3 text-right">
            <p className="text-xs text-muted">Pénz</p>
            <p className="font-display text-2xl text-cash">{ft(money)}</p>
          </div>
          <div className="pointer-events-auto flex gap-2">
            <HudBtn label="Úticél" onClick={openMap}>
              <Navigation className="size-4" />
            </HudBtn>
            <HudBtn
              label="Szünet"
              onClick={() => {
                useGame.getState().setScreen("pause");
                window.__horizont?.setFrozen(true);
              }}
            >
              <Pause className="size-4" />
            </HudBtn>
          </div>
        </div>
      </div>

      {(job || challenge) && (
        <div className="pointer-events-none absolute top-36 left-3 max-w-xs sm:top-32 sm:left-4">
          <div className="hud-panel rounded-xl px-4 py-3">
            <p className="font-display text-xl">{job?.title ?? challenge?.title}</p>
            <p className="mt-1 text-sm text-muted">{job?.detail ?? challenge?.detail}</p>
          </div>
        </div>
      )}

      {waypoint && wayRel != null && (
        <div className="pointer-events-none absolute top-36 right-3 sm:top-32 sm:right-4">
          <div className="hud-panel flex items-center gap-2 rounded-xl px-3 py-2">
            <Navigation
              className="size-5 text-accent"
              style={{ transform: `rotate(${(-wayRel * 180) / Math.PI}deg)` }}
            />
            <div>
              <p className="text-sm">{waypoint.label ?? "Úticél"}</p>
              <p className="text-xs text-muted">{Math.round(wayDist ?? 0)} m</p>
            </div>
          </div>
        </div>
      )}

      {prompt && (
        <div className="pointer-events-none absolute inset-x-0 bottom-28 flex justify-center px-4 sm:bottom-8">
          <p className="hud-panel rounded-full px-4 py-2 text-sm">{prompt}</p>
        </div>
      )}

      {toast && (
        <div className="pointer-events-none absolute inset-x-0 bottom-40 flex justify-center px-4 sm:bottom-20">
          <p className="hud-panel rounded-lg px-4 py-2 text-sm">{toast.text}</p>
        </div>
      )}

      {minimap && (
        <img
          src={minimap}
          alt="Térkép"
          className="pointer-events-none absolute right-3 bottom-3 size-28 rounded-xl border border-border sm:right-4 sm:bottom-4 sm:size-36"
        />
      )}
    </>
  );
}

function HudBtn({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      className="hud-panel flex min-h-11 items-center gap-2 rounded-lg px-3 text-sm"
      onClick={onClick}
    >
      {children}
      {label}
    </button>
  );
}

function PauseMenu() {
  return (
    <Overlay title="Szünet">
      <button className="min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg" onClick={resume}>
        Folytatás
      </button>
      <button className="min-h-12 rounded-lg border border-border bg-surface font-display text-xl" onClick={openMap}>
        Úticél
      </button>
      <button
        className="min-h-12 rounded-lg border border-border bg-surface font-display text-xl"
        onClick={() => useGame.getState().setScreen("help")}
      >
        Segítség
      </button>
      <button
        className="min-h-11 text-muted"
        onClick={() => {
          useGame.getState().setScreen("title");
          window.__horizont?.setFrozen(true);
        }}
      >
        Főmenü
      </button>
    </Overlay>
  );
}

function Help() {
  return (
    <Overlay title="Irányítás" onClose={resume}>
      <HelpBody />
      <button className="min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg" onClick={resume}>
        Vissza
      </button>
    </Overlay>
  );
}

function HelpBody() {
  return (
    <ul className="mt-4 space-y-2 text-sm leading-relaxed text-muted">
      <li>W / felfelé — gáz. S — fék. A és D — balra és jobbra.</li>
      <li>Szóköz — kézifék drifteléshez. H — duda. V — motorháztető kamera.</li>
      <li>E — munka, műhely, kereskedés, peca. M — úticél.</li>
      <li>Az Úticél menüben válassz munkát, kihívást vagy bulit: a nyilak mutatják az utat.</li>
      <li>A gyártelepen driftelj, a reptéren gyorsulj. A víznél állj meg, és pecázz.</li>
    </ul>
  );
}

function MapOverlay() {
  const [tab, setTab] = useState<DestKind>("work");
  const posX = useGame((s) => s.posX);
  const posZ = useGame((s) => s.posZ);
  const list = DESTINATIONS.filter((d) => d.kind === tab);
  const tabs: { id: DestKind; label: string }[] = [
    { id: "work", label: "Munka" },
    { id: "challenge", label: "Kihívás" },
    { id: "party", label: "Buli" },
  ];
  return (
    <Overlay title="Úticél" onClose={resume}>
      <div className="grid grid-cols-3 gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={`min-h-11 rounded-lg border px-2 text-sm ${
              tab === t.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-surface text-fg"
            }`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="mt-3 flex max-h-96 flex-col gap-2 overflow-y-auto">
        {list.map((d) => {
          const dist = Math.hypot(d.x - posX, d.z - posZ);
          return (
            <button
              key={d.id}
              className="flex min-h-16 items-center justify-between gap-3 rounded-lg border border-border bg-surface px-3 py-2 text-left"
              onClick={() => {
                useGame.getState().setWaypoint({ x: d.x, z: d.z, label: d.name });
                useGame.getState().toastMsg(`GPS: ${d.name}`);
                resume();
              }}
            >
              <span>
                <span className="block font-display text-xl">{d.name}</span>
                <span className="block text-sm text-muted">{d.blurb}</span>
              </span>
              <span className="shrink-0 text-sm text-muted">{Math.round(dist)} m</span>
            </button>
          );
        })}
      </div>
    </Overlay>
  );
}

function Garage() {
  const money = useGame((s) => s.money);
  const owned = useGame((s) => s.owned);
  const current = useGame((s) => s.currentCar);
  const upgrades = useGame((s) => s.upgrades);
  const car = CARS.find((c) => c.id === current)!;
  const u = upgrades[current] ?? {};
  const kinds: UpgradeKind[] = ["engine", "tires", "brakes", "turbo"];
  return (
    <Overlay title="Műhely" onClose={resume}>
      <p className="text-sm text-muted">
        {car.name} · {ft(money)}
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {owned.map((id) => {
          const c = CARS.find((x) => x.id === id)!;
          return (
            <button
              key={id}
              className={`min-h-12 rounded-lg border px-3 text-left text-sm ${
                id === current ? "border-accent bg-surface-2" : "border-border bg-surface"
              }`}
              onClick={() => {
                useGame.getState().selectCar(id);
                window.__horizont?.swapCar(id);
              }}
            >
              {c.name}
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex flex-col gap-2">
        {kinds.map((k) => {
          const lvl = u[k] ?? 0;
          const cost = lvl >= 3 ? null : UPGRADE_COST[lvl];
          return (
            <button
              key={k}
              disabled={cost == null || money < (cost ?? 0)}
              className="flex min-h-12 items-center justify-between rounded-lg border border-border bg-surface px-3 text-sm disabled:opacity-40"
              onClick={() => {
                if (useGame.getState().bumpUpgrade(current, k)) {
                  useGame.getState().toastMsg(`${UPGRADE_LABEL[k]} szint ${lvl + 1}`);
                }
              }}
            >
              <span>
                {UPGRADE_LABEL[k]} · {"●".repeat(lvl)}
                {"○".repeat(3 - lvl)}
              </span>
              <span className="text-cash">{cost == null ? "Max" : ft(cost)}</span>
            </button>
          );
        })}
      </div>
    </Overlay>
  );
}

function Dealer() {
  const money = useGame((s) => s.money);
  const owned = useGame((s) => s.owned);
  const found = useGame((s) => s.foundSecret);
  const list = CARS.filter((c) => !c.secret || found);
  return (
    <Overlay title="Kereskedés" onClose={resume}>
      <p className="text-sm text-cash">{ft(money)}</p>
      <div className="mt-3 flex max-h-96 flex-col gap-2 overflow-y-auto">
        {list.map((c) => {
          const have = owned.includes(c.id);
          const canBuy = !have && !c.secret && money >= c.price;
          return (
            <div key={c.id} className="rounded-lg border border-border bg-surface p-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-display text-xl">{c.name}</p>
                  <p className="text-sm text-muted">
                    {c.klass} · {c.blurb}
                  </p>
                </div>
                <span className="size-4 shrink-0 rounded-full" style={{ background: c.color }} />
              </div>
              <div className="mt-2 flex gap-2">
                {!have && !c.secret && (
                  <button
                    disabled={!canBuy}
                    className="min-h-11 flex-1 rounded-lg bg-accent text-sm text-accent-fg disabled:opacity-40"
                    onClick={() => {
                      useGame.getState().ownCar(c.id);
                      window.__horizont?.swapCar(c.id);
                      useGame.getState().toastMsg(`${c.name} a tiéd.`);
                    }}
                  >
                    Vétel · {ft(c.price)}
                  </button>
                )}
                {have && <span className="flex min-h-11 flex-1 items-center text-sm text-cash">Megvan</span>}
                {have && owned.length > 1 && c.id !== "csibe" && (
                  <button
                    className="min-h-11 rounded-lg border border-border px-3 text-sm"
                    onClick={() => useGame.getState().sellCar(c.id)}
                  >
                    Eladás
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Overlay>
  );
}

function Fishing() {
  const [pos, setPos] = useState(0.2);
  useEffect(() => {
    let raf = 0;
    let p = 0.2;
    let dir = 1;
    let last = performance.now();
    const step = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      p += dir * dt * 0.72;
      if (p > 1) {
        p = 1;
        dir = -1;
      }
      if (p < 0) {
        p = 0;
        dir = 1;
      }
      setPos(p);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);
  const cast = () => {
    const sweet = Math.abs(pos - 0.72);
    const st = useGame.getState();
    if (sweet < 0.08) {
      st.addMoney(180);
      st.bumpStat("fishCaught");
      st.toastMsg("Ponty! +180 Ft");
      resume();
    } else if (sweet < 0.2) {
      st.addMoney(70);
      st.bumpStat("fishCaught");
      st.toastMsg("Keszeg. +70 Ft");
      resume();
    } else {
      st.toastMsg("Elúszott. Cél a zöld sáv.");
    }
  };
  return (
    <Overlay title="Pecázás" onClose={resume}>
      <p className="text-sm text-muted">Dobd be, amikor a mutató a zöld sávban van.</p>
      <div className="relative mt-4 h-4 overflow-hidden rounded-full bg-surface-2">
        <div className="absolute top-0 h-full w-8 bg-cash/80" style={{ left: "68%" }} />
        <div className="absolute top-0 h-full w-1 bg-fg" style={{ left: `${pos * 100}%` }} />
      </div>
      <button className="mt-4 min-h-12 rounded-lg bg-accent font-display text-xl text-accent-fg" onClick={cast}>
        Bevetés
      </button>
    </Overlay>
  );
}

function Overlay({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose?: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-end justify-center bg-bg/55 p-3 sm:items-center sm:p-6">
      <div className="hud-panel flex max-h-dvh w-full max-w-md flex-col overflow-y-auto rounded-xl p-4 sm:p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-display text-3xl tracking-wide">{title}</h2>
          {onClose && (
            <button className="flex size-11 items-center justify-center rounded-lg border border-border" onClick={onClose} aria-label="Bezárás">
              <X className="size-4" />
            </button>
          )}
        </div>
        {children}
      </div>
    </div>
  );
}

function TouchControls() {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-3 md:hidden">
      <div className="pointer-events-auto flex gap-2">
        <Hold
          label="Balra"
          onDown={() => {
            input.steerTouch = 1;
          }}
          onUp={() => {
            input.steerTouch = 0;
          }}
        >
          <span className="font-display text-xl">A</span>
        </Hold>
        <Hold
          label="Jobbra"
          onDown={() => {
            input.steerTouch = -1;
          }}
          onUp={() => {
            input.steerTouch = 0;
          }}
        >
          <span className="font-display text-xl">D</span>
        </Hold>
      </div>
      <div className="pointer-events-auto flex gap-2">
        <Hold
          label="Fék"
          onDown={() => {
            input.brakeTouch = 1;
          }}
          onUp={() => {
            input.brakeTouch = 0;
          }}
        >
          S
        </Hold>
        <Hold
          label="Gáz"
          primary
          onDown={() => {
            input.throttleTouch = 1;
          }}
          onUp={() => {
            input.throttleTouch = 0;
          }}
        >
          W
        </Hold>
        <Hold
          label="Kézifék"
          onDown={() => {
            input.handbrakeTouch = true;
          }}
          onUp={() => {
            input.handbrakeTouch = false;
          }}
        >
          ●
        </Hold>
        <Hold
          label="Duda"
          onDown={() => {
            input.hornTouch = true;
          }}
          onUp={() => {
            input.hornTouch = false;
          }}
        >
          <Volume2 className="size-4" />
        </Hold>
        <Hold
          label="E"
          onDown={() => {
            input.interactTouch = true;
          }}
          onUp={() => {
            input.interactTouch = false;
          }}
        >
          E
        </Hold>
      </div>
    </div>
  );
}

function Hold({
  label,
  onDown,
  onUp,
  children,
  primary,
}: {
  label: string;
  onDown: () => void;
  onUp: () => void;
  children: ReactNode;
  primary?: boolean;
}) {
  return (
    <button
      aria-label={label}
      className={`flex size-12 items-center justify-center rounded-lg border border-border text-sm ${
        primary ? "bg-accent text-accent-fg" : "bg-bg/80 text-fg"
      }`}
      onPointerDown={(e) => {
        e.preventDefault();
        (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      onLostPointerCapture={onUp}
    >
      {children}
    </button>
  );
}
